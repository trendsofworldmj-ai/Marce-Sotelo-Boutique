from flask import Blueprint, g, jsonify, request
import db
from auth import audit, login_required, role_required
from inventory import StockError, move_stock, to_int, txt
from sales import err

bp = Blueprint("transfers", __name__)

def t_folio(tid):
    return f"TR-{tid:06d}"

def log_event(con, tid, action, detail=""):
    con.execute("INSERT INTO transfer_events(transfer_id, user_id, action, detail) VALUES(?,?,?,?)",
                (tid, g.user["id"], action, detail))

def detail_transfer(con, tid):
    t = con.execute("""
        SELECT t.*, 
               ob.name AS origin_branch_name, ob.code AS origin_branch_code,
               db.name AS dest_branch_name, db.code AS dest_branch_code,
               u_req.username AS requested_by_user,
               u_aut.username AS authorized_by_user,
               u_shp.username AS shipped_by_user,
               u_rcv.username AS received_by_user
        FROM transfers t
        JOIN branches ob ON ob.id = t.origin_branch_id
        JOIN branches db ON db.id = t.dest_branch_id
        JOIN users u_req ON u_req.id = t.requested_by
        LEFT JOIN users u_aut ON u_aut.id = t.authorized_by
        LEFT JOIN users u_shp ON u_shp.id = t.shipped_by
        LEFT JOIN users u_rcv ON u_rcv.id = t.received_by
        WHERE t.id = ?
    """, (tid,)).fetchone()
    if not t: return None

    items = con.execute("""
        SELECT ti.*, v.sku, v.size, v.color, p.name AS product_name
        FROM transfer_items ti
        JOIN variants v ON v.id = ti.variant_id
        JOIN products p ON p.id = v.product_id
        WHERE ti.transfer_id = ?
    """, (tid,)).fetchall()

    events = con.execute("""
        SELECT te.*, u.username
        FROM transfer_events te
        JOIN users u ON u.id = te.user_id
        WHERE te.transfer_id = ?
        ORDER BY te.id ASC
    """, (tid,)).fetchall()

    return {
        "id": t["id"], "folio": t["folio"], "status": t["status"],
        "origin_branch": {"id": t["origin_branch_id"], "name": t["origin_branch_name"], "code": t["origin_branch_code"]},
        "dest_branch": {"id": t["dest_branch_id"], "name": t["dest_branch_name"], "code": t["dest_branch_code"]},
        "requested_by": t["requested_by_user"], "authorized_by": t["authorized_by_user"],
        "shipped_by": t["shipped_by_user"], "received_by": t["received_by_user"],
        "notes": t["notes"], "created_at": t["created_at"], "updated_at": t["updated_at"],
        "items": [dict(i) for i in items],
        "events": [dict(e) for e in events]
    }

@bp.post("/api/transfers")
@login_required
def create_transfer():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    try:
        origin_id = int(d.get("origin_branch_id"))
        dest_id = int(d.get("dest_branch_id"))
        if origin_id == dest_id:
            return err("La sucursal de origen y destino deben ser distintas.", 400)
        
        if g.user["role"] != "admin" and g.user["branch_id"]:
            if g.user["branch_id"] not in (origin_id, dest_id):
                return err("Solo puedes solicitar traspasos relacionados con tu sucursal.", 403)

        items_input = d.get("items") or []
        if not items_input:
            return err("Agrega al menos una partida al traspaso.", 400)

        notes = txt(d.get("notes"), "notas", 300)
        
        # Consolidar por variant_id para blindar contra duplicados
        raw_lines = {}
        for it in items_input:
            vid = int(it.get("variant_id"))
            qty = to_int(it.get("qty"), "cantidad", minimum=1)
            raw_lines[vid] = raw_lines.get(vid, 0) + qty

        clean_items = []
        for vid, qty in raw_lines.items():
            r = con.execute("""
                SELECT vs.stock, vs.reserved, v.sku 
                FROM variant_stock vs JOIN variants v ON v.id = vs.variant_id
                WHERE vs.variant_id=? AND vs.branch_id=?
            """, (vid, origin_id)).fetchone()
            if not r:
                return err(f"La variante {vid} no tiene registro en la sucursal de origen.", 400)
            avail = r["stock"] - r["reserved"]
            if avail < qty:
                return err(f"Stock insuficiente en origen para SKU {r['sku']}. Disponible: {avail}, Solicitado: {qty}", 409)
            clean_items.append((vid, qty))

        with con:
            cur = con.execute("""
                INSERT INTO transfers (folio, origin_branch_id, dest_branch_id, status, requested_by, notes)
                VALUES ('TEMP', ?, ?, 'solicitado', ?, ?)
            """, (origin_id, dest_id, g.user["id"], notes))
            tid = cur.lastrowid
            folio = t_folio(tid)
            con.execute("UPDATE transfers SET folio=? WHERE id=?", (folio, tid))
            
            for vid, qty in clean_items:
                con.execute("INSERT INTO transfer_items (transfer_id, variant_id, qty_requested) VALUES (?,?,?)",
                            (tid, vid, qty))
            
            log_event(con, tid, "solicitado", f"Traspaso creado con {len(clean_items)} partidas.")
            audit(con, g.user["id"], "traspaso_solicitado", f"{folio} origen={origin_id} destino={dest_id}")

        return jsonify(id=tid, folio=folio), 201
    except (TypeError, ValueError) as e:
        return err(str(e), 400)

@bp.get("/api/transfers")
@login_required
def list_transfers():
    con = db.get_db()
    sql = "SELECT id FROM transfers WHERE 1=1"
    args = []
    
    if g.user["role"] != "admin" and g.user["branch_id"]:
        sql += " AND (origin_branch_id=? OR dest_branch_id=?)"
        args.extend([g.user["branch_id"], g.user["branch_id"]])
    else:
        bid = request.args.get("branch_id", type=int)
        if bid:
            sql += " AND (origin_branch_id=? OR dest_branch_id=?)"
            args.extend([bid, bid])

    status = request.args.get("status")
    if status:
        sql += " AND status=?"; args.append(status)

    sql += " ORDER BY id DESC LIMIT 100"
    rows = con.execute(sql, args).fetchall()
    return jsonify(transfers=[detail_transfer(con, r["id"]) for r in rows])

@bp.get("/api/transfers/<int:tid>")
@login_required
def get_transfer(tid):
    r = detail_transfer(db.get_db(), tid)
    return jsonify(r) if r else err("Traspaso no encontrado.", 404)

@bp.post("/api/transfers/<int:tid>/authorize")
@role_required("admin")
def authorize_transfer(tid):
    con = db.get_db()
    t = con.execute("SELECT * FROM transfers WHERE id=?", (tid,)).fetchone()
    if not t: return err("Traspaso no encontrado.", 404)
    if t["status"] != "solicitado":
        return err("Solo se pueden autorizar traspasos en estado 'solicitado'.", 409)

    with con:
        upd = con.execute("""
            UPDATE transfers 
            SET status='autorizado', authorized_by=?, updated_at=datetime('now','localtime')
            WHERE id=? AND status='solicitado'
        """, (g.user["id"], tid))
        if upd.rowcount != 1:
            return err("El traspaso ya no se encuentra en estado solicitado.", 409)
        log_event(con, tid, "autorizado", f"Autorizado por {g.user['username']}")
        audit(con, g.user["id"], "traspaso_autorizado", t["folio"])
    return jsonify(ok=True)

@bp.post("/api/transfers/<int:tid>/ship")
@login_required
def ship_transfer(tid):
    """Despacho atómico: descuenta físicamente el stock de origen y cambia a 'en_transito'."""
    con = db.get_db()
    t = con.execute("SELECT * FROM transfers WHERE id=?", (tid,)).fetchone()
    if not t: return err("Traspaso no encontrado.", 404)
    if t["status"] != "autorizado":
        return err("El traspaso debe estar 'autorizado' para ser despachado.", 409)

    if g.user["role"] != "admin" and g.user["branch_id"] != t["origin_branch_id"]:
        return err("Solo el personal de la sucursal de origen o administración puede despachar el traspaso.", 403)

    items = con.execute("SELECT * FROM transfer_items WHERE transfer_id=?", (tid,)).fetchall()
    try:
        with con:
            upd = con.execute("""
                UPDATE transfers 
                SET status='en_transito', shipped_by=?, updated_at=datetime('now','localtime')
                WHERE id=? AND status='autorizado'
            """, (g.user["id"], tid))
            if upd.rowcount != 1:
                return err("El traspaso ya fue despachado o modificado.", 409)

            for it in items:
                qty = it["qty_requested"]
                move_stock(con, it["variant_id"], t["origin_branch_id"], "traspaso_salida", -qty,
                           f"Salida {t['folio']}", g.user["id"], "transfer", tid)
                con.execute("UPDATE transfer_items SET qty_shipped=? WHERE id=?", (qty, it["id"]))

            log_event(con, tid, "despachado", "Mercancía en tránsito desde sucursal origen.")
            audit(con, g.user["id"], "traspaso_despachado", t["folio"])
        return jsonify(ok=True)
    except StockError as e:
        return err(f"No se pudo despachar por falta de existencia: {e}", 409)

@bp.post("/api/transfers/<int:tid>/receive")
@login_required
def receive_transfer(tid):
    """Recepción atómica en destino: suma el stock recibido y registra discrepancias."""
    d, con = request.get_json(silent=True) or {}, db.get_db()
    t = con.execute("SELECT * FROM transfers WHERE id=?", (tid,)).fetchone()
    if not t: return err("Traspaso no encontrado.", 404)
    if t["status"] != "en_transito":
        return err("El traspaso debe estar 'en_transito' para recibirse.", 409)

    if g.user["role"] != "admin" and g.user["branch_id"] != t["dest_branch_id"]:
        return err("Solo el personal de la sucursal de destino o administración puede recibir la mercancía.", 403)

    items = con.execute("SELECT * FROM transfer_items WHERE transfer_id=?", (tid,)).fetchall()
    received_map = {int(x["variant_id"]): to_int(x.get("qty"), "cantidad recibida") for x in d.get("items") or []}
    discrepancies = []

    with con:
        upd = con.execute("""
            UPDATE transfers 
            SET status='recibido', received_by=?, updated_at=datetime('now','localtime')
            WHERE id=? AND status='en_transito'
        """, (g.user["id"], tid))
        if upd.rowcount != 1:
            return err("El traspaso ya fue recibido o modificado.", 409)

        for it in items:
            vid = it["variant_id"]
            rec_qty = received_map.get(vid, it["qty_shipped"])
            if rec_qty < 0:
                return err("La cantidad recibida no puede ser negativa.", 400)
            
            con.execute("UPDATE transfer_items SET qty_received=? WHERE id=?", (rec_qty, it["id"]))
            
            if rec_qty > 0:
                move_stock(con, vid, t["dest_branch_id"], "traspaso_entrada", rec_qty,
                           f"Entrada {t['folio']}", g.user["id"], "transfer", tid)
            
            if rec_qty != it["qty_shipped"]:
                discrepancies.append(f"Var {vid}: enviadas {it['qty_shipped']}, recibidas {rec_qty}")

        disc_txt = f" Discrepancias: {'; '.join(discrepancies)}" if discrepancies else " Sin discrepancias."
        log_event(con, tid, "recibido", f"Mercancía recibida en destino.{disc_txt}")
        audit(con, g.user["id"], "traspaso_recibido", f"{t['folio']}{disc_txt}")

    return jsonify(ok=True, discrepancies=discrepancies)

@bp.post("/api/transfers/<int:tid>/cancel")
@login_required
def cancel_transfer(tid):
    d, con = request.get_json(silent=True) or {}, db.get_db()
    reason = str(d.get("reason") or "").strip()
    if len(reason) < 5: return err("Escribe el motivo de cancelación (mín. 5 caracteres).", 400)

    t = con.execute("SELECT * FROM transfers WHERE id=?", (tid,)).fetchone()
    if not t: return err("Traspaso no encontrado.", 404)
    if t["status"] in ("recibido", "cancelado", "rechazado"):
        return err(f"No se puede cancelar un traspaso en estado '{t['status']}'.", 409)

    with con:
        upd = con.execute("""
            UPDATE transfers 
            SET status='cancelado', notes = COALESCE(notes || ' | ', '') || ?, updated_at=datetime('now','localtime')
            WHERE id=? AND status IN ('solicitado', 'autorizado', 'en_transito')
        """, (f"Cancelado: {reason}", tid))
        if upd.rowcount != 1:
            return err("El traspaso ya no puede ser cancelado.", 409)

        if t["status"] == "en_transito":
            items = con.execute("SELECT * FROM transfer_items WHERE transfer_id=?", (tid,)).fetchall()
            for it in items:
                move_stock(con, it["variant_id"], t["origin_branch_id"], "traspaso_cancelacion", it["qty_shipped"],
                           f"Reversión {t['folio']}: {reason}", g.user["id"], "transfer", tid)

        log_event(con, tid, "cancelado", f"Cancelado por {g.user['username']}: {reason}")
        audit(con, g.user["id"], "traspaso_cancelado", f"{t['folio']} motivo={reason}")

    return jsonify(ok=True)