import re
from functools import wraps
from flask import g, jsonify, request, session
from werkzeug.security import generate_password_hash
import db

ROLES = ("admin", "cajero")
USERNAME_RE = re.compile(r"^[a-z0-9._-]{3,30}$")
OPEN_ENDPOINTS = {"change_password", "logout", "me"}

def audit(con, uid, action, detail=""):
    con.execute("INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)", (uid, action, detail))

def create_user(con, username, full_name, role, password, must_change=True, branch_id=None):
    username = username.strip().lower()
    if role not in ROLES: raise ValueError("Rol no válido.")
    if not USERNAME_RE.match(username): raise ValueError("Usuario: 3-30 caracteres (letras, números . _ -).")
    if len(password) < 8: raise ValueError("La contraseña debe tener al menos 8 caracteres.")
    
    if branch_id is not None:
        b = con.execute("SELECT 1 FROM branches WHERE id=? AND active=1", (branch_id,)).fetchone()
        if not b:
            raise ValueError("Sucursal no válida o inactiva.")

    cur = con.execute(
        "INSERT INTO users(username,full_name,role,pass_hash,must_change,branch_id) VALUES(?,?,?,?,?,?)",
        (username, full_name.strip(), role, generate_password_hash(password), int(must_change), branch_id)
    )
    return cur.lastrowid

def public(u):
    out = {
        "id": u["id"],
        "username": u["username"],
        "full_name": u["full_name"],
        "role": u["role"],
        "active": bool(u["active"]),
        "branch_id": u["branch_id"] if "branch_id" in u.keys() else None,
        "branch_name": u["branch_name"] if "branch_name" in u.keys() else None,
        "branch_code": u["branch_code"] if "branch_code" in u.keys() else None,
    }
    return out

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        uid = session.get("uid")
        if not uid:
            session.clear()
            return jsonify(error="Inicia sesión para continuar."), 401
        
        con = db.get_db()
        u = con.execute("""
            SELECT u.*, b.name AS branch_name, b.code AS branch_code 
            FROM users u 
            LEFT JOIN branches b ON b.id = u.branch_id 
            WHERE u.id=? AND u.active=1
        """, (uid,)).fetchone()
        
        if not u:
            session.clear()
            return jsonify(error="Inicia sesión para continuar."), 401
        if u["must_change"] and request.endpoint not in OPEN_ENDPOINTS:
            return jsonify(error="Debes cambiar tu contraseña antes de continuar."), 403
        g.user = u
        return f(*a, **k)
    return w

def role_required(*roles):
    def deco(f):
        @wraps(f)
        @login_required
        def w(*a, **k):
            if g.user["role"] not in roles:
                audit(db.get_db(), g.user["id"], "acceso_denegado", request.path)
                db.get_db().commit()
                return jsonify(error="No tienes permiso para esta operación."), 403
            return f(*a, **k)
        return w
    return deco