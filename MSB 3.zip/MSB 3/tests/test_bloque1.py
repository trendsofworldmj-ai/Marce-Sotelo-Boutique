import os, sqlite3, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

class B1(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.path = os.path.join(self.tmp, "t.db")
        self.app = create_app(self.path)
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "Cajera Uno", "cajero", "Caja12345", must_change=False)
        self.c = self.app.test_client()
    def login(self, u, p, c=None): return (c or self.c).post("/api/login", json={"username": u, "password": p})

    def test_sin_sesion_401(self): self.assertEqual(self.c.get("/api/users").status_code, 401)
    def test_login_ok_y_mal(self):
        self.assertEqual(self.login("marcela", "x").status_code, 401)
        self.assertEqual(self.login("marcela", "Admin12345").status_code, 200)
    def test_cajero_no_gestiona_usuarios(self):
        self.login("caja1", "Caja12345")
        self.assertEqual(self.c.get("/api/users").status_code, 403)
        r = self.c.post("/api/users", json={"username": "x1x", "full_name": "X", "role": "admin", "password": "Abcdefg12"})
        self.assertEqual(r.status_code, 403)
    def test_admin_crea_cajero_y_cambio_obligatorio(self):
        self.login("marcela", "Admin12345")
        r = self.c.post("/api/users", json={"username": "caja2", "full_name": "Dos", "role": "cajero", "password": "Temporal123"})
        self.assertEqual(r.status_code, 201)
        c2 = self.app.test_client(); self.login("caja2", "Temporal123", c2)
        self.assertEqual(c2.get("/api/users").status_code, 403)
        self.assertEqual(c2.post("/api/password", json={"current": "Temporal123", "new": "Nueva12345"}).status_code, 200)
    def test_bloqueo_por_intentos(self):
        for _ in range(5): self.login("caja1", "mal")
        self.assertEqual(self.login("caja1", "Caja12345").status_code, 429)
    def test_ultima_admin_no_se_desactiva(self):
        self.login("marcela", "Admin12345")
        self.assertEqual(self.c.post("/api/users/1/active", json={"active": False}).status_code, 400)
    def test_rechaza_no_json(self):
        self.assertEqual(self.c.post("/api/login", data="a=b").status_code, 415)
    def test_bd_impide_stock_negativo_y_venta_duplicada(self):
        con = sqlite3.connect(self.path); con.execute("PRAGMA foreign_keys=ON")
        con.execute("INSERT INTO products(id,name,price_cents) VALUES(1,'Blusa',38900)")
        con.execute("INSERT INTO variants(id,product_id,sku,size,color,stock) VALUES(1,1,'BLU-M-MAR','M','Marfil',2)")
        with self.assertRaises(sqlite3.IntegrityError): con.execute("UPDATE variants SET stock=-1 WHERE id=1")
        con.execute("INSERT INTO cash_sessions(id,user_id,opening_cents) VALUES(1,1,50000)")
        con.execute("INSERT INTO sales(session_id,user_id,idempotency_key,subtotal_cents,total_cents) VALUES(1,1,'k1',100,100)")
        with self.assertRaises(sqlite3.IntegrityError):
            con.execute("INSERT INTO sales(session_id,user_id,idempotency_key,subtotal_cents,total_cents) VALUES(1,1,'k1',100,100)")

if __name__ == "__main__": unittest.main()
