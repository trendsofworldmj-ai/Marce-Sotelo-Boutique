import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

class B10MultisucursalCore(unittest.TestCase):
    """
    Incremento 2: Verificación de alta de sucursales, asignación a usuarios,
    aislamiento de existencias, seguridad de no-suplantación en cajeras,
    ventas y cajas independientes, y saneamiento auditado de inventario.
    """

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.path = os.path.join(self.tmp, "t.db")
        self.app = create_app(self.path)

        with self.app.app_context():
            con = db.get_db()
            with con:
                # Marcela es Administradora Central (branch_id = None)
                self.uid_admin = create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False, branch_id=None)
                # Crear Sucursal 2 (Sucursal Norte), San José ya fue creada automáticamente en init_app/migrate
                con.execute("INSERT INTO branches (code, name, kind, active) VALUES ('NTE', 'Sucursal Norte', 'operativa', 1)")
                b_sjo = con.execute("SELECT id FROM branches WHERE code='SJO'").fetchone()["id"]
                b_nte = con.execute("SELECT id FROM branches WHERE code='NTE'").fetchone()["id"]
                self.b_sjo, self.b_nte = b_sjo, b_nte

                # Cajera 1 fija en San José
                create_user(con, "caja_sjo", "Cajera San José", "cajero", "Caja12345", must_change=False, branch_id=b_sjo)
                # Cajera 2 fija en Sucursal Norte
                create_user(con, "caja_nte", "Cajera Norte", "cajero", "Caja12345", must_change=False, branch_id=b_nte)

        self.adm = self.app.test_client()
        self.cSjo = self.app.test_client()
        self.cNte = self.app.test_client()

        self.adm.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
        self.cSjo.post("/api/login", json={"username": "caja_sjo", "password": "Caja12345"})
        self.cNte.post("/api/login", json={"username": "caja_nte", "password": "Caja12345"})

    def test_san_jose_principal_y_alta_sucursales(self):
        # 1. San José debe existir como principal
        r = self.adm.get("/api/branches").get_json()
        codes = [b["code"] for b in r["branches"]]
        self.assertIn("SJO", codes)
        self.assertIn("NTE", codes)

        # 2. Cajero no puede crear ni editar sucursales
        self.assertEqual(self.cSjo.post("/api/branches", json={"code": "X", "name": "Sucursal X"}).status_code, 403)
        self.assertEqual(self.cSjo.patch(f"/api/branches/{self.b_sjo}", json={"name": "Otro"}).status_code, 403)

        # 3. Admin crea una tercera sucursal
        res = self.adm.post("/api/branches", json={"code": "SUR", "name": "Sucursal Sur", "kind": "operativa"})
        self.assertEqual(res.status_code, 201)

    def test_aislamiento_de_inventario_entre_sucursales(self):
        # Crear producto con 10 unidades en San José y 3 unidades en Sucursal Norte
        p_res = self.adm.post("/api/products", json={
            "name": "Vestido Gala", "price": 1200, "cost": 600, "branch_id": self.b_sjo,
            "variants": [{"sku": "VG-ROJO-M", "size": "M", "color": "Rojo", "stock": 10}]
        }).get_json()
        pid = p_res["id"]
        vid = self.adm.get("/api/products").get_json()["products"][0]["variants"][0]["id"]

        # Ajustar existencia en Sucursal Norte (+3)
        self.adm.post(f"/api/variants/{vid}/adjust", json={"branch_id": self.b_nte, "delta": 3, "reason": "Carga inicial Norte"})

        # San José debe ver en su catálogo local 10 disponibles
        p_sjo = self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual(p_sjo["stock"], 10)
        self.assertEqual(p_sjo["consolidated_stock"], 13)

        # Sucursal Norte debe ver en su catálogo local 3 disponibles
        p_nte = self.cNte.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual(p_nte["stock"], 3)
        self.assertEqual(p_nte["consolidated_stock"], 13)

        # Ambas pueden ver que la otra tiene existencias en branch_map
        self.assertEqual(p_sjo["branches"][str(self.b_nte)]["stock"], 3)

    def test_cajera_no_puede_suplantar_sucursal_y_venta_aislada(self):
        # Producto con 2 piezas en San José y 0 en Norte
        self.adm.post("/api/products", json={
            "name": "Falda Seda", "price": 500, "cost": 250, "branch_id": self.b_sjo,
            "variants": [{"sku": "FS-AZUL-CH", "size": "CH", "color": "Azul", "stock": 2}]
        })
        vid = self.adm.get("/api/products").get_json()["products"][0]["variants"][0]["id"]

        # Cajera Norte abre su caja
        self.cNte.post("/api/cash/open", json={"opening": 200})

        # Cajera Norte intenta vender 1 pieza (no hay stock en su sucursal)
        # E intenta engañar al servidor enviando "branch_id": self.b_sjo en el payload
        res_fail = self.cNte.post("/api/sales", json={
            "idempotency_key": "llave-trampa-001",
            "branch_id": self.b_sjo, # El servidor DEBE ignorar esto
            "items": [{"variant_id": vid, "qty": 1}],
            "payments": [{"method": "efectivo", "amount": 500, "received": 500}]
        })
        # Debe fallar con 409 Existencia insuficiente en sucursal
        self.assertEqual(res_fail.status_code, 409)
        self.assertIn("insuficiente en sucursal", res_fail.get_json()["error"])

        # En cambio, Cajera San José vende con éxito
        self.cSjo.post("/api/cash/open", json={"opening": 500})
        res_ok = self.cSjo.post("/api/sales", json={
            "idempotency_key": "llave-sjo-001",
            "items": [{"variant_id": vid, "qty": 1}],
            "payments": [{"method": "efectivo", "amount": 500, "received": 500}]
        })
        self.assertEqual(res_ok.status_code, 201)

        # San José baja a 1, Norte se queda en 0, consolidado en 1
        p_check = self.adm.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual(p_check["branches"][str(self.b_sjo)]["stock"], 1)
        self.assertEqual(p_check["branches"][str(self.b_nte)]["stock"], 0)
        self.assertEqual(p_check["consolidated_stock"], 1)

    def test_cajas_independientes_y_cortes_por_sucursal(self):
        # Cajas independientes entre San José y Norte
        self.cSjo.post("/api/cash/open", json={"opening": 1000})
        self.cNte.post("/api/cash/open", json={"opening": 400})

        # Movimiento en San José no afecta Norte
        self.cSjo.post("/api/cash/movements", json={"kind": "salida", "amount": 100, "reason": "Artículos de limpieza"})
        sum_sjo = self.cSjo.get("/api/cash/summary").get_json()
        sum_nte = self.cNte.get("/api/cash/summary").get_json()

        self.assertEqual(sum_sjo["expected"], 900)
        self.assertEqual(sum_nte["expected"], 400)

    def test_saneamiento_y_limpieza_de_inventario(self):
        # 1. Crear producto con stock
        self.adm.post("/api/products", json={
            "name": "Prueba Limpieza", "price": 100, "cost": 50, "branch_id": self.b_sjo,
            "variants": [{"sku": "LIMP-01", "stock": 5}]
        })
        # Poner existencias a cero mediante ajustes auditados
        r_zero = self.adm.post("/api/inventory/clean", json={"mode": "zero_stock", "reason": "Inventario inicial en ceros"}).get_json()
        self.assertTrue(r_zero["ok"])
        p_zero = self.adm.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual(p_zero["stock"], 0)

        # 2. Purga de producto de prueba sin ventas: debe tener éxito
        r_purge = self.adm.post("/api/inventory/clean", json={"mode": "purge_test", "reason": "Limpiar catálogo de prueba"}).get_json()
        self.assertTrue(r_purge["ok"])
        self.assertEqual(len(self.adm.get("/api/products").get_json()["products"]), 0)

        # 3. Crear producto, venderlo, e intentar purga: DEBE RECHAZARSE para proteger integridad contable
        self.adm.post("/api/products", json={
            "name": "Producto Vendido", "price": 200, "cost": 100, "branch_id": self.b_sjo,
            "variants": [{"sku": "VEND-01", "stock": 2}]
        })
        vid = self.adm.get("/api/products").get_json()["products"][0]["variants"][0]["id"]
        self.cSjo.post("/api/cash/open", json={"opening": 100})
        self.cSjo.post("/api/sales", json={
            "idempotency_key": "llave-sjo-limp-01",
            "items": [{"variant_id": vid, "qty": 1}],
            "payments": [{"method": "efectivo", "amount": 200, "received": 200}]
        })
        r_fail_purge = self.adm.post("/api/inventory/clean", json={"mode": "purge_test", "reason": "Intento ilegal de borrar historial"})
        self.assertEqual(r_fail_purge.status_code, 409)

if __name__ == "__main__":
    unittest.main()