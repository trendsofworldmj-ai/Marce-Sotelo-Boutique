import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import license
from gen_license import make_license

class B13Licenciamiento(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.app = create_app(os.path.join(self.tmp, "t.db"))
        self.c = self.app.test_client()
        self.mid = license.get_machine_id()

    def test_formato_id_maquina(self):
        self.assertTrue(self.mid.startswith("MB-"))
        self.assertEqual(len(self.mid.split("-")), 5)

    def test_verificacion_licencia_valida_e_invalida(self):
        # 1. Licencia válida para esta máquina
        valid_key = make_license(self.mid, "PERPETUAL")
        ok, info = license.verify_license_string(valid_key, self.mid)
        self.assertTrue(ok)
        self.assertEqual(info["machine_id"], self.mid)

        # 2. Licencia para otra máquina debe ser rechazada
        other_key = make_license("MB-9999-8888-7777-6666", "PERPETUAL")
        ok_bad, msg = license.verify_license_string(other_key, self.mid)
        self.assertFalse(ok_bad)
        self.assertIn("otro equipo", msg)

        # 3. Licencia falsificada o alterada
        tampered = valid_key[:-4] + "AAAA"
        ok_tamp, msg_tamp = license.verify_license_string(tampered, self.mid)
        self.assertFalse(ok_tamp)
        self.assertIn("inválida", msg_tamp)

        # 4. Licencia vencida
        expired_key = make_license(self.mid, "2020-01-01")
        ok_exp, msg_exp = license.verify_license_string(expired_key, self.mid)
        self.assertFalse(ok_exp)
        self.assertIn("expiró", msg_exp)

    def test_endpoint_activacion(self):
        valid_key = make_license(self.mid, "PERPETUAL")
        res = self.c.post("/api/license/activate", json={"key": valid_key})
        self.assertEqual(res.status_code, 200)
        
        # Estado debe reportar activa
        st = self.c.get("/api/license/status").get_json()
        self.assertTrue(st["licensed"])

if __name__ == "__main__":
    unittest.main()