import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

class B11TraspasosApartados(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.path = os.path.join(self.tmp, "t.db")
        self.app = create_app(self.path)
        with self.app.app_context():
            con = db.get_db()
            with con:
                self.adm_id = create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                con.execute("INSERT INTO branches (code, name, kind, active) VALUES ('NTE', 'Sucursal Norte', 'operativa', 1)")
                self.b_sjo = con.execute("SELECT id FROM branches WHERE code='SJO'").fetchone()["id"]
                self.b_nte = con.execute("SELECT id FROM branches WHERE code='NTE'").fetchone()["id"]
                create_user(con, "caja_sjo", "Caja San José", "cajero", "Caja12345", must_change=False, branch_id=self.b_sjo)
                create_user(con, "caja_nte", "Caja Norte", "cajero", "Caja12345", must_change=False, branch_id=self.b_nte)

        self.adm = self.app.test_client()
        self.cSjo = self.app.test_client()
        self.cNte = self.app.test_client()

        self.adm.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
        self.cSjo.post("/api/login", json={"username": "caja_sjo", "password": "Caja12345"})
        self.cNte.post("/api/login", json={"username": "caja_nte", "password": "Caja12345"})

        # Producto de prueba con stock inicial 10 en San José y 0 en Norte
        self.adm.post("/api/products", json={
            "name": "Vestido Primavera", "price": 800, "cost": 400, "branch_id": self.b_sjo,
            "variants": [{"sku": "VP-ROSA-CH", "size": "CH", "color": "Rosa", "stock": 10}]
        })
        self.vid = self.adm.get("/api/products").get_json()["products"][0]["variants"][0]["id"]

    def test_flujo_completo_traspaso_autorizado_y_discrepancia(self):
        # 1. Sucursal Norte solicita 4 prendas a San José
        r_sol = self.cNte.post("/api/transfers", json={
            "origin_branch_id": self.b_sjo,
            "dest_branch_id": self.b_nte,
            "items": [{"variant_id": self.vid, "qty": 4}],
            "notes": "Surtido fin de semana"
        }).get_json()
        tid = r_sol["id"]

        # Stock en origen aún no se descuenta
        self.assertEqual(self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 10)

        # 2. Administradora autoriza el traspaso
        self.assertEqual(self.adm.post(f"/api/transfers/{tid}/authorize", json={}).status_code, 200)

        # 3. San José despacha: el inventario sale de San José
        self.assertEqual(self.cSjo.post(f"/api/transfers/{tid}/ship", json={}).status_code, 200)
        self.assertEqual(self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 6)
        # Sucursal Norte aún no lo recibe (está en tránsito)
        self.assertEqual(self.cNte.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 0)

        # 4. Sucursal Norte recibe con discrepancia (recibe 3 en vez de 4 porque 1 se dañó en camino)
        res_rcv = self.cNte.post(f"/api/transfers/{tid}/receive", json={
            "items": [{"variant_id": self.vid, "qty": 3}]
        }).get_json()
        self.assertTrue(res_rcv["ok"])
        self.assertEqual(len(res_rcv["discrepancies"]), 1)

        # El inventario físico en Norte sube a 3
        self.assertEqual(self.cNte.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 3)
        # Consolidado total es 9 (6 en San José + 3 en Norte)
        self.assertEqual(self.adm.get("/api/products").get_json()["products"][0]["variants"][0]["consolidated_stock"], 9)

    def test_apartado_reserva_stock_abonos_y_entrega(self):
        # 1. Abrir caja en San José
        self.cSjo.post("/api/cash/open", json={"opening": 500})

        # 2. Crear apartado de 2 prendas ($1,600 total) con anticipo de $500
        r_ap = self.cSjo.post("/api/layaways", json={
            "customer_name": "Laura Méndez", "customer_phone": "3229876543",
            "items": [{"variant_id": self.vid, "qty": 2}],
            "deposit": 500, "method": "efectivo"
        }).get_json()
        lid = r_ap["id"]

        # Stock físico sigue en 10, pero disponible baja a 8 (2 reservadas)
        v_check = self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual(v_check["stock"], 10)
        self.assertEqual(v_check["reserved"], 2)
        self.assertEqual(v_check["available"], 8)

        # Intento de venta que supere el disponible (pedir 9 cuando quedan 8 disponibles) falla
        r_sale_fail = self.cSjo.post("/api/sales", json={
            "idempotency_key": "llave-ap-bloqueo",
            "items": [{"variant_id": self.vid, "qty": 9}],
            "payments": [{"method": "efectivo", "amount": 7200, "received": 7200}]
        })
        self.assertEqual(r_sale_fail.status_code, 409)

        # 3. Abono de $600
        self.cSjo.post(f"/api/layaways/{lid}/payments", json={"amount": 600, "method": "efectivo"})
        # 4. Abono final de $500 (liquidación completa)
        self.cSjo.post(f"/api/layaways/{lid}/payments", json={"amount": 500, "method": "efectivo"})

        # 5. Entrega de mercancía: descuenta el físico (10 -> 8) y libera la reserva (2 -> 0)
        self.assertEqual(self.cSjo.post(f"/api/layaways/{lid}/deliver", json={}).status_code, 200)

        v_final = self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual(v_final["stock"], 8)
        self.assertEqual(v_final["reserved"], 0)
        self.assertEqual(v_final["available"], 8)

    def test_devolucion_parcial_por_partida(self):
        # 1. Venta de 2 prendas
        self.cSjo.post("/api/cash/open", json={"opening": 500})
        sale_res = self.cSjo.post("/api/sales", json={
            "idempotency_key": "llave-venta-dev-parcial",
            "items": [{"variant_id": self.vid, "qty": 2}],
            "payments": [{"method": "efectivo", "amount": 1600, "received": 1600}]
        }).get_json()
        sid = sale_res["id"]
        self.assertEqual(self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 8)

        # Detalle de la venta para obtener sale_item_id
        s_detail = self.cSjo.get(f"/api/sales/{sid}").get_json()
        si_id = s_detail["items"][0]["id"] if "id" in s_detail["items"][0] else 1

        # 2. Devolución parcial de 1 sola prenda
        admin_creds = {"username": "marcela", "password": "Admin12345"}
        ref_res = self.cSjo.post(f"/api/sales/{sid}/refund", json={
            "items": [{"sale_item_id": si_id, "qty": 1}],
            "reason": "Cliente cambió por otra talla",
            "method": "efectivo",
            "authorizer": admin_creds
        })
        self.assertEqual(ref_res.status_code, 201)
        self.assertEqual(ref_res.get_json()["refund_total"], 800.0)

        # Stock vuelve a 9
        self.assertEqual(self.cSjo.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 9)

        # Reembolso registrado en caja
        c_sum = self.cSjo.get("/api/cash/summary").get_json()
        self.assertEqual(c_sum["salidas"], 800.0)

    def test_etiqueta_codigo_barras_svg(self):
        r = self.cSjo.get(f"/api/variants/{self.vid}/label.html")
        self.assertEqual(r.status_code, 200)
        html = r.get_data(as_text=True)
        self.assertIn("Marcela Boutique", html)
        self.assertIn("<svg", html)
        self.assertIn("VP-ROSA-CH", html)

if __name__ == "__main__":
    unittest.main()