import sys, os, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from app import create_app
import db
from auth import create_user
app = create_app(os.path.join(tempfile.mkdtemp(), "ui.db"))
with app.app_context():
    con = db.get_db()
    with con:
        create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
        create_user(con, "caja1", "Cajera Uno", "cajero", "Caja12345", must_change=False)
c = app.test_client(); c.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
c.post("/api/products", json={"name": "Blusa Alba", "category": "Ropa", "cost": 180, "price": 389, "variants": [{"sku": "BLU-M", "size": "M", "color": "Marfil", "stock": 5, "min_stock": 1}, {"sku": "BLU-G", "size": "G", "color": "Marfil", "stock": 2}]})
app.run(host="127.0.0.1", port=5055)
