const {JSDOM}=require("jsdom");const base="http://127.0.0.1:5055";
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const jar=()=>{let c="";return async(u,o={})=>{const r=await fetch(new URL(u,base),{...o,headers:{...(o.headers||{}),cookie:c}});const sc=r.headers.getSetCookie();if(sc.length)c=sc.map(x=>x.split(";")[0]).join("; ");return r}};
const post=(f,u,b)=>f(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});
let fails=0;const ok=(c,m)=>{console.log((c?"OK   ":"FALLA ")+m);if(!c)fails++};
(async()=>{
 const k=jar();await post(k,"/api/login",{username:"caja1",password:"Caja12345"});await post(k,"/api/cash/open",{opening:300});await post(k,"/api/cash/close",{counted:290});
 const f=jar(),errs=[];const html=await(await fetch(base+"/")).text();
 const dom=new JSDOM(html,{runScripts:"dangerously",resources:"usable",url:base+"/",pretendToBeVisual:true,virtualConsole:new (require("jsdom").VirtualConsole)().on("jsdomError",e=>errs.push(e.message)),beforeParse(w){w.fetch=f}});
 const w=dom.window,d=w.document,$=i=>d.getElementById(i),click=el=>el.dispatchEvent(new w.MouseEvent("click",{bubbles:true}));
 await sleep(1500);$("lu").value="marcela";$("lp").value="Admin12345";click($("lb"));await sleep(600);
 click(d.querySelector('[data-v="caja"]'));await sleep(600);
 ok(!$("hist").hidden&&$("histList").textContent.includes("caja1")&&$("histList").textContent.includes("-$10.00"),"administradora ve historial con diferencia -$10.00");
 click(d.querySelector("[data-s]"));await sleep(500);ok(!$("infoModal").hidden&&$("infoBody").textContent.includes("Efectivo contado"),"botón Ver abre el detalle de la caja");
 console.log(errs.length?"ERRORES JS: "+errs.join("|"):"sin errores de JS");process.exit(fails||errs.length?1:0)})();
