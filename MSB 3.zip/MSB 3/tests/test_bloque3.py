import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

ADMIN = {"username": "marcela", "password": "Admin12345"}
class B3(unittest.TestCase):
    def setUp(self):
        self.app = create_app(os.path.join(tempfile.mkdtemp(), "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "Caja Uno", "cajero", "Caja12345", must_change=False)
                create_user(con, "caja2", "Caja Dos", "cajero", "Caja12345", must_change=False)
        self.a, self.k, self.k2 = (self.app.test_client() for _ in range(3))
        self.a.post("/api/login", json=ADMIN)
        self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.k2.post("/api/login", json={"username": "caja2", "password": "Caja12345"})
        self.a.post("/api/products", json={"name": "Blusa", "cost": 180, "price": 389, "variants": [{"sku": "B-M", "size": "M", "stock": 5}, {"sku": "B-G", "size": "G", "stock": 1}]})
    def stock(self, vid=1):
        with self.app.app_context(): return db.get_db().execute("SELECT stock FROM variants WHERE id=?", (vid,)).fetchone()[0]
    def sale(self, qty=2, key="llave-0001", c=None, **kw):
        body = {"idempotency_key": key, "items": [{"variant_id": 1, "qty": qty, "price": 1}], "payments": [{"method": "efectivo", "amount": 389 * qty, "received": 1000}]}
        body.update(kw); return (c or self.k).post("/api/sales", json=body)

    def test_exige_caja_abierta(self): self.assertEqual(self.sale().status_code, 409)
    def test_venta_completa_cambio_y_stock(self):
        self.k.post("/api/cash/open", json={"opening": 500})
        r = self.sale(); j = r.get_json()
        self.assertEqual((r.status_code, j["total"], j["change"]), (201, 778, 222)); self.assertEqual(self.stock(), 3)  # precio del cliente ignorado
        html = self.k.get(f"/api/sales/{j['id']}/receipt.html").get_data(as_text=True)
        self.assertIn("MB-000001", html); self.assertIn("$778.00", html)
    def test_idempotencia_no_descuenta_dos_veces(self):
        self.k.post("/api/cash/open", json={"opening": 0})
        self.assertEqual(self.sale().status_code, 201); r2 = self.sale()
        self.assertTrue(r2.get_json()["duplicate"]); self.assertEqual(self.stock(), 3)
        self.assertEqual(len(self.k.get("/api/sales").get_json()["sales"]), 1)
    def test_sin_existencia_no_guarda_nada(self):
        self.k.post("/api/cash/open", json={"opening": 0})
        r = self.k.post("/api/sales", json={"idempotency_key": "llave-0002", "items": [{"variant_id": 1, "qty": 1}, {"variant_id": 2, "qty": 3}],
                                           "payments": [{"method": "tarjeta", "amount": 1556}]})
        self.assertEqual(r.status_code, 409); self.assertEqual((self.stock(1), self.stock(2)), (5, 1))
        self.assertEqual(self.k.get("/api/sales").get_json()["sales"], [])
    def test_pagos_deben_sumar_total(self):
        self.k.post("/api/cash/open", json={"opening": 0})
        self.assertEqual(self.sale(payments=[{"method": "efectivo", "amount": 700}]).status_code, 400)
        self.assertEqual(self.sale(payments=[{"method": "cripto", "amount": 778}]).status_code, 400)
    def test_descuento_requiere_autorizacion(self):
        self.k.post("/api/cash/open", json={"opening": 0})
        pay = [{"method": "tarjeta", "amount": 678}]
        self.assertEqual(self.sale(discount=100, payments=pay, key="llave-0003").status_code, 403)
        bad = {"username": "marcela", "password": "mal"}
        self.assertEqual(self.sale(discount=100, payments=pay, key="llave-0004", authorizer=bad).status_code, 403)
        self.assertEqual(self.sale(discount=100, payments=pay, key="llave-0005", authorizer=ADMIN).status_code, 201)
        self.assertEqual(self.sale(discount=50, payments=[{"method": "tarjeta", "amount": 728}], key="llave-0006").status_code, 201)
    def test_cancelacion_con_autorizacion_restaura_stock(self):
        self.k.post("/api/cash/open", json={"opening": 0}); sid = self.sale().get_json()["id"]
        self.assertEqual(self.k.post(f"/api/sales/{sid}/cancel", json={"reason": "cliente se arrepintió"}).status_code, 403)
        self.assertEqual(self.k.post(f"/api/sales/{sid}/cancel", json={"reason": "x", "authorizer": ADMIN}).status_code, 400)
        r = self.k.post(f"/api/sales/{sid}/cancel", json={"reason": "cliente se arrepintió", "authorizer": ADMIN})
        self.assertEqual(r.status_code, 200); self.assertEqual(self.stock(), 5)
        self.assertEqual(self.a.post(f"/api/sales/{sid}/cancel", json={"reason": "otra vez va"}).status_code, 409); self.assertEqual(self.stock(), 5)
    def test_cajero_solo_ve_sus_ventas(self):
        self.k.post("/api/cash/open", json={"opening": 0}); sid = self.sale().get_json()["id"]
        self.assertEqual(self.k2.get(f"/api/sales/{sid}").status_code, 404)
        self.assertEqual(self.a.get(f"/api/sales/{sid}").status_code, 200)

if __name__ == "__main__": unittest.main()
