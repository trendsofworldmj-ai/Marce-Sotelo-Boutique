import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

PROD = {"name": "Blusa Alba", "category": "Ropa", "cost": 180, "price": 389,
        "variants": [{"size": "M", "color": "Marfil", "sku": "blu-m", "barcode": "750100", "stock": 3, "min_stock": 2},
                     {"size": "G", "color": "Marfil", "sku": "blu-g", "stock": 1}]}

class B7(unittest.TestCase):
    def setUp(self):
        self.app = create_app(os.path.join(tempfile.mkdtemp(), "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "M", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "C", "cajero", "Caja12345", must_change=False)
        self.a, self.k = self.app.test_client(), self.app.test_client()
        self.a.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
        self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.pid = self.a.post("/api/products", json=PROD).get_json()["id"]
        self.vs = self.a.get("/api/products").get_json()["products"][0]["variants"]

    def test_editar_variante(self):
        v = self.vs[0]["id"]
        r = self.a.patch(f"/api/variants/{v}", json={"size": "L", "barcode": "999", "min_stock": 5})
        self.assertEqual(r.status_code, 200)
        got = self.a.get("/api/products").get_json()["products"][0]["variants"][0]
        self.assertEqual((got["size"], got["barcode"], got["min_stock"]), ("L", "999", 5))

    def test_variante_sku_duplicado_vacio_y_permiso(self):
        v = self.vs[0]["id"]
        self.assertEqual(self.a.patch(f"/api/variants/{v}", json={"sku": "BLU-G"}).status_code, 409)
        self.assertEqual(self.a.patch(f"/api/variants/{v}", json={"sku": "  "}).status_code, 400)
        self.assertEqual(self.a.patch(f"/api/variants/9999", json={"size": "X"}).status_code, 404)
        self.assertEqual(self.k.patch(f"/api/variants/{v}", json={"size": "X"}).status_code, 403)

    def test_variante_inactiva_no_se_vende_ni_se_lista(self):
        v = self.vs[0]["id"]
        self.assertEqual(self.a.patch(f"/api/variants/{v}", json={"active": False}).status_code, 200)
        ids = lambda c, q="": [x["id"] for x in c.get("/api/products" + q).get_json()["products"][0]["variants"]]
        self.assertNotIn(v, ids(self.k)); self.assertNotIn(v, ids(self.a))
        self.assertIn(v, ids(self.a, "?all=1"))
        self.assertNotIn(v, ids(self.k, "?all=1"))          # la cajera no puede pedir inactivos
        self.k.post("/api/cash/open", json={"opening": 0})
        r = self.k.post("/api/sales", json={"idempotency_key": "clave-inactiva-1", "items": [{"variant_id": v, "qty": 1}],
                                            "payments": [{"method": "efectivo", "amount": 389}]})
        self.assertEqual(r.status_code, 400)
        low = [x["id"] for x in self.a.get("/api/inventory/low").get_json()["low"]]
        self.assertNotIn(v, low)

    def test_validacion_de_tipos_no_produce_500(self):
        bad = dict(PROD, name="X", category=["a"])
        self.assertEqual(self.a.post("/api/products", json=bad).status_code, 400)
        bad = dict(PROD, name="Y", image="http://evil.example/x.png")
        self.assertEqual(self.a.post("/api/products", json=bad).status_code, 400)
        self.assertEqual(self.a.post("/api/products", json=dict(PROD, name="Z", variants=["x"])).status_code, 400)
        self.assertEqual(self.a.patch(f"/api/products/{self.pid}", json={"name": "  "}).status_code, 400)
        self.assertEqual(self.a.patch(f"/api/products/{self.pid}", json={"brand": {"a": 1}}).status_code, 400)
        ok = self.a.post("/api/products", json=dict(PROD, name="W", image="/static/logo.jpg", variants=[{"sku": "W-1"}]))
        self.assertEqual(ok.status_code, 201)

    def test_ajuste_fuera_de_rango(self):
        v = self.vs[0]["id"]
        r = self.a.post(f"/api/variants/{v}/adjust", json={"delta": 10**12, "reason": "prueba grande"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.a.get("/api/products").get_json()["products"][0]["variants"][0]["stock"], 3)

    def test_movimientos_incluyen_sku_y_cabeceras(self):
        m = self.a.get("/api/inventory/movements").get_json()["movements"]
        self.assertTrue(all(x["sku"] for x in m))
        r = self.a.get("/api/products")
        self.assertEqual(r.headers["Cache-Control"], "no-store"); self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertIn("frame-ancestors 'none'", r.headers["Content-Security-Policy"])

    def test_cajero_no_ve_costo_en_listados(self):
        self.assertNotIn("cost", self.k.get("/api/products").get_json()["products"][0])
        self.assertEqual(self.k.get("/api/inventory/movements").status_code, 403)

if __name__ == "__main__":
    unittest.main()
