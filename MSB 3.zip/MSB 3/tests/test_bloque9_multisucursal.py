import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user


class B9Migracion(unittest.TestCase):
    """Incremento 1 (aditivo) de la arquitectura multisucursal: branches, variant_stock,
    transfers y columnas branch_id. No debe alterar ni perder nada de lo existente."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.path = os.path.join(self.tmp, "t.db")

    def test_migracion_sobre_base_nueva_crea_tablas(self):
        app = create_app(self.path)
        with app.app_context():
            con = db.get_db()
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for t in ("branches", "variant_stock", "transfers", "transfer_items", "transfer_events"):
                self.assertIn(t, tables)
            for t in ("users", "cash_sessions", "sales", "purchases", "expenses", "inventory_movements"):
                cols = {r[1] for r in con.execute(f"PRAGMA table_info({t})")}
                self.assertIn("branch_id", cols)

    def test_migracion_sobre_base_existente_preserva_datos(self):
        # 1) Simula una instalación YA en uso, con datos reales, antes de este incremento.
        app1 = create_app(self.path)
        with app1.app_context():
            con = db.get_db()
            with con:
                uid = create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                con.execute("INSERT INTO products(name, price_cents) VALUES ('Blusa', 38900)")
                con.execute(
                    "INSERT INTO variants(product_id, sku, size, color, stock) VALUES (1, 'BLU-M-MAR', 'M', 'Marfil', 7)"
                )

        # 2) "Reinicia la app": init_app corre de nuevo sobre la misma base.
        app2 = create_app(self.path)
        with app2.app_context():
            con = db.get_db()
            u = con.execute("SELECT * FROM users WHERE username='marcela'").fetchone()
            self.assertEqual(u["id"], uid)
            self.assertIsNone(u["branch_id"])
            v = con.execute("SELECT * FROM variants WHERE sku='BLU-M-MAR'").fetchone()
            self.assertEqual(v["stock"], 7)
            self.assertIn(con.execute("SELECT COUNT(*) FROM branches").fetchone()[0], (0, 1))
            self.assertIn(con.execute("SELECT COUNT(*) FROM variant_stock").fetchone()[0], (0, 1))

        # 3) Re-ejecutar la migración una tercera vez es inofensivo (ALTER TABLE no se repite, no hay error).
        app3 = create_app(self.path)
        with app3.app_context():
            con = db.get_db()
            self.assertEqual(con.execute("SELECT COUNT(*) FROM users").fetchone()[0], 1)

    def test_transfer_origen_destino_distintos(self):
        import sqlite3
        app = create_app(self.path)
        with app.app_context():
            con = db.get_db()
            with con:
                con.execute("INSERT INTO branches(code, name, kind) VALUES ('MTZ','Maestra','maestra')")
                con.execute("INSERT INTO branches(code, name, kind) VALUES ('A','Sucursal A','operativa')")
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute(
                    "INSERT INTO transfers(folio, origin_branch_id, dest_branch_id) VALUES ('T-000001', 2, 2)"
                )


if __name__ == "__main__":
    unittest.main()
