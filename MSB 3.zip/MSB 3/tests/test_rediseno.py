import os, re, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Rediseno(unittest.TestCase):
    def setUp(self): self.c = create_app(os.path.join(tempfile.mkdtemp(), "t.db")).test_client()

    def test_recursos_locales_se_sirven(self):
        h = self.c.get("/").get_data(as_text=True)
        refs = re.findall(r'(?:src|href)="(/static/[^"]+)"', h)
        self.assertGreaterEqual(len(refs), 14)             # 3 CSS + 11 JS + logos
        for r in refs: self.assertEqual(self.c.get(r).status_code, 200, r)

    def test_sin_dependencias_externas(self):
        """La app debe funcionar sin internet: ningún recurso http(s) externo en plantillas, CSS ni JS."""
        pat = re.compile(r"""(?:src|href)=["']https?://|url\(\s*["']?https?://|@import\s+["']?https?://|\bfrom\s+["']https?://""")
        for base, _, files in os.walk(ROOT):
            if any(x in base for x in ("node_modules", "__pycache__", ".git", "instance")): continue
            for f in files:
                if f.endswith((".html", ".css", ".js")) and "tests" not in base:
                    self.assertIsNone(pat.search(open(os.path.join(base, f), encoding="utf-8").read()), os.path.join(base, f))

    def test_menu_y_vistas_completas(self):
        h = self.c.get("/").get_data(as_text=True)
        for v in ("pos", "caja", "prod", "comp", "gas", "rep", "aud", "usr", "resp"):
            self.assertIn(f'data-v="{v}"', h)
        for vid in ("vPos", "vCaja", "vProd", "vComp", "vGas", "vRep", "vAud", "vUsr", "vResp"): self.assertIn(f'id="{vid}"', h)
        # las funciones de gestión llevan data-admin; Caja rápida y Caja no
        for v in ("pos", "caja"): self.assertNotRegex(h, rf'data-v="{v}"[^>]*data-admin')
        for v in ("prod", "comp", "gas", "rep", "aud", "usr", "resp"): self.assertRegex(h, rf'data-v="{v}"[^>]*data-admin')

    def test_cabeceras_de_seguridad_intactas(self):
        r = self.c.get("/"); csp = r.headers["Content-Security-Policy"]
        self.assertIn("default-src 'self'", csp); self.assertNotIn("http", csp.replace("https:", "") .split("img-src")[0])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY"); self.assertEqual(r.headers["Cache-Control"], "no-store")

    def test_tokens_definidos_y_usados(self):
        css = open(os.path.join(ROOT, "static/css/tokens.css")).read(); used = ""
        for f in ("components.css", "layout.css"): used += open(os.path.join(ROOT, "static/css", f)).read()
        defined = set(re.findall(r"(--[a-z0-9-]+)\s*:", css))
        for v in set(re.findall(r"var\((--[a-z0-9-]+)", used)): self.assertIn(v, defined, f"variable sin definir: {v}")

if __name__ == "__main__": unittest.main()
