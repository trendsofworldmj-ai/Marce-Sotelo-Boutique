import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

class B12InterfazMultisucursal(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.app = create_app(os.path.join(self.tmp, "t.db"))
        self.c = self.app.test_client()

    def test_vistas_multisucursal_renderizadas(self):
        html = self.c.get("/").get_data(as_text=True)
        # Verificar que existen las vistas nuevas en el DOM
        self.assertIn('id="vTransf"', html)
        self.assertIn('id="vApart"', html)
        self.assertIn('id="vSuc"', html)
        # Verificar los botones del menú de navegación
        self.assertIn('data-v="transf"', html)
        self.assertIn('data-v="apart"', html)
        self.assertIn('data-v="suc"', html)
        # Verificar el chip de sucursal
        self.assertIn('id="branchChip"', html)
        # Verificar que los scripts se sirven sin 404
        for mod in ["modules/sucursales", "modules/traspasos", "modules/apartados"]:
            self.assertIn(f"{mod}.js", html)
            res = self.c.get(f"/static/js/{mod}.js")
            self.assertEqual(res.status_code, 200, f"No se pudo cargar {mod}.js")

    def test_sin_dependencias_remotas_en_vistas_nuevas(self):
        # Regla inviolable: la aplicación debe funcionar 100% desconectada de Internet
        for fname in ["suc.html", "transf.html", "apart.html"]:
            p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "templates", "partials", "views", fname)
            content = open(p, encoding="utf-8").read()
            self.assertNotIn("http://", content)
            self.assertNotIn("https://", content)

if __name__ == "__main__":
    unittest.main()