import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

ADMIN = {"username": "marcela", "password": "Admin12345"}
class B4(unittest.TestCase):
    def setUp(self):
        self.app = create_app(os.path.join(tempfile.mkdtemp(), "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "Caja Uno", "cajero", "Caja12345", must_change=False)
                create_user(con, "caja2", "Caja Dos", "cajero", "Caja12345", must_change=False)
        self.a, self.k, self.k2 = (self.app.test_client() for _ in range(3))
        self.a.post("/api/login", json=ADMIN)
        self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.k2.post("/api/login", json={"username": "caja2", "password": "Caja12345"})
        self.a.post("/api/products", json={"name": "Blusa", "cost": 180, "price": 389, "variants": [{"sku": "B-M", "stock": 20}]})
        self.n = 0
    def sell(self, method="efectivo", qty=2):
        self.n += 1; amt = 389 * qty
        p = {"method": method, "amount": amt}; 
        if method == "efectivo": p["received"] = amt
        return self.k.post("/api/sales", json={"idempotency_key": f"llave-{self.n:04d}", "items": [{"variant_id": 1, "qty": qty}], "payments": [p]}).get_json()["id"]
    def summ(self, c=None): return (c or self.k).get("/api/cash/summary").get_json()

    def test_esperado_incluye_fondo_efectivo_entradas_salidas(self):
        self.k.post("/api/cash/open", json={"opening": 500}); self.sell(); self.sell("tarjeta")
        s = self.summ(); self.assertEqual((s["expected"], s["sales_total"], s["sales_by_method"]["tarjeta"], s["cash_collected"]), (1278, 1556, 778, 778))
        self.assertEqual(self.k.post("/api/cash/movements", json={"kind": "salida", "amount": 100, "reason": "pago de paquetería"}).status_code, 201)
        self.k.post("/api/cash/movements", json={"kind": "entrada", "amount": 50, "reason": "cambio extra del banco"})
        self.assertEqual(self.summ()["expected"], 1228)
    def test_validaciones_de_movimientos(self):
        self.assertEqual(self.a.post("/api/cash/movements", json={"kind": "salida", "amount": 1, "reason": "sin caja abierta"}).status_code, 409)
        self.k.post("/api/cash/open", json={"opening": 100})
        for body in ({"kind": "salida", "amount": 400, "reason": "mayor al efectivo"}, {"kind": "salida", "amount": 10, "reason": "x"}, {"kind": "otro", "amount": 10, "reason": "tipo inválido"}):
            self.assertEqual(self.k.post("/api/cash/movements", json=body).status_code, 400)
    def test_cancelacion_en_efectivo_genera_reembolso_sin_doble_descuento(self):
        self.k.post("/api/cash/open", json={"opening": 500}); sid = self.sell()
        self.assertEqual(self.k.post(f"/api/sales/{sid}/cancel", json={"reason": "cliente devolvió", "authorizer": ADMIN}).status_code, 200)
        s = self.summ(); self.assertEqual((s["expected"], s["cancelled"]["count"], s["sales_total"], s["salidas"]), (500, 1, 0, 778))
    def test_cancelar_venta_en_efectivo_exige_caja_abierta(self):
        self.k.post("/api/cash/open", json={"opening": 0}); sid = self.sell()
        self.k.post("/api/cash/close", json={"counted": 778})
        self.assertEqual(self.k.post(f"/api/sales/{sid}/cancel", json={"reason": "cliente devolvió", "authorizer": ADMIN}).status_code, 409)
        self.k.post("/api/cash/open", json={"opening": 0})
        self.assertEqual(self.k.post(f"/api/sales/{sid}/cancel", json={"reason": "cliente devolvió", "authorizer": ADMIN}).status_code, 200)
        self.assertEqual(self.summ()["expected"], -778)  # el reembolso salió de esta caja aunque la venta fue de otra sesión
    def test_cierre_con_diferencia_y_sin_reabrir(self):
        self.k.post("/api/cash/open", json={"opening": 500}); self.sell()
        r = self.k.post("/api/cash/close", json={"counted": 1258}).get_json()
        self.assertEqual((r["expected"], r["counted"], r["difference"], r["status"]), (1278, 1258, -20, "cerrada"))
        self.assertEqual(self.k.post("/api/cash/close", json={"counted": 1}).status_code, 409)
        self.assertEqual(self.k.post("/api/sales", json={"idempotency_key": "llave-9999", "items": [{"variant_id": 1, "qty": 1}], "payments": [{"method": "tarjeta", "amount": 389}]}).status_code, 409)
        self.assertEqual(self.a.get("/api/cash/sessions").get_json()["sessions"][0]["difference"], -20)
    def test_permisos_de_consulta(self):
        self.k.post("/api/cash/open", json={"opening": 0})
        self.assertEqual(self.k2.get("/api/cash/summary?session_id=1").status_code, 404)
        self.assertEqual(self.a.get("/api/cash/summary?session_id=1").status_code, 200)
        self.assertEqual(self.k.get("/api/cash/sessions").status_code, 403)

if __name__ == "__main__": unittest.main()
