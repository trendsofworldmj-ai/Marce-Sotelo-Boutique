import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

ADMIN = {"username": "marcela", "password": "Admin12345"}
class B6A(unittest.TestCase):
    def setUp(self):
        self.app = create_app(os.path.join(tempfile.mkdtemp(), "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "Caja", "cajero", "Caja12345", must_change=False)
        self.a, self.k = self.app.test_client(), self.app.test_client()
        self.a.post("/api/login", json=ADMIN); self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.a.post("/api/products", json={"name": "Blusa", "cost": 100, "price": 389, "variants": [{"sku": "B-M", "stock": 20}]})
        self.k.post("/api/cash/open", json={"opening": 0}); self.n = 0
    def sell(self, qty, method):
        self.n += 1; p = {"method": method, "amount": 389 * qty}
        if method == "efectivo": p["received"] = 389 * qty
        return self.k.post("/api/sales", json={"idempotency_key": f"llave-{self.n:04d}", "items": [{"variant_id": 1, "qty": qty}], "payments": [p]}).get_json()["id"]
    def scenario(self):
        self.sell(2, "efectivo"); self.sell(1, "tarjeta"); c = self.sell(1, "efectivo")
        self.k.post(f"/api/sales/{c}/cancel", json={"reason": "cliente devolvió", "authorizer": ADMIN})
        self.a.post("/api/expenses", json={"concept": "Renta", "category": "Renta", "amount": 150})
        sup = self.a.post("/api/suppliers", json={"name": "Mayoreo"}).get_json()["id"]
        pid = self.a.post("/api/purchases", json={"supplier_id": sup, "items": [{"variant_id": 1, "qty": 5, "cost": 100}]}).get_json()["id"]
        self.a.post(f"/api/purchases/{pid}/receive", json={}); self.a.post(f"/api/purchases/{pid}/payments", json={"amount": 200, "method": "transferencia"})

    def test_resumen_financiero(self):
        self.scenario(); r = self.a.get("/api/reports/summary").get_json()
        self.assertEqual((r["sales"]["count"], r["sales"]["total"], r["sales"]["avg_ticket"]), (2, 1167, 583.5))
        self.assertEqual(r["sales"]["by_method"], {"efectivo": 778, "tarjeta": 389}); self.assertEqual(r["sales"]["cancelled"], {"count": 1, "total": 389})
        self.assertEqual((r["profit"]["cogs"], r["profit"]["gross_profit"], r["profit"]["gross_margin_pct"], r["profit"]["net"]), (300, 867, 74.3, 717))
        self.assertEqual((r["cash_flow"]["net"], r["purchases"]["supplier_balance_total"], r["purchases"]["received_total"]), (817, 300, 500))
        self.assertEqual((r["inventory"]["value_at_cost"], r["inventory"]["value_at_price"]), (2200, 8558))
    def test_top_productos_y_dias(self):
        self.scenario(); p = self.a.get("/api/reports/top-products").get_json()["products"][0]
        self.assertEqual((p["name"], p["units"], p["revenue"], p["profit"]), ("Blusa", 3, 1167, 867))
        d = self.a.get("/api/reports/sales-by-day").get_json()["days"]; self.assertEqual((len(d), d[0]["count"], d[0]["total"]), (1, 2, 1167))
    def test_filtro_de_fechas_y_validacion(self):
        self.scenario(); r = self.a.get("/api/reports/summary?from=2999-01-01&to=2999-12-31").get_json()
        self.assertEqual((r["sales"]["count"], r["profit"]["net"], r["profit"]["gross_margin_pct"]), (0, 0, 0))
        for q in ("from=hoy", "from=2026-12-01&to=2026-01-01"): self.assertEqual(self.a.get(f"/api/reports/summary?{q}").status_code, 400)
    def test_solo_admin_y_auditoria(self):
        self.scenario()
        for u in ("/api/reports/summary", "/api/reports/top-products", "/api/reports/sales-by-day", "/api/audit"): self.assertEqual(self.k.get(u).status_code, 403)
        ev = self.a.get("/api/audit?action=venta").get_json()["events"]; self.assertEqual((len(ev), ev[0]["username"]), (3, "caja1"))
        self.assertGreater(len(self.a.get("/api/audit?user=marcela&limit=5").get_json()["events"]), 0)

if __name__ == "__main__": unittest.main()
