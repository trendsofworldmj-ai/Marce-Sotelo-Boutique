import os, sqlite3, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user
from inventory import move_stock, StockError

BLUSA = {"name": "Blusa Alba", "category": "Ropa", "cost": 180, "price": 389,
         "variants": [{"size": "M", "color": "Marfil", "sku": "blu-m", "barcode": "750100", "stock": 3, "min_stock": 2},
                      {"size": "G", "color": "Marfil", "stock": 1}]}

class B2(unittest.TestCase):
    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(), "t.db"); self.app = create_app(self.path)
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "M", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "C", "cajero", "Caja12345", must_change=False)
        self.a, self.k = self.app.test_client(), self.app.test_client()
        self.a.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
        self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.pid = self.a.post("/api/products", json=BLUSA).get_json()["id"]

    def test_alta_con_variantes_y_movimiento_inicial(self):
        p = self.a.get("/api/products").get_json()["products"][0]
        self.assertEqual([v["stock"] for v in p["variants"]], [3, 1]); self.assertEqual(p["cost"], 180)
        self.assertEqual(p["variants"][1]["sku"], f"P{self.pid}-G-MARFIL")
        self.assertEqual(len(self.a.get("/api/inventory/movements").get_json()["movements"]), 2)
    def test_cajero_no_ve_costo_ni_crea(self):
        p = self.k.get("/api/products").get_json()["products"][0]; self.assertNotIn("cost", p)
        self.assertEqual(self.k.post("/api/products", json=BLUSA).status_code, 403)
        self.assertEqual(self.k.post("/api/variants/1/adjust", json={"delta": 5, "reason": "intento"}).status_code, 403)
    def test_busqueda_por_nombre_sku_barcode(self):
        for q in ("alba", "BLU-M", "750100"): self.assertEqual(len(self.k.get(f"/api/products?q={q}").get_json()["products"]), 1)
        self.assertEqual(len(self.k.get("/api/products?q=zzz").get_json()["products"]), 0)
    def test_ajuste_exige_motivo_y_no_permite_negativos(self):
        self.assertEqual(self.a.post("/api/variants/1/adjust", json={"delta": -1, "reason": "x"}).status_code, 400)
        self.assertEqual(self.a.post("/api/variants/1/adjust", json={"delta": -9, "reason": "merma por daño"}).status_code, 400)
        self.assertEqual(self.a.post("/api/variants/1/adjust", json={"delta": -2, "reason": "merma por daño"}).get_json()["stock"], 1)
    def test_move_stock_atomico(self):
        with self.app.app_context():
            con = db.get_db()
            with self.assertRaises(StockError): move_stock(con, 1, "venta", -99, "t", 1)
            self.assertEqual(con.execute("SELECT stock FROM variants WHERE id=1").fetchone()[0], 3)
    def test_sku_duplicado_409_y_baja_logica(self):
        self.assertEqual(self.a.post(f"/api/products/{self.pid}/variants", json={"sku": "BLU-M"}).status_code, 409)
        self.a.patch(f"/api/products/{self.pid}", json={"active": False})
        self.assertEqual(len(self.k.get("/api/products").get_json()["products"]), 0)
    def test_bajo_stock(self):
        self.assertEqual({r["sku"] for r in self.k.get("/api/inventory/low").get_json()["low"]}, {f"P{self.pid}-G-MARFIL"})
    def test_csv_exporta_importa_todo_o_nada(self):
        csv_ok = "producto,categoria,marca,sku,barcode,talla,color,costo,precio,existencia,minimo\nJeans Roma,Pantalones,,JR-5,,5,Azul,300,579,4,1\nJeans Roma,Pantalones,,JR-7,,7,Azul,300,579,2,1\nBlusa Alba,Ropa,,BLU-M,,M,Marfil,180,389,9,2\n"
        r = self.a.post("/api/inventory/import", json={"csv": csv_ok}).get_json()
        self.assertEqual((r["productos"], r["variantes"], r["omitidos"]), (1, 2, ["BLU-M"]))
        bad = "producto,sku,precio,existencia\nA,A1,100,2\nB,B1,abc,1\n"
        self.assertEqual(self.a.post("/api/inventory/import", json={"csv": bad}).status_code, 400)
        self.assertEqual(len(self.a.get("/api/products?q=A1").get_json()["products"]), 0)
        self.assertIn("JR-5", self.a.get("/api/inventory/export.csv").get_data(as_text=True))

if __name__ == "__main__": unittest.main()
