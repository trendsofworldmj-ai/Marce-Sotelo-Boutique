"""Interfaz completa en Chromium real: flujo de la cajera (caja rápida y corte) y pantallas administrativas
(compras, proveedores, gastos, reportes, auditoría, usuarios). Base temporal, datos ficticios.
Uso: python tests/ui_pw/admin.py   (SHOTS=/ruta para guardar capturas de revisión visual)"""
import os, sys, tempfile, threading
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright, expect
from app import create_app
import db
from auth import create_user

app = create_app(os.path.join(tempfile.mkdtemp(), "ui.db"))
with app.app_context():
    con = db.get_db()
    with con:
        create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
        create_user(con, "caja1", "Cajera Uno", "cajero", "Caja12345", must_change=False)
api = app.test_client(); api.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
api.post("/api/products", json={"name": "Blusa Alba", "category": "Ropa", "cost": 180, "price": 389, "variants": [
    {"sku": "BLU-M", "size": "M", "color": "Marfil", "stock": 5, "min_stock": 1}, {"sku": "BLU-G", "size": "G", "color": "Marfil", "stock": 2}]})
stock = lambda: {v["sku"]: v["stock"] for p in api.get("/api/products?all=1").get_json()["products"] for v in p["variants"]}
srv = make_server("127.0.0.1", 5069, app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
URL, SHOTS, ok, fail = "http://127.0.0.1:5069", os.environ.get("SHOTS"), [], []
def check(n, c): (ok if c else fail).append(n); print(("  OK  " if c else " FALLA "), n)
def shot(pg, name):
    if SHOTS: os.makedirs(SHOTS, exist_ok=True); pg.screenshot(path=os.path.join(SHOTS, name + ".png"), full_page=True)
def login(pg, u, p):
    pg.goto(URL); pg.fill("#lu", u); pg.fill("#lp", p); pg.click("#lb"); pg.wait_for_selector("#top:not([hidden])")
def go(pg, v, sel): pg.click(f'#nav [data-v="{v}"]'); pg.wait_for_selector(sel + ":not([hidden])")
def has(pg, sel, text, t=4000):
    try: expect(pg.locator(sel)).to_contain_text(text, timeout=t); return True
    except AssertionError: return False

with sync_playwright() as pw:
    b = pw.chromium.launch(); errs = []
    # ---------- cajera ----------
    ctx = b.new_context(bypass_csp=True, viewport={"width": 1280, "height": 800}); pc = ctx.new_page(); pc.on("pageerror", lambda e: errs.append(str(e)))
    login(pc, "caja1", "Caja12345")
    vis = pc.locator("#nav .nav-item:visible").all_inner_texts()
    check("cajera ve solo Caja rápida, Caja, Apartados y Traspasos en el menú", [t.strip() for t in vis] == ["Caja rápida", "Caja y cortes", "Apartados", "Traspasos"])
    check("cajera: encabezados de grupo vacíos ocultos", pc.locator("#nav .nav-group:visible").count() == 2)
    for u in ["/api/purchases", "/api/suppliers", "/api/expenses", "/api/reports/summary", "/api/audit", "/api/users"]:
        check(f"cajera: {u} prohibido en servidor", pc.evaluate(f"fetch('{u}').then(r=>r.status)") == 403)
    pc.fill("#fondo", "500"); pc.click("#openBtn"); pc.wait_for_selector("#pos:not([hidden])")
    pc.fill("#q", "blu-g"); pc.press("#q", "Enter"); expect(pc.locator("#cartItems")).to_contain_text("Blusa Alba")
    check("lector: Enter con SKU exacto agrega la pieza", has(pc, "#tot", "389"))
    pc.fill("#pays .rc input", "500"); check("cambio calculado ($111)", has(pc, "#payInfo", "111"))
    shot(pc, "01-caja-rapida")
    pc.click("#charge"); pc.wait_for_selector("#doneModal:not([hidden])"); check("venta con folio", has(pc, "#doneInfo", "MB-000001"))
    pc.keyboard.press("Escape"); pc.wait_for_selector("#doneModal", state="hidden"); check("Esc cierra el diálogo", True)
    check("venta aparece en recientes", has(pc, "#sales", "MB-000001"))
    go(pc, "caja", "#vCaja"); check("Caja: esperado $889", has(pc, "#cajaSum", "$889.00"))
    pc.fill("#mvAmt", "9999"); pc.fill("#mvWhy", "exceso"); pc.click("#mvAdd"); check("salida mayor al efectivo se rechaza", has(pc, "#toast", "suficiente"))
    pc.fill("#mvAmt", "100"); pc.fill("#mvWhy", "Paquetería"); pc.click("#mvAdd"); check("salida de $100: esperado $789", has(pc, "#cajaSum", "$789.00"))
    shot(pc, "02-caja")
    pc.fill("#cnt", "780"); pc.click("#closeBtn"); pc.wait_for_selector("#confModal:not([hidden])"); pc.click("#cOk"); pc.wait_for_selector("#closeModal:not([hidden])")
    check("cierre muestra diferencia -$9.00", has(pc, "#closeInfo", "-$9.00")); pc.click("#closeOk")
    check("chip: caja cerrada", has(pc, "#cajaChip", "Caja cerrada"))
    check("cajera no ve historial de cajas", pc.locator("#hist").is_hidden())

    # ---------- administradora ----------
    pa = b.new_context(bypass_csp=True, viewport={"width": 1280, "height": 800}).new_page(); pa.on("pageerror", lambda e: errs.append(str(e)))
    login(pa, "marcela", "Admin12345")
    check("admin ve los 12 destinos del menú", pa.locator("#nav .nav-item:visible").count() == 12)
    go(pa, "caja", "#vCaja"); check("admin ve historial con la diferencia", has(pa, "#histList", "-$9.00"))
    pa.click("#histList [data-s]"); pa.wait_for_selector("#infoModal:not([hidden])"); check("«Ver» abre el detalle de la caja", has(pa, "#infoBody", "Efectivo contado")); pa.click("#infoOk")

    go(pa, "comp", "#vComp"); check("sin compras: estado vacío", has(pa, "#cList", "Aún no hay compras"))
    pa.click("#cNew"); check("sin proveedores no abre la compra", has(pa, "#toast", "registra un proveedor"))
    pa.click('[data-ctab="prov"]'); pa.click("#sNew"); pa.fill("#spN", "Textiles Luna"); pa.fill("#spT", "5551234567"); pa.click("#fOk"); pa.wait_for_selector("#formModal", state="hidden")
    check("proveedor creado", has(pa, "#sList", "Textiles Luna"))
    pa.click('[data-ctab="compras"]'); pa.click("#cNew"); pa.wait_for_selector("#cpS")
    pa.locator(".cp-q").first.fill("10"); pa.locator(".cp-c").first.fill("200"); check("total estimado $2,000", has(pa, "#cpTotal", "$2,000.00"))
    pa.click("#fOk"); pa.wait_for_selector("#formModal", state="hidden"); check("compra pendiente listada", has(pa, "#cList", "pendiente"))
    check("compra pendiente no mueve inventario", stock()["BLU-M"] == 5)
    shot(pa, "03-compras")
    pa.click('[data-pa="recv"]'); pa.wait_for_selector("#confModal:not([hidden])"); pa.click("#cOk"); check("recibida: estado actualizado", has(pa, "#cList", "recibida"))
    check("recibir sube el inventario (5→15)", stock()["BLU-M"] == 15)
    pa.click('[data-pa="pay"]'); pa.fill("#pgA", "500"); pa.click("#fOk"); pa.wait_for_selector("#formModal", state="hidden"); check("pago parcial: saldo $1,500", has(pa, "#cList", "$1,500.00"))
    pa.click('[data-pa="pay"]'); pa.fill("#pgA", "99999"); pa.click("#fOk"); pa.wait_for_function("document.getElementById('fErr').textContent.length>0")
    check("pago mayor al saldo rechazado con mensaje", "saldo" in pa.inner_text("#fErr").lower()); pa.click("#fNo")
    pa.click('[data-pa="view"]'); pa.wait_for_selector("#infoModal:not([hidden])"); check("detalle de compra con pagos", has(pa, "#infoBody", "efectivo")); pa.click("#infoOk")

    go(pa, "gas", "#vGas"); check("gastos: vacío", has(pa, "#gList", "Sin gastos"))
    pa.click("#gNew"); pa.fill("#gxC", "Renta"); pa.fill("#gxK", "Local"); pa.fill("#gxA", "1200"); pa.click("#fOk"); pa.wait_for_selector("#formModal", state="hidden")
    check("gasto registrado con total", has(pa, "#gList", "Renta") and has(pa, "#gKpis", "$1,200.00"))
    pa.click("#gNew"); pa.fill("#gxC", "Sin monto"); pa.click("#fOk"); pa.wait_for_function("document.getElementById('fErr').textContent.length>0")
    check("gasto sin monto: error visible", "monto" in pa.inner_text("#fErr").lower()); pa.click("#fNo")
    shot(pa, "04-gastos")

    go(pa, "rep", "#vRep"); check("reportes: ventas $389", has(pa, "#rBody", "$389.00"))
    check("reportes: utilidad neta = bruta − gastos (1200)", has(pa, "#rBody", "Utilidad neta") and has(pa, "#rBody", "$1,200.00"))
    check("reportes: producto más vendido", has(pa, "#rBody", "Blusa Alba"))
    shot(pa, "05-reportes")
    go(pa, "aud", "#vAud"); check("auditoría: compra recibida", has(pa, "#auList", "Compra recibida"))
    pa.select_option("#auAct", "gasto_registrado"); pa.click("#auApply"); pa.wait_for_function("!document.getElementById('auList').innerText.includes('Compra recibida')")
    check("auditoría: filtro por acción", has(pa, "#auList", "Gasto registrado"))
    shot(pa, "06-auditoria")

    go(pa, "usr", "#vUsr"); check("usuarios: lista", has(pa, "#uList", "Cajera Uno"))
    check("no hay botón para desactivarse a sí misma", pa.locator('#uList tr:has-text("Marcela") [data-u]').count() == 0)
    pa.click("#uNew"); pa.fill("#unN", "Cajera Dos"); pa.fill("#unU", "caja2"); pa.fill("#unP", "corta"); pa.click("#fOk"); pa.wait_for_function("document.getElementById('fErr').textContent.length>0")
    check("contraseña corta rechazada", "8" in pa.inner_text("#fErr")); pa.fill("#unP", "Temporal123"); pa.click("#fOk"); pa.wait_for_selector("#formModal", state="hidden")
    check("usuario creado", has(pa, "#uList", "Cajera Dos"))
    pa.locator('#uList tr:has-text("Cajera Dos") [data-u]').click(); pa.wait_for_selector("#confModal:not([hidden])"); pa.click("#cOk")
    check("usuario desactivado", has(pa, "#uList", "inactivo"))
    shot(pa, "07-usuarios")
    go(pa, "prod", "#vProd"); shot(pa, "08-productos"); go(pa, "resp", "#vResp"); shot(pa, "09-respaldos")

    # ---------- móvil ----------
    pm = b.new_context(bypass_csp=True, viewport={"width": 390, "height": 800}).new_page(); pm.on("pageerror", lambda e: errs.append(str(e)))
    login(pm, "marcela", "Admin12345")
    check("móvil: menú lateral oculto por defecto", not pm.locator("#side").bounding_box()["x"] >= 0)
    pm.click("#menuBtn"); pm.wait_for_timeout(300); check("móvil: el botón abre el menú", pm.locator("#side").bounding_box()["x"] >= 0)
    pm.click('#nav [data-v="gas"]'); pm.wait_for_selector("#vGas:not([hidden])"); pm.wait_for_timeout(300)
    check("móvil: el menú se cierra al navegar", pm.locator("#side").bounding_box()["x"] < 0)
    OV = "()=>{const W=document.documentElement.clientWidth;return [document.documentElement.scrollWidth,W,[...document.querySelectorAll('body *')].filter(e=>{const r=e.getBoundingClientRect();return r.right>W+1&&r.width>0&&getComputedStyle(e).position!=='fixed'}).slice(0,8).map(e=>e.tagName+'#'+e.id+'.'+e.className)]}"
    print("   ancho:", pm.evaluate(OV))
    check("móvil: sin desbordamiento horizontal de la página", pm.evaluate("document.documentElement.scrollWidth<=document.documentElement.clientWidth"))
    shot(pm, "10-movil-gastos"); pm.click("#menuBtn"); pm.click('#nav [data-v="pos"]'); pm.wait_for_timeout(300); shot(pm, "11-movil-pos")
    check("móvil POS: sin desbordamiento horizontal", pm.evaluate("document.documentElement.scrollWidth<=document.documentElement.clientWidth"))
    check("sin errores de JavaScript", not errs)
    if errs: print("   errores:", errs)
    b.close()
srv.shutdown(); print(f"\n{len(ok)} correctas, {len(fail)} fallidas"); sys.exit(1 if fail else 0)
