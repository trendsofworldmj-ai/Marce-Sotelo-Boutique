"""Interfaz de respaldo/restauración en Chromium real (base temporal, datos ficticios)."""
import os, sys, tempfile, threading
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright, expect
from app import create_app
import db
from auth import create_user

app = create_app(os.path.join(tempfile.mkdtemp(), "ui.db"))
with app.app_context():
    con = db.get_db()
    with con:
        create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
        create_user(con, "caja1", "Cajera Uno", "cajero", "Caja12345", must_change=False)
api = app.test_client(); api.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
mk = lambda n, s: api.post("/api/products", json={"name": n, "price": 100, "cost": 40, "variants": [{"sku": s, "stock": 3}]})
names = lambda: [p["name"] for p in api.get("/api/products?all=1").get_json()["products"]]
mk("Blusa Alba", "A-1")
srv = make_server("127.0.0.1", 5068, app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
ok, fail = [], []
def check(n, c): (ok if c else fail).append(n); print(("  OK  " if c else " FALLA "), n)

with sync_playwright() as pw:
    b = pw.chromium.launch(); errs = []; pg = b.new_context(bypass_csp=True).new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto("http://127.0.0.1:5068"); pg.fill("#lu", "marcela"); pg.fill("#lp", "Admin12345"); pg.click("#lb"); pg.wait_for_selector("#top:not([hidden])")
    pg.click('#nav [data-v="resp"]'); expect(pg.locator("#rList")).to_contain_text("Aún no hay respaldos")
    pg.click("#rNew"); expect(pg.locator("#rList")).to_contain_text("manual")
    check("respaldo manual creado y listado", "boutique-" in pg.inner_text("#rList"))
    check("enlace de descarga presente", pg.locator('#rList a[href*="/download"]').count() == 1)
    mk("Vestido Luna", "V-1"); check("hay 2 productos antes de restaurar", names() == ["Blusa Alba", "Vestido Luna"])
    pg.click("#rList button[data-n]"); pg.fill("#rc", "restaurar mal"); pg.click("#fOk")
    expect(pg.locator("#fErr")).to_contain_text("RESTAURAR"); check("sin la palabra de confirmación no restaura", len(names()) == 2)
    pg.fill("#rc", "RESTAURAR"); pg.click("#fOk")
    expect(pg.locator("#toast")).to_contain_text("Restaurado", timeout=8000)      # señal determinista: el servidor ya respondió OK
    with pg.expect_navigation(timeout=8000): pass                                  # la interfaz se recarga sola ~1,8 s después
    pg.wait_for_selector("#top:not([hidden])", timeout=8000)
    check("restauración aplicada: vuelve a 1 producto", names() == ["Blusa Alba"])
    pg.click('#nav [data-v="resp"]'); expect(pg.locator("#rList")).to_contain_text("previo a restauración")
    check("quedó copia previa a la restauración", "previo a restauración" in pg.inner_text("#rList"))
    check("sin errores de JavaScript", not errs)
    pg2 = b.new_context(bypass_csp=True).new_page(); pg2.goto("http://127.0.0.1:5068"); pg2.fill("#lu", "caja1"); pg2.fill("#lp", "Caja12345"); pg2.click("#lb"); pg2.wait_for_selector("#top:not([hidden])")
    check("cajera no ve la pestaña Respaldo", not pg2.locator('#nav [data-v="resp"]').is_visible())
    check("cajera: API de respaldos prohibida (403)", pg2.evaluate("fetch('/api/backups').then(r=>r.status)") == 403)
    b.close()
srv.shutdown(); print(f"\n{len(ok)} correctas, {len(fail)} fallidas"); sys.exit(1 if fail else 0)
