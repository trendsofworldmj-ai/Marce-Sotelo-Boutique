"""Prueba de interfaz en Chromium real (Playwright). Uso: python tests/ui_pw/productos.py
Levanta la app con una base temporal y datos ficticios; no toca datos reales."""
import os, sys, tempfile, threading
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright, expect
from app import create_app
import db
from auth import create_user

app = create_app(os.path.join(tempfile.mkdtemp(), "ui.db"))
with app.app_context():
    con = db.get_db()
    with con:
        create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
        create_user(con, "caja1", "Cajera Uno", "cajero", "Caja12345", must_change=False)
srv = make_server("127.0.0.1", 5066, app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
URL, ok, fail = "http://127.0.0.1:5066", [], []
def check(name, cond):
    (ok if cond else fail).append(name); print(("  OK  " if cond else " FALLA "), name)

def has(pg, sel, text, present=True, t=4000):
    """Espera automática (la lista se recarga de forma asíncrona tras guardar)."""
    try:
        (expect(pg.locator(sel)).to_contain_text(text, timeout=t) if present else expect(pg.locator(sel)).not_to_contain_text(text, timeout=t)); return True
    except AssertionError: return False

def login(pg, u, p):
    pg.goto(URL); pg.fill("#lu", u); pg.fill("#lp", p); pg.click("#lb"); pg.wait_for_selector("#top:not([hidden])")

with sync_playwright() as pw:
    b = pw.chromium.launch(); errs = []
    ctx = b.new_context(bypass_csp=True)   # la CSP de la app bloquea eval, que usa el propio Playwright
    pg = ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
    login(pg, "marcela", "Admin12345")
    check("admin ve pestaña Productos", pg.locator('#nav [data-v="prod"]').is_visible())
    pg.click('#nav [data-v="prod"]'); pg.wait_for_selector("#vProd:not([hidden])")
    check("catálogo vacío al inicio", has(pg, "#pList", "No hay productos"))

    # alta de producto con dos variantes
    pg.click("#pNew"); pg.fill("#fn", "Blusa Alba"); pg.fill("#fc", "Ropa"); pg.fill("#fb", "Marcela"); pg.fill("#fcost", "180"); pg.fill("#fp", "389")
    r1 = pg.locator("#fBody .vrow:not(.vh)").nth(0)
    r1.locator(".vs").fill("M"); r1.locator(".vc").fill("Marfil"); r1.locator(".vk").fill("blu-m"); r1.locator(".vn").fill("3"); r1.locator(".vm").fill("2")
    pg.click("#fAddV"); r2 = pg.locator("#fBody .vrow:not(.vh)").nth(1)
    r2.locator(".vs").fill("G"); r2.locator(".vc").fill("Marfil"); r2.locator(".vk").fill("blu-g"); r2.locator(".vn").fill("1")
    pg.click("#fOk"); pg.wait_for_selector("#formModal", state="hidden"); has(pg, "#pList", "Blusa Alba")
    t = pg.inner_text("#pList")
    check("producto creado con ambas variantes", "Blusa Alba" in t and "BLU-M" in t and "BLU-G" in t)
    check("costo y precio visibles para admin", "$180.00" in t and "$389.00" in t)
    check("existencia baja detectada (G: 1 ≤ mín 1)", has(pg, "#pCount", "1 variante(s) con existencia baja"))

    # el servidor rechaza datos inválidos y la ventana sigue abierta mostrando el error
    pg.click("#pNew"); pg.fill("#fn", "Sin precio"); pg.locator("#fBody .vrow:not(.vh) .vk").first.fill("sp-1"); pg.click("#fOk")
    pg.wait_for_function("document.getElementById('fErr').textContent.length>0")
    check("error de validación visible y sin guardar", "precio" in pg.inner_text("#fErr").lower() and "Sin precio" not in pg.inner_text("#pList"))
    pg.click("#fNo")

    # ajuste de existencias con motivo obligatorio
    pg.locator('button[data-a="adj"]').first.click(); pg.fill("#fd", "5"); pg.click("#fOk"); pg.wait_for_function("document.getElementById('fErr').textContent.length>0")
    check("ajuste sin motivo rechazado", "motivo" in pg.inner_text("#fErr").lower())
    pg.fill("#fr", "Conteo físico semanal"); pg.click("#fOk"); pg.wait_for_selector("#formModal", state="hidden")
    check("existencia actualizada a 8", has(pg, "#pList", "8 pzas"))
    pg.locator('button[data-a="hist"]').first.click(); pg.wait_for_selector("#infoModal:not([hidden])")
    check("historial muestra ajuste con motivo y usuario", "Ajuste" in pg.inner_text("#infoBody") and "Conteo físico semanal" in pg.inner_text("#infoBody") and "marcela" in pg.inner_text("#infoBody"))
    pg.click("#infoOk")

    # edición y desactivación de variante
    pg.locator('button[data-a="editv"]').nth(1).click(); pg.fill("#ev4", "750200"); pg.click("#fOk"); pg.wait_for_selector("#formModal", state="hidden")
    check("código de barras editado", has(pg, "#pList", "750200"))
    pg.locator('button[data-a="togv"]').nth(1).click(); pg.wait_for_selector("#confModal:not([hidden])"); pg.click("#cOk")
    pg.wait_for_function("!document.getElementById('pList').innerText.includes('BLU-G')")
    check("variante desactivada se oculta", has(pg, "#pList", "BLU-G", present=False))
    pg.check("#pInact"); check("'Ver inactivos' la muestra", has(pg, "#pList", "variante inactiva")); pg.uncheck("#pInact")

    # importación CSV (todo o nada) y filtro por búsqueda
    bad = os.path.join(tempfile.mkdtemp(), "mal.csv"); open(bad, "w", encoding="utf-8").write("producto,sku,precio,existencia\nVestido,,500,2\n")
    pg.set_input_files("#pFile", bad); pg.wait_for_selector("#confModal:not([hidden])"); pg.click("#cOk"); pg.wait_for_selector("#infoModal:not([hidden])")
    check("CSV con error: no importa nada y lista el detalle", "No se importó nada" in pg.inner_text("#infoTitle") and "Línea 2" in pg.inner_text("#infoBody")); pg.click("#infoOk")
    good = os.path.join(tempfile.mkdtemp(), "ok.csv"); open(good, "w", encoding="utf-8").write("producto,categoria,sku,talla,color,costo,precio,existencia,minimo\nVestido Luna,Ropa,VES-S,S,Negro,300,650,4,1\nBLU-M,,BLU-M,M,Marfil,1,2,9,1\n")
    pg.set_input_files("#pFile", good); pg.wait_for_selector("#confModal:not([hidden])"); pg.click("#cOk"); pg.wait_for_selector("#pList >> text=Vestido Luna")
    check("CSV válido importa y omite SKU existente", has(pg, "#pList", "Vestido Luna") and has(pg, "#pList", "8 pzas"))
    pg.fill("#pq", "ves-s"); check("búsqueda por SKU", "Vestido Luna" in pg.inner_text("#pList") and "Blusa Alba" not in pg.inner_text("#pList")); pg.fill("#pq", "")

    # desactivar producto: desaparece de la caja del cajero
    pg.locator('button[data-a="togp"]').first.click(); pg.wait_for_selector("#confModal:not([hidden])"); pg.click("#cOk")
    pg.wait_for_function("!document.getElementById('pList').innerText.includes('Blusa Alba')")
    check("producto desactivado se oculta", has(pg, "#pList", "Blusa Alba", present=False))
    check("sin errores de JavaScript (admin)", not errs)

    # cajera: sin acceso, también en servidor
    pg2 = b.new_context(bypass_csp=True).new_page();   # contexto aparte = cookies de sesión distintas
    login(pg2, "caja1", "Caja12345")
    check("cajera NO ve pestaña Productos", not pg2.locator('#nav [data-v="prod"]').is_visible())
    st = pg2.evaluate("fetch('/api/products?all=1').then(r=>r.json()).then(d=>JSON.stringify(d))")
    check("cajera no recibe costos por la API", '"cost"' not in st and "Blusa" not in st)
    st2 = pg2.evaluate("fetch('/api/variants/1/adjust',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({delta:1,reason:'intento no autorizado'})}).then(r=>r.status)")
    check("cajera no puede ajustar inventario (403)", st2 == 403)
    b.close()

srv.shutdown()
print(f"\n{len(ok)} correctas, {len(fail)} fallidas"); sys.exit(1 if fail else 0)
