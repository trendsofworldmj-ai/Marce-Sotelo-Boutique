"""Humo del POS en Chromium real: la cajera vende y el inventario baja; variantes inactivas no aparecen. Base temporal."""
import os, sys, tempfile, threading
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright, expect
from app import create_app
import db
from auth import create_user

app = create_app(os.path.join(tempfile.mkdtemp(), "ui.db"))
with app.app_context():
    con = db.get_db()
    with con:
        create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
        create_user(con, "caja1", "Cajera Uno", "cajero", "Caja12345", must_change=False)
adm = app.test_client(); adm.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
pid = adm.post("/api/products", json={"name": "Blusa Alba", "category": "Ropa", "cost": 180, "price": 389, "variants": [
    {"sku": "BLU-M", "size": "M", "color": "Marfil", "stock": 5, "min_stock": 1}, {"sku": "BLU-X", "size": "XL", "color": "Marfil", "stock": 4}]}).get_json()["id"]
vs = adm.get("/api/products").get_json()["products"][0]["variants"]
adm.patch(f"/api/variants/{vs[1]['id']}", json={"active": False})
srv = make_server("127.0.0.1", 5067, app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
ok, fail = [], []
def check(n, c): (ok if c else fail).append(n); print(("  OK  " if c else " FALLA "), n)

with sync_playwright() as pw:
    b = pw.chromium.launch(); errs = []; pg = b.new_context(bypass_csp=True).new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto("http://127.0.0.1:5067"); pg.fill("#lu", "caja1"); pg.fill("#lp", "Caja12345"); pg.click("#lb"); pg.wait_for_selector("#top:not([hidden])")
    check("cajera no ve el menú de administración", not pg.locator("#nav [data-admin]:visible").count())
    pg.click("#openBtn"); pg.wait_for_selector("#pos:not([hidden])")
    expect(pg.locator(".prod")).to_have_count(1)
    opts = pg.locator(f"#v{pid} option").all_inner_texts()
    check("el selector solo lista la variante activa", len(opts) == 1 and "XL" not in opts[0])
    pg.click(f'button[data-add="{pid}"]'); expect(pg.locator("#tot")).to_contain_text("389")
    pg.click("#charge"); pg.wait_for_selector("#doneModal:not([hidden])")
    check("venta registrada con folio", "MB-000001" in pg.inner_text("#doneInfo"))
    stock = adm.get("/api/products").get_json()["products"][0]["variants"][0]["stock"]
    check("existencia bajó de 5 a 4", stock == 4)
    check("sin errores de JavaScript (POS)", not errs)
    b.close()
srv.shutdown(); print(f"\n{len(ok)} correctas, {len(fail)} fallidas"); sys.exit(1 if fail else 0)
