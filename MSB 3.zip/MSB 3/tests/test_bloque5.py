import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import db
from auth import create_user

class B5(unittest.TestCase):
    def setUp(self):
        self.app = create_app(os.path.join(tempfile.mkdtemp(), "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "Caja", "cajero", "Caja12345", must_change=False)
        self.a, self.k = self.app.test_client(), self.app.test_client()
        self.a.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
        self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.a.post("/api/products", json={"name": "Blusa", "cost": 100, "price": 389, "variants": [{"sku": "B-M", "stock": 4}]})
        self.sup = self.a.post("/api/suppliers", json={"name": "Moda Mayoreo", "phone": "3221234567"}).get_json()["id"]
    def buy(self, qty=4, cost=200): return self.a.post("/api/purchases", json={"supplier_id": self.sup, "items": [{"variant_id": 1, "qty": qty, "cost": cost}]}).get_json()["id"]
    def prod(self): return self.a.get("/api/products").get_json()["products"][0]

    def test_cajero_sin_acceso(self):
        for m, u in (("get", "/api/suppliers"), ("get", "/api/purchases"), ("get", "/api/expenses"), ("post", "/api/expenses"), ("post", "/api/purchases/1/receive")):
            self.assertEqual(getattr(self.k, m)(u, **({"json": {}} if m == "post" else {})).status_code, 403)
    def test_compra_pendiente_no_mueve_stock_y_recibir_si(self):
        pid = self.buy(); self.assertEqual(self.prod()["variants"][0]["stock"], 4)
        self.assertEqual(self.a.get(f"/api/purchases/{pid}").get_json()["total"], 800)
        self.assertEqual(self.a.post(f"/api/purchases/{pid}/receive", json={}).status_code, 200)
        p = self.prod(); self.assertEqual((p["variants"][0]["stock"], p["cost"]), (8, 150))   # promedio ponderado: (4*100+4*200)/8
        kinds = [m["kind"] for m in self.a.get("/api/inventory/movements").get_json()["movements"]]
        self.assertIn("compra", kinds)
    def test_recibir_dos_veces_no_duplica(self):
        pid = self.buy(); self.a.post(f"/api/purchases/{pid}/receive", json={})
        self.assertEqual(self.a.post(f"/api/purchases/{pid}/receive", json={}).status_code, 409); self.assertEqual(self.prod()["variants"][0]["stock"], 8)
    def test_cancelar_solo_pendientes(self):
        p1, p2 = self.buy(), self.buy()
        self.assertEqual(self.a.post(f"/api/purchases/{p1}/cancel", json={}).status_code, 200)
        self.assertEqual(self.a.post(f"/api/purchases/{p1}/receive", json={}).status_code, 409)
        self.a.post(f"/api/purchases/{p2}/receive", json={}); self.assertEqual(self.a.post(f"/api/purchases/{p2}/cancel", json={}).status_code, 409)
    def test_pagos_a_proveedor_y_saldo(self):
        pid = self.buy()
        r = self.a.post(f"/api/purchases/{pid}/payments", json={"amount": 300, "method": "transferencia"}).get_json()
        self.assertEqual((r["paid"], r["balance"]), (300, 500))
        self.assertEqual(self.a.post(f"/api/purchases/{pid}/payments", json={"amount": 600, "method": "efectivo"}).status_code, 400)
        self.assertEqual(self.a.post(f"/api/purchases/{pid}/payments", json={"amount": 500, "method": "efectivo"}).get_json()["balance"], 0)
        c = self.buy(); self.a.post(f"/api/purchases/{c}/cancel", json={})
        self.assertEqual(self.a.post(f"/api/purchases/{c}/payments", json={"amount": 10, "method": "efectivo"}).status_code, 409)
    def test_validaciones_de_compra(self):
        bad = [{"supplier_id": 99, "items": [{"variant_id": 1, "qty": 1, "cost": 1}]}, {"supplier_id": self.sup, "items": []},
               {"supplier_id": self.sup, "items": [{"variant_id": 1, "qty": 0, "cost": 1}]}, {"supplier_id": self.sup, "items": [{"variant_id": 77, "qty": 1, "cost": 1}]}]
        for b in bad: self.assertEqual(self.a.post("/api/purchases", json=b).status_code, 400)
    def test_gastos_y_resumen(self):
        self.a.post("/api/expenses", json={"concept": "Renta del local", "category": "Renta", "amount": 3500})
        self.a.post("/api/expenses", json={"concept": "Bolsas", "category": "Empaque", "amount": 250.50})
        self.assertEqual(self.a.post("/api/expenses", json={"concept": "", "amount": 10}).status_code, 400)
        self.assertEqual(self.a.post("/api/expenses", json={"concept": "Cero", "amount": 0}).status_code, 400)
        r = self.a.get("/api/expenses").get_json(); self.assertEqual((r["total"], r["by_category"]["Renta"]), (3750.5, 3500))
        self.assertEqual(self.a.get("/api/expenses?from=2999-01-01").get_json()["total"], 0)
        self.assertEqual(self.a.get("/api/expenses?from=hoy").status_code, 400)

if __name__ == "__main__": unittest.main()
