import os, sqlite3, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app
import backup, db
from auth import create_user

P = lambda name, sku: {"name": name, "price": 100, "cost": 40, "variants": [{"sku": sku, "stock": 5}]}

class B8(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(); self.app = create_app(os.path.join(self.dir, "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                create_user(con, "marcela", "M", "admin", "Admin12345", must_change=False)
                create_user(con, "caja1", "C", "cajero", "Caja12345", must_change=False)
        self.a, self.k = self.app.test_client(), self.app.test_client()
        self.a.post("/api/login", json={"username": "marcela", "password": "Admin12345"})
        self.k.post("/api/login", json={"username": "caja1", "password": "Caja12345"})
        self.bdir = os.path.join(self.dir, "backups")
    names = lambda self: [p["name"] for p in self.a.get("/api/products?all=1").get_json()["products"]]

    def test_crear_listar_descargar_y_permisos(self):
        r = self.a.post("/api/backups", json={}); self.assertEqual(r.status_code, 201)
        name = r.get_json()["name"]; self.assertTrue(os.path.isfile(os.path.join(self.bdir, name)))
        self.assertEqual([b["name"] for b in self.a.get("/api/backups").get_json()["backups"]], [name])
        d = self.a.get(f"/api/backups/{name}/download"); self.assertEqual(d.status_code, 200); self.assertTrue(d.data.startswith(b"SQLite format 3\x00"))
        self.assertEqual(self.k.get("/api/backups").status_code, 403)
        self.assertEqual(self.k.post("/api/backups", json={}).status_code, 403)
        self.assertEqual(self.k.get(f"/api/backups/{name}/download").status_code, 403)
        self.assertEqual(self.k.post("/api/backups/restore", json={"name": name, "confirm": "RESTAURAR"}).status_code, 403)

    def test_restaurar_regresa_al_estado_del_respaldo(self):
        self.a.post("/api/products", json=P("Blusa A", "A-1"))
        name = self.a.post("/api/backups", json={}).get_json()["name"]
        self.a.post("/api/products", json=P("Blusa B", "B-1"))
        self.a.post("/api/users", json={"username": "nueva", "full_name": "N", "role": "cajero", "password": "Nueva12345"})
        self.assertEqual(self.names(), ["Blusa A", "Blusa B"])
        r = self.a.post("/api/backups/restore", json={"name": name, "confirm": "RESTAURAR"}); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.names(), ["Blusa A"])
        self.assertEqual([u["username"] for u in self.a.get("/api/users").get_json()["users"]], ["marcela", "caja1"])
        pre = r.get_json()["safety_copy"]; con = sqlite3.connect(os.path.join(self.bdir, pre))
        self.assertEqual(con.execute("SELECT COUNT(*) FROM products").fetchone()[0], 2); con.close()   # la copia previa conserva lo que había
        ev = [e["action"] for e in self.a.get("/api/audit?limit=20").get_json()["events"]]
        self.assertIn("backup_restaurado", ev)
        # y se puede deshacer restaurando la copia previa
        self.assertEqual(self.a.post("/api/backups/restore", json={"name": pre, "confirm": "RESTAURAR"}).status_code, 200)
        self.assertEqual(self.names(), ["Blusa A", "Blusa B"])

    def test_confirmacion_y_nombres_peligrosos(self):
        name = self.a.post("/api/backups", json={}).get_json()["name"]
        self.assertEqual(self.a.post("/api/backups/restore", json={"name": name}).status_code, 400)
        self.assertEqual(self.a.post("/api/backups/restore", json={"name": name, "confirm": "si"}).status_code, 400)
        for bad in ("../t.db", "..\\t.db", "/etc/passwd", "boutique-1.db", name + ".bak", ""):
            self.assertEqual(self.a.post("/api/backups/restore", json={"name": bad, "confirm": "RESTAURAR"}).status_code, 400, bad)
        self.assertEqual(self.a.post("/api/backups/restore", json={"name": "boutique-20200101-000000.db", "confirm": "RESTAURAR"}).status_code, 404)
        self.assertIn(self.a.get("/api/backups/..%2Ft.db/download").status_code, (400, 404))
        self.assertEqual(self.a.get("/api/backups/passwd/download").status_code, 400)

    def test_archivo_corrupto_no_se_restaura_y_no_toca_datos(self):
        self.a.post("/api/products", json=P("Blusa A", "A-1"))
        os.makedirs(self.bdir, exist_ok=True); bad = "boutique-20200101-000000.db"; open(os.path.join(self.bdir, bad), "wb").write(b"esto no es sqlite" * 50)
        r = self.a.post("/api/backups/restore", json={"name": bad, "confirm": "RESTAURAR"}); self.assertEqual(r.status_code, 400)
        self.assertEqual(self.names(), ["Blusa A"])

    def test_respaldo_sin_administradora_activa_se_rechaza(self):
        name = self.a.post("/api/backups", json={}).get_json()["name"]
        con = sqlite3.connect(os.path.join(self.bdir, name)); con.execute("UPDATE users SET active=0 WHERE role='admin'"); con.commit(); con.close()
        r = self.a.post("/api/backups/restore", json={"name": name, "confirm": "RESTAURAR"})
        self.assertEqual(r.status_code, 400); self.assertIn("administradora", r.get_json()["error"])
        self.assertEqual(self.a.get("/api/users").status_code, 200)   # el sistema sigue intacto

    def test_respaldo_automatico_al_cerrar_caja_y_poda(self):
        self.k.post("/api/cash/open", json={"opening": 100})
        self.assertEqual(self.k.post("/api/cash/close", json={"counted": 100}).status_code, 200)
        self.assertEqual([b["kind"] for b in self.a.get("/api/backups").get_json()["backups"]], ["automático"])
        manual = self.a.post("/api/backups", json={}).get_json()["name"]
        for _ in range(backup.KEEP_AUTO + 3): backup.create_backup(self.app, "auto")
        kinds = [b["kind"] for b in self.a.get("/api/backups").get_json()["backups"]]
        self.assertEqual(kinds.count("automático"), backup.KEEP_AUTO); self.assertIn(manual, [b["name"] for b in self.a.get("/api/backups").get_json()["backups"]])

if __name__ == "__main__":
    unittest.main()
