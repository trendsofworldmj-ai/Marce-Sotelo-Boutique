import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app

class B6B(unittest.TestCase):
    def test_interfaz_se_sirve(self):
        c = create_app(os.path.join(tempfile.mkdtemp(), "t.db")).test_client()
        h = c.get("/").get_data(as_text=True)
        self.assertIn("Marcela Boutique", h); self.assertIn('id="pos"', h)
        self.assertEqual(c.get("/static/logo.jpg").status_code, 200)

if __name__ == "__main__": unittest.main()
