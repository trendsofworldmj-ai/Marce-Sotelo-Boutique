import os, tempfile, unittest
from app import create_app
import db
from auth import create_user

class B14Usuarios(unittest.TestCase):
    def setUp(self):
        self.app = create_app(os.path.join(tempfile.mkdtemp(), "t.db"))
        with self.app.app_context():
            con = db.get_db()
            with con:
                self.adm = create_user(con, "marcela", "Marcela", "admin", "Admin12345", must_change=False)
                self.caj = create_user(con, "caja1", "Caja", "cajero", "Caja12345", must_change=False)
        self.a = self.app.test_client(); self.a.post("/api/login", json={"username": "marcela", "password": "Admin12345"})

    def test_restablecer_password_y_cambio_de_rol(self):
        r = self.a.patch(f"/api/users/{self.caj}", json={"reset_password": "Nueva12345", "role": "admin"})
        self.assertEqual(r.status_code, 200)
        c = self.app.test_client()
        ok = c.post("/api/login", json={"username": "caja1", "password": "Nueva12345"})
        self.assertEqual(ok.status_code, 200); self.assertTrue(ok.get_json()["must_change"])
        self.assertEqual(c.get("/api/users").status_code, 403)   # hasta cambiar la temporal no puede operar
        self.assertEqual(c.post("/api/password", json={"current": "Nueva12345", "new": "Definitiva123"}).status_code, 200)
        self.assertEqual(c.get("/api/users").status_code, 200)   # ahora es administradora

    def test_password_corta_rechazada(self):
        self.assertEqual(self.a.patch(f"/api/users/{self.caj}", json={"reset_password": "corta"}).status_code, 400)

    def test_no_se_puede_degradar_a_la_ultima_administradora(self):
        r = self.a.patch(f"/api/users/{self.adm}", json={"role": "cajero"})
        self.assertEqual(r.status_code, 400)

if __name__ == "__main__": unittest.main()
