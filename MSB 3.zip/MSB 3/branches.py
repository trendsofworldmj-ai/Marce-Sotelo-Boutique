from flask import Blueprint, g, jsonify, request
import db
from auth import audit, login_required, role_required
from inventory import txt

bp = Blueprint("branches", __name__)

def err(msg, code=400):
    return jsonify(error=msg), code

@bp.get("/api/branches")
@login_required
def list_branches():
    con = db.get_db()
    if g.user["role"] == "admin":
        rows = con.execute("SELECT * FROM branches ORDER BY id ASC").fetchall()
    else:
        rows = con.execute("SELECT * FROM branches WHERE active=1 ORDER BY id ASC").fetchall()
    return jsonify(branches=[dict(r) for r in rows])

@bp.post("/api/branches")
@role_required("admin")
def create_branch():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    try:
        code = (txt(d.get("code"), "código", 10) or "").upper().strip()
        name = txt(d.get("name"), "nombre", 80)
        kind = str(d.get("kind") or "operativa").strip().lower()
        address = txt(d.get("address"), "dirección", 200)
        phone = txt(d.get("phone"), "teléfono", 30)

        if not code or len(code) < 2:
            return err("El código debe tener entre 2 y 10 caracteres.")
        if not name or len(name) < 3:
            return err("El nombre de la sucursal es obligatorio (mín. 3 caracteres).")
        if kind not in ("maestra", "operativa"):
            return err("El tipo de sucursal debe ser 'maestra' u 'operativa'.")

        with con:
            cur = con.execute(
                "INSERT INTO branches(code, name, address, phone, kind, active) VALUES(?,?,?,?,?,1)",
                (code, name, address, phone, kind)
            )
            bid = cur.lastrowid
            audit(con, g.user["id"], "sucursal_creada", f"id={bid} code={code} name={name}")
        return jsonify(id=bid, code=code, name=name), 201
    except Exception as e:
        if "UNIQUE" in str(e).upper():
            return err("Ya existe una sucursal con ese código o nombre.", 409)
        return err(str(e), 400)

@bp.patch("/api/branches/<int:bid>")
@role_required("admin")
def update_branch(bid):
    d, con, sets, args = request.get_json(silent=True) or {}, db.get_db(), [], []
    branch = con.execute("SELECT * FROM branches WHERE id=?", (bid,)).fetchone()
    if not branch:
        return err("Sucursal no encontrada.", 404)

    try:
        if "name" in d:
            name = txt(d["name"], "nombre", 80)
            if not name or len(name) < 3:
                return err("Nombre no válido.")
            sets.append("name=?"); args.append(name)
        if "address" in d:
            sets.append("address=?"); args.append(txt(d["address"], "dirección", 200))
        if "phone" in d:
            sets.append("phone=?"); args.append(txt(d["phone"], "teléfono", 30))
        if "active" in d:
            active_val = int(bool(d["active"]))
            # No permitir desactivar la sucursal principal San José
            if not active_val and branch["code"] == "SJO":
                active_count = con.execute("SELECT COUNT(*) FROM branches WHERE active=1").fetchone()[0]
                if active_count <= 1:
                    return err("No puedes desactivar la sucursal principal San José.", 400)
            
            # Impedir desactivación si hay turnos de caja abiertos en esa sucursal
            if not active_val:
                open_cajas = con.execute("SELECT COUNT(*) FROM cash_sessions WHERE branch_id=? AND status='abierta'", (bid,)).fetchone()[0]
                if open_cajas > 0:
                    return err("No se puede desactivar una sucursal con turnos de caja abiertos.", 409)

            sets.append("active=?"); args.append(active_val)

        if not sets:
            return err("Nada que actualizar.")

        with con:
            con.execute(f"UPDATE branches SET {','.join(sets)} WHERE id=?", args + [bid])
            audit(con, g.user["id"], "sucursal_actualizada", f"id={bid}")
        return jsonify(ok=True)
    except Exception as e:
        if "UNIQUE" in str(e).upper():
            return err("Nombre o código ya utilizado por otra sucursal.", 409)
        return err(str(e), 400)