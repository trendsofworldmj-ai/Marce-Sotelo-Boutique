import os, secrets
from datetime import datetime, timedelta
from flask import Flask, g, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash
import db
from auth import ROLES, audit, create_user, login_required, public, role_required

MAX_FAILS, LOCK_MIN = 5, 10

def create_app(db_path=None):
    app = Flask(__name__)
    os.makedirs(app.instance_path, exist_ok=True)
    kf = os.path.join(app.instance_path, "secret.key")
    if not os.path.exists(kf):
        fd = os.open(kf, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f: f.write(secrets.token_hex(32))
    with open(kf) as f: app.secret_key = f.read().strip()
    app.config.update(DB_PATH=db_path or os.path.join(app.instance_path, "boutique.db"),
                      MAX_CONTENT_LENGTH=5 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", PERMANENT_SESSION_LIFETIME=36000)
    db.init_app(app)

    # Blueprints
    from license import bp as license_bp
    app.register_blueprint(license_bp)
    from branches import bp as branches_bp
    app.register_blueprint(branches_bp)
    from inventory import bp as inventory_bp
    app.register_blueprint(inventory_bp)
    from sales import bp as sales_bp
    app.register_blueprint(sales_bp)
    from cash import bp as cash_bp
    app.register_blueprint(cash_bp)
    from purchases import bp as purchases_bp
    app.register_blueprint(purchases_bp)
    from reports import bp as reports_bp
    app.register_blueprint(reports_bp)
    from backup import bp as backup_bp
    app.register_blueprint(backup_bp)
    from transfers import bp as transfers_bp
    app.register_blueprint(transfers_bp)
    from layaways import bp as layaways_bp
    app.register_blueprint(layaways_bp)
    from labels import bp as labels_bp
    app.register_blueprint(labels_bp)

    @app.before_request
    def check_license_and_csrf():
        # Mitigación CSRF para escrituras
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and not request.is_json:
            return jsonify(error="Se requiere application/json."), 415

    @app.after_request
    def secure_headers(r):
        r.headers.setdefault("X-Content-Type-Options", "nosniff")
        r.headers.setdefault("X-Frame-Options", "DENY")
        r.headers.setdefault("Referrer-Policy", "no-referrer")
        r.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; form-action 'self'")
        if request.path.startswith("/api/") or request.path == "/":
            r.headers["Cache-Control"] = "no-store"
        return r

    @app.get("/")
    def index(): return render_template("app.html")

    @app.post("/api/login")
    def login():
        d = request.get_json(silent=True) or {}
        con, now = db.get_db(), datetime.now()
        u = con.execute("""
            SELECT u.*, b.name as branch_name, b.code as branch_code 
            FROM users u 
            LEFT JOIN branches b ON b.id = u.branch_id 
            WHERE u.username=?
        """, (str(d.get("username", "")).strip().lower(),)).fetchone()
        
        if u and u["locked_until"] and datetime.fromisoformat(u["locked_until"]) > now:
            return jsonify(error="Cuenta bloqueada temporalmente. Intenta en unos minutos."), 429
        if not u or not u["active"] or not check_password_hash(u["pass_hash"], str(d.get("password", ""))):
            if u:
                n = u["failed_attempts"] + 1
                lock = (now + timedelta(minutes=LOCK_MIN)).isoformat() if n >= MAX_FAILS else None
                with con:
                    con.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?", (0 if lock else n, lock, u["id"]))
                    audit(con, u["id"], "login_fallido")
            return jsonify(error="Usuario o contraseña incorrectos."), 401
        with con:
            con.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?", (u["id"],))
            audit(con, u["id"], "login")
        session.clear(); session["uid"] = u["id"]; session.permanent = True
        return jsonify(user=public(u), must_change=bool(u["must_change"]))

    @app.post("/api/logout")
    def logout():
        session.clear(); return jsonify(ok=True)

    @app.get("/api/me")
    @login_required
    def me(): return jsonify(user=public(g.user), must_change=bool(g.user["must_change"]))

    @app.post("/api/password")
    @login_required
    def change_password():
        d = request.get_json(silent=True) or {}
        old, new = str(d.get("current", "")), str(d.get("new", ""))
        if not check_password_hash(g.user["pass_hash"], old): return jsonify(error="La contraseña actual no es correcta."), 400
        if len(new) < 8 or new == old: return jsonify(error="La nueva contraseña debe ser distinta y de al menos 8 caracteres."), 400
        con = db.get_db()
        with con:
            con.execute("UPDATE users SET pass_hash=?, must_change=0 WHERE id=?", (generate_password_hash(new), g.user["id"]))
            audit(con, g.user["id"], "cambio_password")
        return jsonify(ok=True)

    @app.get("/api/users")
    @role_required("admin")
    def list_users():
        rows = db.get_db().execute("""
            SELECT u.*, b.name AS branch_name, b.code AS branch_code 
            FROM users u 
            LEFT JOIN branches b ON b.id = u.branch_id 
            ORDER BY u.id
        """).fetchall()
        return jsonify(users=[public(r) for r in rows])

    @app.post("/api/users")
    @role_required("admin")
    def add_user():
        d, con = request.get_json(silent=True) or {}, db.get_db()
        branch_id = d.get("branch_id")
        try:
            with con:
                uid = create_user(con, str(d.get("username", "")), str(d.get("full_name", "")),
                                  str(d.get("role", "")), str(d.get("password", "")), branch_id=branch_id)
                audit(con, g.user["id"], "usuario_creado", f"id={uid} rol={d.get('role')} sucursal={branch_id}")
        except ValueError as e: return jsonify(error=str(e)), 400
        except Exception: return jsonify(error="Ese usuario ya existe o los datos no son válidos."), 409
        return jsonify(id=uid), 201

    @app.patch("/api/users/<int:uid>")
    @role_required("admin")
    def edit_user(uid):
        d, con, sets, args = request.get_json(silent=True) or {}, db.get_db(), [], []
        u = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not u: return jsonify(error="Usuario no encontrado."), 404
        
        if "full_name" in d:
            name = str(d["full_name"]).strip()
            if not name: return jsonify(error="El nombre es obligatorio."), 400
            sets.append("full_name=?"); args.append(name)
        if "role" in d:
            role = str(d["role"]).strip().lower()
            if role not in ROLES: return jsonify(error="Rol no válido."), 400
            if u["role"] == "admin" and role != "admin" and con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0] <= 1:
                return jsonify(error="Debe quedar al menos una administradora activa."), 400
            sets.append("role=?"); args.append(role)
        if "branch_id" in d:
            bid = d["branch_id"]
            if bid is not None and not con.execute("SELECT 1 FROM branches WHERE id=?", (bid,)).fetchone():
                return jsonify(error="Sucursal no válida."), 400
            sets.append("branch_id=?"); args.append(bid)
        if "reset_password" in d:
            new_p = str(d["reset_password"])
            if len(new_p) < 8: return jsonify(error="La contraseña debe tener al menos 8 caracteres."), 400
            sets.append("pass_hash=?"); args.append(generate_password_hash(new_p))
            sets.append("must_change=1")

        if not sets: return jsonify(error="Nada que actualizar."), 400
        with con:
            con.execute(f"UPDATE users SET {','.join(sets)} WHERE id=?", args + [uid])
            audit(con, g.user["id"], "usuario_modificado", f"id={uid}")
        return jsonify(ok=True)

    @app.post("/api/users/<int:uid>/active")
    @role_required("admin")
    def set_active(uid):
        flag, con = int(bool((request.get_json(silent=True) or {}).get("active"))), db.get_db()
        t = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not t: return jsonify(error="Usuario no encontrado."), 404
        if not flag:
            if uid == g.user["id"]: return jsonify(error="No puedes desactivarte a ti misma."), 400
            if t["role"] == "admin" and con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0] <= 1:
                return jsonify(error="Debe quedar al menos una administradora activa."), 400
        with con:
            con.execute("UPDATE users SET active=? WHERE id=?", (flag, uid))
            audit(con, g.user["id"], "usuario_activo" if flag else "usuario_desactivado", f"id={uid}")
        return jsonify(ok=True)

    return app

if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000)