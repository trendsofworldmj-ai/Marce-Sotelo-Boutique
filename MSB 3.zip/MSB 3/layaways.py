from datetime import datetime, timedelta
from flask import Blueprint, g, jsonify, request
import db
from auth import audit, login_required
from inventory import StockError, cents, move_stock, to_int, txt
from sales import current_session, err, folio, mxn

bp = Blueprint("layaways", __name__)
DEFAULT_EXPIRE_DAYS = 30

def l_folio(lid):
    return f"AP-{lid:06d}"

def detail_layaway(con, lid):
    l = con.execute("""
        SELECT l.*, b.name AS branch_name, u.username AS cashier
        FROM layaways l
        JOIN branches b ON b.id = l.branch_id
        JOIN users u ON u.id = l.user_id
        WHERE l.id = ?
    """, (lid,)).fetchone()
    if not l: return None

    items = con.execute("""
        SELECT li.*, v.sku, v.size, v.color, p.name AS product_name
        FROM layaway_items li
        JOIN variants v ON v.id = li.variant_id
        JOIN products p ON p.id = v.product_id
        WHERE li.layaway_id = ?
    """, (lid,)).fetchall()

    payments = con.execute("""
        SELECT lp.*, u.username AS cashier
        FROM layaway_payments lp
        JOIN users u ON u.id = lp.user_id
        WHERE lp.layaway_id = ?
        ORDER BY lp.id ASC
    """, (lid,)).fetchall()

    return {
        "id": l["id"], "folio": l["folio"], "status": l["status"],
        "branch_name": l["branch_name"], "cashier": l["cashier"],
        "customer_name": l["customer_name"], "customer_phone": l["customer_phone"],
        "total": l["total_cents"] / 100, "paid": l["paid_cents"] / 100,
        "balance": (l["total_cents"] - l["paid_cents"]) / 100,
        "expires_at": l["expires_at"], "created_at": l["created_at"], "notes": l["notes"],
        "items": [dict(i) for i in items],
        "payments": [dict(p) for p in payments]
    }

@bp.post("/api/layaways")
@login_required
def create_layaway():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    c_name = txt(d.get("customer_name"), "nombre del cliente", 100)
    if not c_name: return err("El nombre del cliente es obligatorio.", 400)
    c_phone = txt(d.get("customer_phone"), "teléfono", 30)
    notes = txt(d.get("notes"), "notas", 300)

    sess = current_session(con, g.user["id"])
    if not sess: return err("Abre tu caja antes de crear un apartado.", 409)
    branch_id = sess["branch_id"] or g.user["branch_id"] or db.get_default_branch_id(con)

    items_in = d.get("items") or []
    if not items_in: return err("El apartado no tiene prendas.", 400)

    # Consolidar por variant_id para blindar contra prendas duplicadas
    lines = {}
    for it in items_in:
        try: vid, qty = int(it["variant_id"]), int(it["qty"])
        except (KeyError, TypeError, ValueError): return err("Partida no válida.", 400)
        if qty <= 0: return err("La cantidad debe ser mayor a 0.", 400)
        lines[vid] = lines.get(vid, 0) + qty

    items = []
    for vid, qty in lines.items():
        r = con.execute("""
            SELECT v.id, v.sku, p.price_cents, COALESCE(vs.stock, 0) as stock, COALESCE(vs.reserved, 0) as reserved
            FROM variants v
            JOIN products p ON p.id = v.product_id
            LEFT JOIN variant_stock vs ON vs.variant_id = v.id AND vs.branch_id = ?
            WHERE v.id=? AND v.active=1 AND p.active=1
        """, (branch_id, vid)).fetchone()
        if not r: return err(f"Variante {vid} no válida.", 400)
        avail = r["stock"] - r["reserved"]
        if avail < qty:
            return err(f"Stock insuficiente para apartar SKU {r['sku']}. Disponible: {avail}, Solicitado: {qty}", 409)
        items.append((vid, qty, r["price_cents"]))

    total_cents = sum(q * pr for _, q, pr in items)
    
    try:
        deposit = cents(d.get("deposit", 0), "anticipo")
    except ValueError as e: return err(str(e), 400)
    if deposit <= 0 or deposit > total_cents:
        return err(f"El anticipo debe ser mayor a 0 y no exceder el total ({mxn(total_cents)}).", 400)
    
    method = str(d.get("method") or "efectivo").lower()
    if method not in ("efectivo", "tarjeta", "transferencia", "otro"):
        return err("Método de pago no válido.", 400)

    exp_days = to_int(d.get("days", DEFAULT_EXPIRE_DAYS), "días de vigencia", 1)
    expires_at = (datetime.now() + timedelta(days=exp_days)).strftime("%Y-%m-%d 23:59:59")

    try:
        with con:
            cur = con.execute("""
                INSERT INTO layaways(folio, branch_id, user_id, customer_name, customer_phone, total_cents, paid_cents, expires_at, notes)
                VALUES('TEMP', ?, ?, ?, ?, ?, ?, ?, ?)
            """, (branch_id, g.user["id"], c_name, c_phone, total_cents, deposit, expires_at, notes))
            lid = cur.lastrowid
            folio_str = l_folio(lid)
            con.execute("UPDATE layaways SET folio=? WHERE id=?", (folio_str, lid))

            for vid, qty, pr in items:
                con.execute("INSERT INTO layaway_items(layaway_id, variant_id, qty, price_cents) VALUES(?,?,?,?)",
                            (lid, vid, qty, pr))
                # Actualización atómica de reserva con seguro de no sobreventa
                upd = con.execute("""
                    UPDATE variant_stock 
                    SET reserved = reserved + ? 
                    WHERE variant_id=? AND branch_id=? AND (reserved + ?) <= stock
                """, (qty, vid, branch_id, qty))
                if upd.rowcount != 1:
                    raise StockError("El stock disponible cambió durante la operación.")

            con.execute("""
                INSERT INTO layaway_payments(layaway_id, session_id, user_id, amount_cents, method)
                VALUES(?,?,?,?,?)
            """, (lid, sess["id"], g.user["id"], deposit, method))

            audit(con, g.user["id"], "apartado_creado", f"{folio_str} anticipo={deposit} total={total_cents}")
    except StockError as e:
        return err(str(e), 409)

    return jsonify(id=lid, folio=folio_str, total=total_cents / 100, paid=deposit / 100), 201

@bp.post("/api/layaways/<int:lid>/payments")
@login_required
def add_payment(lid):
    d, con = request.get_json(silent=True) or {}, db.get_db()
    l = con.execute("SELECT * FROM layaways WHERE id=?", (lid,)).fetchone()
    if not l: return err("Apartado no encontrado.", 404)
    if l["status"] != "vigente":
        return err(f"El apartado ya está {l['status']}.", 409)

    sess = current_session(con, g.user["id"])
    if not sess: return err("Abre tu caja antes de registrar abonos.", 409)

    try: amt = cents(d.get("amount"), "abono")
    except ValueError as e: return err(str(e), 400)

    method = str(d.get("method") or "efectivo").lower()
    if method not in ("efectivo", "tarjeta", "transferencia", "otro"):
        return err("Método no válido.", 400)

    with con:
        # Re-validación atómica de saldo bajo bloqueo transaccional
        cur_l = con.execute("SELECT total_cents, paid_cents, status FROM layaways WHERE id=?", (lid,)).fetchone()
        if cur_l["status"] != "vigente":
            return err(f"El apartado ya está {cur_l['status']}.", 409)
        bal = cur_l["total_cents"] - cur_l["paid_cents"]
        if amt <= 0 or amt > bal:
            return err(f"El abono debe ser mayor a 0 y no exceder el saldo restante ({mxn(bal)}).", 400)

        con.execute("""
            INSERT INTO layaway_payments(layaway_id, session_id, user_id, amount_cents, method)
            VALUES(?,?,?,?,?)
        """, (lid, sess["id"], g.user["id"], amt, method))
        
        new_paid = cur_l["paid_cents"] + amt
        con.execute("UPDATE layaways SET paid_cents=? WHERE id=?", (new_paid, lid))
        audit(con, g.user["id"], "abono_apartado", f"{l['folio']} monto={amt}")

    return jsonify(detail_layaway(con, lid)), 200

@bp.post("/api/layaways/<int:lid>/deliver")
@login_required
def deliver_layaway(lid):
    """Liquidación y entrega atómica: libera la reserva y descuenta el inventario físico como venta."""
    con = db.get_db()
    l = con.execute("SELECT * FROM layaways WHERE id=?", (lid,)).fetchone()
    if not l: return err("Apartado no encontrado.", 404)
    if l["status"] != "vigente": return err(f"El apartado ya está {l['status']}.", 409)
    if l["paid_cents"] < l["total_cents"]:
        return err(f"El apartado aún tiene saldo pendiente ({mxn(l['total_cents'] - l['paid_cents'])}).", 400)

    sess = current_session(con, g.user["id"])
    if not sess: return err("Abre tu caja para procesar la entrega.", 409)

    items = con.execute("SELECT * FROM layaway_items WHERE layaway_id=?", (lid,)).fetchall()
    with con:
        # Cambio de estado atómico con guardia contra doble entrega concurrente
        upd = con.execute("UPDATE layaways SET status='liquidado' WHERE id=? AND status='vigente'", (lid,))
        if upd.rowcount != 1:
            return err("El apartado ya fue liquidado o cancelado.", 409)

        for it in items:
            vid, qty = it["variant_id"], it["qty"]
            # Liberar reserva física
            con.execute("UPDATE variant_stock SET reserved = reserved - ? WHERE variant_id=? AND branch_id=?",
                        (qty, vid, l["branch_id"]))
            # Descontar stock físico definitivo
            move_stock(con, vid, l["branch_id"], "venta", -qty, f"Entrega apartado {l['folio']}", g.user["id"], "layaway", lid)

        audit(con, g.user["id"], "apartado_liquidado", l["folio"])

    return jsonify(ok=True)

@bp.post("/api/layaways/<int:lid>/cancel")
@login_required
def cancel_layaway(lid):
    """Cancelación atómica: libera las prendas reservadas en variant_stock."""
    d, con = request.get_json(silent=True) or {}, db.get_db()
    reason = str(d.get("reason") or "").strip()
    if len(reason) < 5: return err("Escribe el motivo de la cancelación.", 400)

    l = con.execute("SELECT * FROM layaways WHERE id=?", (lid,)).fetchone()
    if not l: return err("Apartado no encontrado.", 404)
    if l["status"] != "vigente": return err(f"El apartado ya está {l['status']}.", 409)

    items = con.execute("SELECT * FROM layaway_items WHERE layaway_id=?", (lid,)).fetchall()
    with con:
        upd = con.execute("""
            UPDATE layaways 
            SET status='cancelado', notes = COALESCE(notes || ' | ', '') || ? 
            WHERE id=? AND status='vigente'
        """, (f"Cancelado: {reason}", lid))
        if upd.rowcount != 1:
            return err("El apartado ya fue liquidado o cancelado.", 409)

        for it in items:
            con.execute("UPDATE variant_stock SET reserved = reserved - ? WHERE variant_id=? AND branch_id=?",
                        (it["qty"], it["variant_id"], l["branch_id"]))

        audit(con, g.user["id"], "apartado_cancelado", f"{l['folio']} motivo={reason}")

    return jsonify(ok=True)

@bp.get("/api/layaways")
@login_required
def list_layaways():
    con = db.get_db()
    sql = "SELECT id FROM layaways WHERE 1=1"
    args = []
    if g.user["role"] != "admin" and g.user["branch_id"]:
        sql += " AND branch_id=?"; args.append(g.user["branch_id"])
    elif request.args.get("branch_id"):
        sql += " AND branch_id=?"; args.append(request.args.get("branch_id"))
    
    st = request.args.get("status")
    if st: sql += " AND status=?"; args.append(st)

    sql += " ORDER BY id DESC LIMIT 100"
    rows = con.execute(sql, args).fetchall()
    return jsonify(layaways=[detail_layaway(con, r["id"]) for r in rows])

@bp.get("/api/layaways/<int:lid>")
@login_required
def get_layaway(lid):
    r = detail_layaway(db.get_db(), lid)
    return jsonify(r) if r else err("Apartado no encontrado.", 404)