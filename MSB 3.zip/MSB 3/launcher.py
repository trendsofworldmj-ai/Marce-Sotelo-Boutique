"""
Lanzador de escritorio Marcela Boutique:
Inicia el servidor Flask localmente en segundo plano y abre la ventana en el navegador.
"""
import os, sys, threading, time, webbrowser
from app import create_app

def open_browser(port):
    time.sleep(1.2)
    webbrowser.open(f"http://127.0.0.1:{port}")

if __name__ == "__main__":
    # Determinar ruta segura de datos fuera del paquete compilado
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    data_dir = os.path.join(base_dir, "datos")
    os.makedirs(data_dir, exist_ok=True)
    db_file = os.path.join(data_dir, "boutique.db")

    app = create_app(db_file)
    port = 5000

    # Iniciar hilo para abrir el navegador automáticamente
    threading.Thread(target=open_browser, args=(port,), daemon=True).start()

    # Ejecutar servidor escuchando solo en localhost
    app.run(host="127.0.0.1", port=port, threaded=True)