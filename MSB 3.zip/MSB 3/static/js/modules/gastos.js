"use strict";
/* Gastos (administradora): registro y consulta por rango de fechas. Sin borrado: queda historial. */
let gData = null;
async function loadGas() {
  if (!$("gFrom").value) $("gFrom").value = monthStartISO(); if (!$("gTo").value) $("gTo").value = todayISO();
  $("gList").innerHTML = loadingHtml(); const r = await api("/api/expenses" + qs({ from: $("gFrom").value, to: $("gTo").value }));
  if (!r.ok) { $("gList").innerHTML = ""; return toastErr(r) }
  gData = r.d; const cats = Object.entries(r.d.by_category);
  $("gKpis").innerHTML = kpi("Gastos del periodo", mxn(r.d.total), { tone: "gold", note: r.d.expenses.length + " registro(s)" }) +
    (cats.length ? kpi("Categoría mayor", esc(cats[0][0]), { note: mxn(cats[0][1]) }) : "");
  paged($("gList"), r.d.expenses, rows => table([
    { h: "Fecha", c: x => esc(when(x.created_at)) }, { h: "Concepto", c: x => esc(x.concept) }, { h: "Categoría", c: x => badge(x.category) }, { h: "Monto", cls: "num", c: x => mxn(x.amount) }],
    rows, { empty: "Sin gastos en este periodo", hint: "Cambia las fechas o registra un gasto nuevo.", foot: `<tr><td colspan="3">Total</td><td class="num">${mxn(r.d.total)}</td></tr>` }), 20);
}
$("gApply").onclick = () => $("gFrom").value > $("gTo").value ? toast("La fecha inicial no puede ser posterior a la final.", "error") : loadGas();
$("gNew").onclick = () => {
  const cats = gData ? Object.keys(gData.by_category) : [];
  formModal("Registrar gasto", field("gxC", "Concepto", { ph: "Ej. renta del local" }) + `${field("gxK", "Categoría", { ph: "General" })}<datalist id="gxCats">${cats.map(c => `<option value="${esc(c)}">`).join("")}</datalist>` + field("gxA", "Monto (MXN)", { type: "number", min: 0, step: "0.01" }) +
    '<p class="hint">Los gastos no se pueden borrar; si te equivocas, anótalo en un gasto nuevo con la aclaración.</p>', async () => {
    const r = await api("/api/expenses", { concept: $("gxC").value, category: $("gxK").value, amount: Number($("gxA").value) }); if (!r.ok) return r.d.error || "No se pudo guardar.";
    toast("Gasto registrado.", "ok"); loadGas(); return null });
  $("gxK").setAttribute("list", "gxCats");
};
MB.register("gas", { admin: true, title: "Gastos", load: loadGas });
