"use strict";
/* Caja y cortes: sesión de caja (compartida con Caja rápida), resumen, entradas/salidas, cierre e historial. */
let lastClose = null;

async function loadSession() {
  const r = await api("/api/cash/current"); MB.session = r.d.session || null;
  const chip = $("cajaChip");
  chip.textContent = MB.session ? "Caja abierta · fondo " + mxn(MB.session.opening_cents / 100) : "Caja cerrada";
  chip.classList.toggle("on", !!MB.session);
  if (MB.afterSession) MB.afterSession();
}

const diffClass = d => d == null ? "" : d < 0 ? "neg" : d > 0 ? "pos" : "";
function sumHtml(d) {
  const bm = Object.entries(d.sales_by_method).map(([m, v]) => listRow(`<span class="muted">${esc(m)}</span>`, mxn(v))).join("") || '<p class="muted">Sin ventas</p>';
  return listRow("Fondo inicial", mxn(d.opening)) + listRow("Cobros en efectivo", mxn(d.cash_collected)) + listRow("Entradas", mxn(d.entradas)) +
    listRow("Salidas (incluye reembolsos)", "−" + mxn(d.salidas)) + listRow("Efectivo esperado", mxn(d.expected), "total") +
    (d.counted != null ? listRow("Efectivo contado", mxn(d.counted)) + listRow("Diferencia", signed(d.difference), "total " + diffClass(d.difference)) : "") +
    `<h3 style="margin:var(--s4) 0 var(--s2)">Ventas del turno: ${mxn(d.sales_total)}</h3>` + bm + listRow("Canceladas", `${d.cancelled.count} · ${mxn(d.cancelled.total)}`);
}
const mvHtml = l => l.length ? l.map(m => `<div class="list-row"><span>${esc(m.reason)}<small>${esc(when(m.created_at))}</small></span><span class="num ${m.kind === "salida" ? "neg" : "pos"}">${m.kind === "salida" ? "−" : "+"}${mxn(m.amount_cents / 100)}</span></div>`).join("") : '<p class="muted">Sin movimientos.</p>';

async function loadCaja() {
  await loadSession();
  if (!MB.session) {
    $("cajaBody").hidden = true; $("cajaNone").hidden = false;
    $("lastClose").innerHTML = lastClose ? '<h3 style="margin:var(--s3) 0 var(--s2)">Último corte</h3>' + sumHtml(lastClose) : "";
  } else {
    const r = await api("/api/cash/summary");
    if (r.ok) { $("cajaNone").hidden = true; $("cajaBody").hidden = false; $("cajaSum").innerHTML = sumHtml(r.d); $("mvList").innerHTML = mvHtml(r.d.movements) }
  }
  if (isAdmin()) loadHist();
}
$("mvAdd").onclick = () => withBusy($("mvAdd"), async () => {
  const r = await api("/api/cash/movements", { kind: $("mvKind").value, amount: Number($("mvAmt").value), reason: $("mvWhy").value.trim() });
  if (!r.ok) return toastErr(r);
  $("mvAmt").value = $("mvWhy").value = ""; toast("Movimiento registrado.", "ok"); loadCaja();
});
$("closeBtn").onclick = async () => {
  const v = $("cnt").value; if (v === "") return toast("Captura el efectivo contado.", "error");
  if (!await askConfirm(`Vas a cerrar tu caja con ${mxn(v)} contados. Esta acción no se puede deshacer.`, { okText: "Cerrar caja" })) return;
  const r = await withBusy($("closeBtn"), () => api("/api/cash/close", { counted: Number(v) })); if (!r.ok) return toastErr(r);
  lastClose = r.d; $("cnt").value = ""; $("closeInfo").innerHTML = sumHtml(r.d); showModal("closeModal"); loadCaja();
};
$("closeOk").onclick = () => hideModal("closeModal");

async function loadHist() {
  const r = await api("/api/cash/sessions"); if (!r.ok) return; $("hist").hidden = false;
  paged($("histList"), r.d.sessions, rows => table([
    { h: "Caja", c: s => "#" + s.id }, { h: "Cajera", c: s => esc(s.user) }, { h: "Apertura", c: s => esc(when(s.opened_at)) },
    { h: "Estado", c: s => badge(s.status, s.status === "abierta" ? "ok" : "") },
    { h: "Diferencia", cls: "num", c: s => `<span class="${diffClass(s.difference)}">${s.difference == null ? "—" : signed(s.difference)}</span>` },
    { h: "", cls: "actions", c: s => `<button class="btn btn-sm" data-s="${s.id}">Ver</button>` }], rows, { empty: "Aún no hay cajas", hint: "Aparecerán aquí cuando se abra la primera." }), 10);
}
$("histList").addEventListener("click", async e => {
  const b = e.target.closest("[data-s]"); if (!b) return;
  const r = await api("/api/cash/summary?session_id=" + b.dataset.s);
  if (r.ok) showInfo("Caja #" + b.dataset.s, sumHtml(r.d) + '<h3 style="margin:var(--s4) 0 var(--s2)">Movimientos</h3>' + mvHtml(r.d.movements));
});
MB.register("caja", { title: "Caja y cortes", load: loadCaja });
