/* Marcela Boutique — módulo de Traspasos */
(function(){
  async function load(){
    const list = document.getElementById("tList");
    if(!list) return;
    list.innerHTML = '<div class="loading">Cargando traspasos…</div>';
    const st = document.getElementById("tStatus")?.value || "";
    try {
      const res = await api.get(`/api/transfers${st ? `?status=${encodeURIComponent(st)}` : ''}`);
      const tList = res.transfers || [];

      // KPIs
      const kpis = document.getElementById("tKpis");
      if(kpis){
        const sol = tList.filter(t => t.status === "solicitado").length;
        const trans = tList.filter(t => t.status === "en_transito").length;
        const comp = tList.filter(t => t.status === "recibido").length;
        kpis.innerHTML = `
          ${kpi("Por autorizar", sol, "Esperando revisión", sol > 0 ? "is-bad" : "")}
          ${kpi("En tránsito", trans, "Enviados a destino", trans > 0 ? "is-gold" : "")}
          ${kpi("Recibidos", comp, "Completados con éxito")}
        `;
      }

      if(!tList.length){
        list.innerHTML = '<div class="empty"><strong>No hay traspasos registrados</strong></div>';
        return;
      }

      const stBadges = {
        solicitado: badge("Solicitado", "warn"),
        autorizado: badge("Autorizado", "info"),
        en_transito: badge("En tránsito", "gold"),
        recibido: badge("Recibido", "ok"),
        cancelado: badge("Cancelado", "danger")
      };

      list.innerHTML = table(
        ["Folio", "Origen", "Destino", "Partidas", "Estado", "Fecha", "Acciones"],
        tList.map(t => {
          const totalPzas = (t.items || []).reduce((acc, i) => acc + i.qty_requested, 0);
          return [
            `<strong>${t.folio}</strong>`,
            t.origin_branch.name,
            t.dest_branch.name,
            `${totalPzas} pza(s)`,
            stBadges[t.status] || badge(t.status),
            `<small>${t.created_at}</small>`,
            `<div class="actions btn-row">
              <button type="button" class="btn btn-sm" data-view="${t.id}">Detalle</button>
              ${window.currentUser?.role === 'admin' && t.status === 'solicitado' ? `
                <button type="button" class="btn btn-sm btn-primary" data-auth="${t.id}">Autorizar</button>
              ` : ''}
              ${t.status === 'autorizado' ? `
                <button type="button" class="btn btn-sm btn-primary" data-ship="${t.id}">Despachar</button>
              ` : ''}
              ${t.status === 'en_transito' ? `
                <button type="button" class="btn btn-sm btn-primary" data-recv="${t.id}">Recibir</button>
              ` : ''}
              ${['solicitado', 'autorizado', 'en_transito'].includes(t.status) ? `
                <button type="button" class="btn btn-sm btn-danger" data-canc="${t.id}">Cancelar</button>
              ` : ''}
            </div>`
          ];
        })
      );

      // Eventos de botones
      list.querySelectorAll("[data-view]").forEach(b => {
        b.onclick = () => showDetail(tList.find(x => x.id === parseInt(b.dataset.view)));
      });

      list.querySelectorAll("[data-auth]").forEach(b => {
        b.onclick = () => confirm("Autorizar traspaso", "¿Deseas autorizar la salida de mercancía para este traspaso?", async () => {
          await api.post(`/api/transfers/${b.dataset.auth}/authorize`, {});
          toast("Traspaso autorizado.", "ok");
          load();
        });
      });

      list.querySelectorAll("[data-ship]").forEach(b => {
        b.onclick = () => confirm("Despachar mercancía", "Esto descontará las piezas de la sucursal de origen y las pondrá en tránsito. ¿Continuar?", async () => {
          await api.post(`/api/transfers/${b.dataset.ship}/ship`, {});
          toast("Mercancía despachada y en tránsito.", "ok");
          load();
        });
      });

      list.querySelectorAll("[data-recv]").forEach(b => {
        b.onclick = () => {
          const t = tList.find(x => x.id === parseInt(b.dataset.recv));
          receiveModal(t);
        };
      });

      list.querySelectorAll("[data-canc]").forEach(b => {
        b.onclick = () => {
          formModal("Cancelar traspaso", `
            <div class="field"><label>Motivo de cancelación</label><textarea id="tcWhy" class="textarea" placeholder="Escribe el motivo (mín. 5 caracteres)"></textarea></div>
          `, async () => {
            const reason = document.getElementById("tcWhy").value.trim();
            if(reason.length < 5) throw new Error("Escribe un motivo formal de al menos 5 caracteres.");
            await api.post(`/api/transfers/${b.dataset.canc}/cancel`, { reason });
            toast("Traspaso cancelado.", "ok");
            load();
          });
        };
      });

    } catch(e) {
      list.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
    }
  }

  function showDetail(t){
    infoModal(`Traspaso ${t.folio}`, `
      <div class="list-row"><span>Origen</span><strong>${t.origin_branch.name}</strong></div>
      <div class="list-row"><span>Destino</span><strong>${t.dest_branch.name}</strong></div>
      <div class="list-row"><span>Estado</span><strong>${t.status}</strong></div>
      <div class="list-row"><span>Solicitó</span><span>${t.requested_by}</span></div>
      ${t.authorized_by ? `<div class="list-row"><span>Autorizó</span><span>${t.authorized_by}</span></div>` : ''}
      ${t.shipped_by ? `<div class="list-row"><span>Despachó</span><span>${t.shipped_by}</span></div>` : ''}
      ${t.received_by ? `<div class="list-row"><span>Recibió</span><span>${t.received_by}</span></div>` : ''}
      <h3 style="margin:var(--s4) 0 var(--s2)">Prendas</h3>
      ${table(["SKU", "Producto", "Talla/Color", "Solicitadas", "Enviadas", "Recibidas"], (t.items||[]).map(i => [
        `<code>${i.sku}</code>`, i.product_name, `${i.size||'-'} / ${i.color||'-'}`,
        i.qty_requested, i.qty_shipped, i.qty_received
      ]))}
      ${(t.events||[]).length ? `
        <h3 style="margin:var(--s4) 0 var(--s2)">Historial de eventos</h3>
        ${table(["Fecha", "Usuario", "Acción", "Detalle"], t.events.map(e => [
          `<small>${e.created_at}</small>`, e.username, e.action, e.detail || '—'
        ]))}
      ` : ''}
    `);
  }

  function receiveModal(t){
    const rows = (t.items||[]).map(i => `
      <div class="list-row" style="padding:var(--s2) 0">
        <div><strong>${i.sku}</strong> - ${i.product_name} (${i.size||'-'}/${i.color||'-'})<small>Enviadas: ${i.qty_shipped}</small></div>
        <div style="width:90px"><input type="number" class="input input-sm t-rec-qty" data-vid="${i.variant_id}" min="0" value="${i.qty_shipped}"></div>
      </div>
    `).join("");

    formModal(`Recibir traspaso ${t.folio}`, `
      <p class="muted">Confirma las prendas físicas que llegaron a la sucursal. Si una prenda llegó rota o faltó, ajusta la cantidad recibida.</p>
      ${rows}
    `, async () => {
      const items = Array.from(document.querySelectorAll(".t-rec-qty")).map(inp => ({
        variant_id: parseInt(inp.dataset.vid),
        qty: parseInt(inp.value) || 0
      }));
      const res = await api.post(`/api/transfers/${t.id}/receive`, { items });
      if(res.discrepancies && res.discrepancies.length){
        toast(`Recibido con ${res.discrepancies.length} discrepancia(s).`, "warn");
      } else {
        toast("Mercancía recibida e ingresada al inventario.", "ok");
      }
      load();
    });
  }

  async function newTransferModal(){
    const bRes = await api.get("/api/branches");
    const pRes = await api.get("/api/products?all=1");
    const branches = (bRes.branches || []).filter(b => b.active);
    const prods = pRes.products || [];

    const bOpts = branches.map(b => `<option value="${b.id}">${b.name}</option>`).join("");
    const vOpts = [];
    prods.forEach(p => {
      (p.variants || []).forEach(v => {
        vOpts.push(`<option value="${v.id}">${p.name} - ${v.sku} (${v.size || '-'}/${v.color || '-'})</option>`);
      });
    });

    formModal("Nuevo traspaso", `
      <div class="form-grid">
        <div class="field"><label>Sucursal origen (de donde sale)</label><select id="ntO" class="select">${bOpts}</select></div>
        <div class="field"><label>Sucursal destino (a donde llega)</label><select id="ntD" class="select">${bOpts}</select></div>
      </div>
      <div class="field" style="margin-top:var(--s2)"><label>Prenda a traspasar</label><select id="ntV" class="select">${vOpts.join("")}</select></div>
      <div class="field"><label>Cantidad de piezas</label><input id="ntQ" type="number" class="input" min="1" value="1"></div>
      <div class="field"><label>Notas / Motivo</label><textarea id="ntN" class="textarea" placeholder="Opcional"></textarea></div>
    `, async () => {
      const origin_branch_id = parseInt(document.getElementById("ntO").value);
      const dest_branch_id = parseInt(document.getElementById("ntD").value);
      const vid = parseInt(document.getElementById("ntV").value);
      const qty = parseInt(document.getElementById("ntQ").value) || 0;
      const notes = document.getElementById("ntN").value.trim();

      if(origin_branch_id === dest_branch_id) throw new Error("La sucursal de origen y destino deben ser distintas.");
      if(qty <= 0) throw new Error("La cantidad debe ser mayor a 0.");

      await api.post("/api/transfers", {
        origin_branch_id,
        dest_branch_id,
        items: [{ variant_id: vid, qty }],
        notes
      });
      toast("Traspaso solicitado exitosamente.", "ok");
      load();
    });
  }

  function setup(){
    const btnNew = document.getElementById("tNew");
    if(btnNew) btnNew.onclick = newTransferModal;
    const btnApp = document.getElementById("tApply");
    if(btnApp) btnApp.onclick = load;
  }

  views.register("transf", load);
  document.addEventListener("DOMContentLoaded", setup);
})();
