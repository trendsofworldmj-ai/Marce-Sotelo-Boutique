"use strict";
/* Respaldos (administradora): crear, descargar y restaurar. */
async function loadResp() {
  $("rList").innerHTML = loadingHtml(); const r = await api("/api/backups"); if (!r.ok) { $("rList").innerHTML = ""; return toastErr(r) }
  paged($("rList"), r.d.backups, rows => table([
    { h: "Archivo", c: b => esc(b.name) }, { h: "Tipo", c: b => badge(b.kind, b.kind === "manual" ? "gold" : "") }, { h: "Fecha", c: b => esc(b.created_at) }, { h: "Tamaño", cls: "num", c: b => b.size_kb + " KB" },
    { h: "", cls: "actions", c: b => `<a class="btn btn-sm" href="/api/backups/${encodeURIComponent(b.name)}/download">Descargar</a> <button class="btn btn-sm btn-danger" data-n="${esc(b.name)}">Restaurar</button>` }],
    rows, { empty: "Aún no hay respaldos", hint: "Crea el primero con «Crear respaldo ahora»." }), 15);
}
$("rNew").onclick = () => withBusy($("rNew"), async () => { const r = await api("/api/backups", {}); r.ok ? (toast("Respaldo creado: " + r.d.name, "ok"), loadResp()) : toastErr(r) });
$("rList").addEventListener("click", e => {
  const b = e.target.closest("button[data-n]"); if (!b) return; const n = b.dataset.n;
  formModal("Restaurar respaldo", `<p>Vas a reemplazar <b>toda la información actual</b> con el respaldo <b>${esc(n)}</b>. Lo registrado después de esa fecha se perderá, aunque antes se guarda una copia automática para poder deshacerlo.</p>${field("rc", "Para confirmar, escribe RESTAURAR")}`, async () => {
    const r = await api("/api/backups/restore", { name: n, confirm: $("rc").value.trim() }); if (!r.ok) return r.d.error || "No se pudo restaurar.";
    toast("Restaurado. Copia previa: " + r.d.safety_copy, "ok"); setTimeout(() => location.reload(), 1800); return null;
  }, { okText: "Restaurar" });
});
MB.register("resp", { admin: true, title: "Respaldos", load: loadResp });
