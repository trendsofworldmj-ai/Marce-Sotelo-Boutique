/* Marcela Boutique — módulo de Apartados */
(function(){
  async function load(){
    const list = document.getElementById("apList");
    if(!list) return;
    list.innerHTML = '<div class="loading">Cargando apartados…</div>';
    const st = document.getElementById("apStatus")?.value || "";
    try {
      const res = await api.get(`/api/layaways${st ? `?status=${encodeURIComponent(st)}` : ''}`);
      const apList = res.layaways || [];

      // KPIs
      const kpis = document.getElementById("apKpis");
      if(kpis){
        const vig = apList.filter(a => a.status === "vigente");
        const balance = vig.reduce((acc, a) => acc + a.balance, 0);
        kpis.innerHTML = `
          ${kpi("Apartados vigentes", vig.length, "Mercancía reservada", vig.length > 0 ? "is-gold" : "")}
          ${kpi("Saldo por cobrar", fmt.money(balance), "Por liquidar en caja")}
          ${kpi("Total registrados", apList.length, "En el periodo")}
        `;
      }

      if(!apList.length){
        list.innerHTML = '<div class="empty"><strong>No hay apartados con ese criterio</strong></div>';
        return;
      }

      const stBadges = {
        vigente: badge("Vigente", "gold"),
        liquidado: badge("Liquidado", "ok"),
        cancelado: badge("Cancelado", "danger")
      };

      list.innerHTML = table(
        ["Folio", "Cliente", "Teléfono", "Total", "Abonado", "Saldo", "Vence", "Estado", "Acciones"],
        apList.map(a => [
          `<strong>${a.folio}</strong>`,
          a.customer_name,
          a.customer_phone || '<span class="faint">—</span>',
          fmt.money(a.total),
          fmt.money(a.paid),
          `<span class="${a.balance > 0 ? 'neg' : 'ok'}">${fmt.money(a.balance)}</span>`,
          `<small>${a.expires_at ? a.expires_at.split(' ')[0] : '—'}</small>`,
          stBadges[a.status] || badge(a.status),
          `<div class="actions btn-row">
            <button type="button" class="btn btn-sm" data-view="${a.id}">Ver</button>
            ${a.status === 'vigente' && a.balance > 0 ? `
              <button type="button" class="btn btn-sm btn-primary" data-pay="${a.id}">Abonar</button>
            ` : ''}
            ${a.status === 'vigente' && a.balance <= 0 ? `
              <button type="button" class="btn btn-sm btn-primary" data-deliv="${a.id}">Entregar</button>
            ` : ''}
            ${a.status === 'vigente' ? `
              <button type="button" class="btn btn-sm btn-danger" data-canc="${a.id}">Cancelar</button>
            ` : ''}
          </div>`
        ])
      );

      list.querySelectorAll("[data-view]").forEach(b => {
        b.onclick = () => showDetail(apList.find(x => x.id === parseInt(b.dataset.view)));
      });

      list.querySelectorAll("[data-pay]").forEach(b => {
        b.onclick = () => {
          const a = apList.find(x => x.id === parseInt(b.dataset.pay));
          payModal(a);
        };
      });

      list.querySelectorAll("[data-deliv]").forEach(b => {
        b.onclick = () => confirm("Entregar prendas apartadas", "El apartado está liquidado. Esto descontará físicamente las piezas del inventario como entregadas. ¿Continuar?", async () => {
          await api.post(`/api/layaways/${b.dataset.deliv}/deliver`, {});
          toast("Apartado entregado con éxito.", "ok");
          load();
        });
      });

      list.querySelectorAll("[data-canc]").forEach(b => {
        b.onclick = () => {
          formModal("Cancelar apartado", `
            <div class="field"><label>Motivo de cancelación</label><textarea id="acWhy" class="textarea" placeholder="Escribe el motivo (mín. 5 caracteres)"></textarea></div>
          `, async () => {
            const reason = document.getElementById("acWhy").value.trim();
            if(reason.length < 5) throw new Error("Escribe un motivo formal de al menos 5 caracteres.");
            await api.post(`/api/layaways/${b.dataset.canc}/cancel`, { reason });
            toast("Apartado cancelado y prendas liberadas.", "ok");
            load();
          });
        };
      });

    } catch(e) {
      list.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
    }
  }

  function showDetail(a){
    infoModal(`Apartado ${a.folio}`, `
      <div class="list-row"><span>Cliente</span><strong>${a.customer_name} (${a.customer_phone || 'Sin tel.'})</strong></div>
      <div class="list-row"><span>Sucursal</span><span>${a.branch_name}</span></div>
      <div class="list-row"><span>Estado</span><strong>${a.status.toUpperCase()}</strong></div>
      <div class="list-row"><span>Total</span><span>${fmt.money(a.total)}</span></div>
      <div class="list-row"><span>Abonado</span><span class="ok">${fmt.money(a.paid)}</span></div>
      <div class="list-row"><span>Saldo restante</span><span class="${a.balance > 0 ? 'neg' : 'ok'}">${fmt.money(a.balance)}</span></div>
      <div class="list-row"><span>Fecha límite</span><span>${a.expires_at}</span></div>
      <h3 style="margin:var(--s4) 0 var(--s2)">Prendas apartadas</h3>
      ${table(["SKU", "Producto", "Talla/Color", "Cant.", "Precio Unit."], (a.items||[]).map(i => [
        `<code>${i.sku}</code>`, i.product_name, `${i.size||'-'} / ${i.color||'-'}`, i.qty, fmt.money(i.price_cents / 100)
      ]))}
      <h3 style="margin:var(--s4) 0 var(--s2)">Historial de abonos</h3>
      ${table(["Fecha", "Atendió", "Método", "Monto"], (a.payments||[]).map(p => [
        `<small>${p.created_at}</small>`, p.cashier, p.method, fmt.money(p.amount_cents / 100)
      ]))}
    `);
  }

  function payModal(a){
    formModal(`Registrar abono a ${a.folio}`, `
      <p class="muted">Saldo pendiente: <strong>${fmt.money(a.balance)}</strong></p>
      <div class="field"><label>Monto a abonar (MXN)</label><input id="apAmt" type="number" step="0.01" min="1" max="${a.balance}" class="input" value="${a.balance}"></div>
      <div class="field"><label>Método de pago</label><select id="apMth" class="select"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta</option><option value="transferencia">Transferencia</option></select></div>
    `, async () => {
      const amount = parseFloat(document.getElementById("apAmt").value) || 0;
      const method = document.getElementById("apMth").value;
      if(amount <= 0 || amount > a.balance) throw new Error("Monto no válido.");
      await api.post(`/api/layaways/${a.id}/payments`, { amount, method });
      toast("Abono registrado en caja.", "ok");
      load();
    });
  }

  function setup(){
    const btnApp = document.getElementById("apApply");
    if(btnApp) btnApp.onclick = load;
  }

  views.register("apart", load);
  document.addEventListener("DOMContentLoaded", setup);
})();
