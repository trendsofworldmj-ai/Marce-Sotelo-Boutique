"use strict";
/* Reportes y balance (administradora). Solo presenta lo que calcula el servidor; no recalcula cifras financieras. */
function setQuick(q) {
  document.querySelectorAll("[data-rq]").forEach(b => b.setAttribute("aria-pressed", b.dataset.rq === q));
  $("rFrom").value = q === "today" ? todayISO() : monthStartISO(); $("rTo").value = todayISO();
}
async function loadRep() {
  if (!$("rFrom").value) setQuick("month");
  if ($("rFrom").value > $("rTo").value) return toast("La fecha inicial no puede ser posterior a la final.", "error");
  $("rBody").innerHTML = loadingHtml("Calculando…"); const a = qs({ from: $("rFrom").value, to: $("rTo").value });
  const [s, t, d] = await Promise.all([api("/api/reports/summary" + a), api("/api/reports/top-products" + a), api("/api/reports/sales-by-day" + a)]);
  if (!s.ok) { $("rBody").innerHTML = ""; return toastErr(s) }
  const x = s.d, m = Object.entries(x.sales.by_method), max = Math.max(1, ...d.d.days.map(v => v.total));
  $("rBody").innerHTML = `<div class="kpis">${kpi("Ventas", mxn(x.sales.total), { tone: "gold", note: `${x.sales.count} venta(s) · ticket promedio ${mxn(x.sales.avg_ticket)}` })}
    ${kpi("Utilidad bruta", mxn(x.profit.gross_profit), { note: `Margen ${x.profit.gross_margin_pct}% · costo de ventas ${mxn(x.profit.cogs)}` })}
    ${kpi("Gastos", mxn(x.profit.expenses))}${kpi("Utilidad neta", mxn(x.profit.net), { tone: x.profit.net < 0 ? "bad" : "gold", note: "Utilidad bruta − gastos" })}</div>
    <div class="stack cols-2"><section class="card"><h2>Ventas por método de pago</h2>${m.length ? m.map(([k, v]) => listRow(esc(k), mxn(v))).join("") : emptyHtml("Sin ventas en el periodo")}
      ${listRow("Descuentos otorgados", mxn(x.sales.discounts))}${listRow("Ventas canceladas (no suman)", `${x.sales.cancelled.count} · ${mxn(x.sales.cancelled.total)}`)}</section>
     <section class="card"><h2>Flujo de efectivo (aproximado)</h2>${listRow("Ventas cobradas", mxn(x.cash_flow.in_sales))}${listRow("Gastos", "−" + mxn(x.cash_flow.out_expenses))}${listRow("Pagos a proveedores", "−" + mxn(x.cash_flow.out_supplier_payments))}${listRow("Flujo neto", mxn(x.cash_flow.net), "total")}
      <p class="hint" style="margin-top:var(--s2)">No resta reembolsos ni es el saldo de caja.</p></section>
     <section class="card"><h2>Compras y proveedores</h2>${listRow("Compras recibidas en el periodo", mxn(x.purchases.received_total))}${listRow("Pagado en el periodo", mxn(x.purchases.paid_in_period))}${listRow("Saldo total con proveedores", mxn(x.purchases.supplier_balance_total), "total")}</section>
     <section class="card"><h2>Inventario hoy</h2>${listRow("Valor a costo", mxn(x.inventory.value_at_cost))}${listRow("Valor a precio de venta", mxn(x.inventory.value_at_price), "total")}</section></div>
    <section class="card"><h2>Productos más vendidos</h2>${t.ok ? table([{ h: "Producto", c: p => esc(p.name) }, { h: "Piezas", cls: "num", c: p => p.units }, { h: "Ingreso (precio de lista)", cls: "num", c: p => mxn(p.revenue) }, { h: "Utilidad", cls: "num", c: p => mxn(p.profit) }], t.d.products, { empty: "Sin ventas en el periodo" }) : ""}</section>
    <section class="card"><h2>Ventas por día</h2>${d.ok && d.d.days.length ? `<div class="bars" aria-hidden="true">${d.d.days.map(v => `<i style="height:${Math.max(3, Math.round(v.total * 100 / max))}%" title="${esc(v.date)}: ${mxn(v.total)}"></i>`).join("")}</div>
      <div id="rDays" style="margin-top:var(--s3)"></div>` : emptyHtml("Sin ventas en el periodo")}</section>`;
  if (d.ok && d.d.days.length) paged($("rDays"), d.d.days.slice().reverse(), rows => table([{ h: "Día", c: v => esc(v.date) }, { h: "Ventas", cls: "num", c: v => v.count }, { h: "Total", cls: "num", c: v => mxn(v.total) }], rows), 10);
}
$("rApply").onclick = () => { document.querySelectorAll("[data-rq]").forEach(b => b.setAttribute("aria-pressed", "false")); loadRep() };
document.querySelectorAll("[data-rq]").forEach(b => b.onclick = () => { setQuick(b.dataset.rq); loadRep() });
MB.register("rep", { admin: true, title: "Reportes y balance", load: loadRep });
