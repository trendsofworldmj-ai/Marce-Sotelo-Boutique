"use strict";
/* Productos e inventario (administradora): catálogo, variantes, ajustes, movimientos, importación y exportación CSV. */
let pAll = [];
const vname = v => [v.size, v.color].filter(Boolean).join(" / ") || "Única";
async function loadProd() {
  $("pList").innerHTML = loadingHtml("Cargando catálogo…");
  const r = await api("/api/products?all=1"); if (!r.ok) { $("pList").innerHTML = ""; return toastErr(r) }
  pAll = r.d.products; renderProd();
}
function renderProd() {
  const q = $("pq").value.trim().toLowerCase(), inact = $("pInact").checked, low = $("pLow").checked;
  let l = pAll.filter(p => inact || p.active);
  if (q) l = l.filter(p => (p.name + " " + (p.category || "") + " " + (p.brand || "")).toLowerCase().includes(q) || p.variants.some(v => (v.sku + " " + (v.barcode || "")).toLowerCase().includes(q)));
  if (low) l = l.filter(p => p.variants.some(v => v.active && v.low));
  const act = pAll.filter(p => p.active), nLow = act.reduce((n, p) => n + p.variants.filter(v => v.active && v.low).length, 0);
  const pieces = act.reduce((n, p) => n + p.variants.filter(v => v.active).reduce((s, v) => s + v.stock, 0), 0);
  $("pKpis").innerHTML = kpi("Productos activos", act.length) + kpi("Piezas en existencia", pieces) + kpi("Variantes con existencia baja", nLow, { tone: nLow ? "bad" : "" });
  $("pCount").textContent = `${l.length} producto(s) · ${nLow} variante(s) con existencia baja`;
  $("pList").innerHTML = l.length ? l.map(p => {
    const vs = p.variants.filter(v => inact || v.active);
    return `<div class="pbox ${p.active ? "" : "off"}"><div class="pbox-head"><div><b>${esc(p.name)}</b> ${p.active ? "" : badge("inactivo")}
      <small>${esc([p.category, p.brand].filter(Boolean).join(" · ") || "Sin categoría")} · costo ${mxn(p.cost)} · precio ${mxn(p.price)}</small></div>
      <div class="btn-row"><button class="btn btn-sm" data-a="editp" data-pid="${p.id}">Editar</button><button class="btn btn-sm" data-a="addv" data-pid="${p.id}">+ Variante</button><button class="btn btn-sm btn-ghost" data-a="togp" data-pid="${p.id}">${p.active ? "Desactivar" : "Activar"}</button></div></div>` +
      (vs.length ? table([
        { h: "Variante", c: v => `${esc(vname(v))}${v.active ? "" : " " + badge("variante inactiva")}<small>SKU ${esc(v.sku)}${v.barcode ? " · " + esc(v.barcode) : ""}</small>` },
        { h: "Existencia", cls: "num", c: v => `<span class="${v.low && v.active ? "neg" : ""}">${v.stock} pzas</span><small>mínimo ${v.min_stock}</small>` },
        { h: "", cls: "actions", c: v => ["adj:Ajustar", "editv:Editar", "hist:Historial", "togv:" + (v.active ? "Desactivar" : "Activar")].map(x => { const [a, t] = x.split(":"); return `<button class="btn btn-sm ${a === "togv" ? "btn-ghost" : ""}" data-a="${a}" data-pid="${p.id}" data-vid="${v.id}">${t}</button>` }).join(" ") }], vs)
        : '<p class="muted" style="padding:var(--s3) var(--s4);margin:0">Sin variantes visibles.</p>') + "</div>";
  }).join("") : `<section class="card">${emptyHtml("No hay productos con ese filtro", "Crea uno nuevo o importa tu catálogo desde un CSV.")}</section>`;
}
[$("pq"), $("pLow"), $("pInact")].forEach(i => i.oninput = renderProd);

const vrow = () => `<div class="vrow"><input class="input input-sm vs" placeholder="Talla" aria-label="Talla"><input class="input input-sm vc" placeholder="Color" aria-label="Color"><input class="input input-sm vk" placeholder="SKU (opcional)" aria-label="SKU"><input class="input input-sm vb" placeholder="Código de barras" aria-label="Código de barras"><input class="input input-sm vn" type="number" min="0" step="1" placeholder="Existencia" aria-label="Existencia inicial" value="0"><input class="input input-sm vm" type="number" min="0" step="1" placeholder="Mínimo" aria-label="Mínimo" value="1"></div>`;
const vhead = '<div class="vrow vh"><small>Talla</small><small>Color</small><small>SKU</small><small>Código de barras</small><small>Existencia inicial</small><small>Mínimo</small></div>';
const collectV = () => [...$("fBody").querySelectorAll(".vrow:not(.vh)")].map(r => ({ size: r.querySelector(".vs").value, color: r.querySelector(".vc").value, sku: r.querySelector(".vk").value, barcode: r.querySelector(".vb").value, stock: r.querySelector(".vn").value, min_stock: r.querySelector(".vm").value }));
const pFields = p => `<div class="form-grid">${field("fn", "Nombre", { value: p ? p.name : "" })}${field("fc", "Categoría", { value: p ? p.category || "" : "" })}${field("fb", "Marca", { value: p ? p.brand || "" : "" })}
  ${field("fcost", "Costo unitario (MXN)", { type: "number", min: 0, step: "0.01", value: p ? p.cost : 0 })}${field("fp", "Precio de venta (MXN)", { type: "number", min: 0, step: "0.01", value: p ? p.price : "" })}</div>`;
const saved = (msg, e) => { toast(msg, "ok"); loadProd(); return null };
function newProduct() {
  formModal("Nuevo producto", pFields(null) + '<h3 style="margin:var(--s3) 0 var(--s1)">Variantes (talla / color)</h3>' + vhead + vrow() + '<button id="fAddV" type="button" class="btn btn-sm" style="margin-top:var(--s2)">+ Otra variante</button>', async () => {
    const r = await api("/api/products", { name: $("fn").value, category: $("fc").value, brand: $("fb").value, cost: $("fcost").value || 0, price: $("fp").value, variants: collectV() });
    return r.ok ? saved("Producto creado.") : r.d.error || "No se pudo guardar.";
  }, { wide: true });
  $("fAddV").onclick = () => $("fAddV").insertAdjacentHTML("beforebegin", vrow());
}
function editProduct(p) {
  formModal("Editar producto", pFields(p) + '<p class="hint">El costo se recalcula como promedio ponderado al recibir compras. El cambio manual queda en auditoría.</p>', async () => {
    const r = await api("/api/products/" + p.id, { name: $("fn").value, category: $("fc").value, brand: $("fb").value, cost: $("fcost").value || 0, price: $("fp").value }, "PATCH");
    return r.ok ? saved("Producto actualizado.") : r.d.error || "No se pudo guardar.";
  });
}
function addVariantForm(p) {
  formModal("Nueva variante · " + p.name, vhead + vrow(), async () => {
    const r = await api(`/api/products/${p.id}/variants`, collectV()[0]);
    return r.ok ? saved("Variante creada.") : r.d.error || "No se pudo guardar.";
  }, { wide: true });
}
function editVariant(p, v) {
  formModal(`Editar variante · ${p.name}`, `<div class="form-grid">${field("ev1", "Talla", { value: v.size || "" })}${field("ev2", "Color", { value: v.color || "" })}${field("ev3", "SKU", { value: v.sku })}
    ${field("ev4", "Código de barras", { value: v.barcode || "" })}${field("ev5", "Existencia mínima", { type: "number", min: 0, step: 1, value: v.min_stock })}</div>`, async () => {
    const r = await api("/api/variants/" + v.id, { size: $("ev1").value, color: $("ev2").value, sku: $("ev3").value, barcode: $("ev4").value, min_stock: $("ev5").value }, "PATCH");
    return r.ok ? saved("Variante actualizada.") : r.d.error || "No se pudo guardar.";
  });
}
function adjustStock(p, v) {
  formModal(`Ajustar existencias · ${p.name} (${vname(v)})`, `<p>Existencia actual: <b>${v.stock}</b></p>${field("fd", "Cantidad a sumar (+) o restar (−)", { type: "number", step: 1 })}${field("fr", "Motivo (obligatorio)", { ph: "Ej. conteo físico, merma, daño" })}`, async () => {
    const r = await api(`/api/variants/${v.id}/adjust`, { delta: Number($("fd").value), reason: $("fr").value.trim() });
    return r.ok ? saved("Existencia actualizada: " + r.d.stock) : r.d.error || "No se pudo ajustar.";
  });
}
const KIND = { inicial: "Alta inicial", compra: "Compra", venta: "Venta", devolucion: "Devolución", ajuste: "Ajuste" };
async function showMoves(vid, title) {
  const r = await api("/api/inventory/movements" + (vid ? "?variant_id=" + vid : "")); if (!r.ok) return toastErr(r);
  showInfo(title, table([
    { h: "Movimiento", c: m => `${esc(KIND[m.kind] || m.kind)}<small>${esc(m.sku || "")}</small>` }, { h: "Fecha", c: m => esc(when(m.created_at)) }, { h: "Usuario", c: m => esc(m.username || "—") },
    { h: "Motivo", c: m => esc(m.reason || "") }, { h: "Piezas", cls: "num", c: m => `<b class="${m.qty < 0 ? "neg" : "pos"}">${m.qty > 0 ? "+" : ""}${m.qty}</b>` }], r.d.movements, { empty: "Sin movimientos" }));
}
$("pMov").onclick = () => showMoves(null, "Últimos movimientos de inventario");
$("pNew").onclick = newProduct;
$("pList").onclick = async e => {
  const b = e.target.closest("button[data-a]"); if (!b) return;
  const p = pAll.find(x => x.id == b.dataset.pid), v = p && p.variants.find(x => x.id == b.dataset.vid), a = b.dataset.a; if (!p) return;
  if (a === "editp") return editProduct(p); if (a === "addv") return addVariantForm(p); if (a === "adj") return adjustStock(p, v); if (a === "editv") return editVariant(p, v);
  if (a === "hist") return showMoves(v.id, `Historial · ${p.name} (${vname(v)})`);
  if (a === "togp") {
    if (p.active && !await askConfirm(`¿Desactivar «${p.name}»? Dejará de aparecer en caja; el historial se conserva.`, { danger: true, okText: "Desactivar" })) return;
    const r = await api("/api/products/" + p.id, { active: !p.active }, "PATCH"); r.ok ? (toast(p.active ? "Producto desactivado." : "Producto activado.", "ok"), loadProd()) : toastErr(r);
  }
  if (a === "togv") {
    if (v.active && v.stock > 0 && !await askConfirm(`Esta variante aún tiene ${v.stock} pieza(s). Si la desactivas no se podrá vender. ¿Continuar?`, { danger: true, okText: "Desactivar" })) return;
    const r = await api("/api/variants/" + v.id, { active: !v.active }, "PATCH"); r.ok ? (toast(v.active ? "Variante desactivada." : "Variante activada.", "ok"), loadProd()) : toastErr(r);
  }
};
$("pImp").onclick = () => $("pFile").click();
$("pFile").onchange = async e => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  if (f.size > 1e6) return toast("Archivo demasiado grande (máximo 1 MB).", "error");
  const text = await f.text(); if (!await askConfirm(`Importar «${f.name}»: los SKU que ya existen se omiten y, si hay errores, no se importa nada.`)) return;
  const r = await api("/api/inventory/import", { csv: text });
  if (!r.ok) return showInfo("No se importó nada", `<div class="alert alert-danger">${esc(r.d.error)}</div>` + (r.d.detalles || []).map(x => `<div class="list-row"><small>${esc(x)}</small></div>`).join(""));
  toast(`Importados ${r.d.productos} producto(s), ${r.d.variantes} variante(s).` + (r.d.omitidos.length ? ` Omitidos: ${r.d.omitidos.length}.` : ""), "ok"); loadProd();
};
MB.register("prod", { admin: true, title: "Productos e inventario", load: loadProd });
