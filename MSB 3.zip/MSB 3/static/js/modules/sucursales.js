/* Marcela Boutique — módulo de Sucursales */
(function(){
  async function load(){
    const list = document.getElementById("sucList");
    if(!list) return;
    list.innerHTML = '<div class="loading">Cargando sucursales…</div>';
    try {
      const res = await api.get("/api/branches");
      const bList = res.branches || [];
      if(!bList.length){
        list.innerHTML = '<div class="empty"><strong>No hay sucursales</strong></div>';
        return;
      }
      list.innerHTML = table(
        ["Código", "Nombre", "Tipo", "Teléfono", "Dirección", "Estado", "Acciones"],
        bList.map(b => [
          `<strong>${b.code}</strong>`,
          b.name,
          badge(b.kind === 'maestra' ? 'Administración' : 'Tienda física', b.kind === 'maestra' ? 'gold' : 'info'),
          b.phone || '<span class="faint">—</span>',
          b.address || '<span class="faint">—</span>',
          badge(b.active ? 'Activa' : 'Inactiva', b.active ? 'ok' : 'danger'),
          `<div class="actions btn-row">
            <button type="button" class="btn btn-sm" data-edit="${b.id}">Editar</button>
            ${b.code !== 'SJO' ? `<button type="button" class="btn btn-sm ${b.active ? 'btn-danger' : ''}" data-tog="${b.id}" data-act="${b.active?0:1}">
              ${b.active ? 'Desactivar' : 'Activar'}
            </button>` : ''}
          </div>`
        ])
      );

      list.querySelectorAll("[data-edit]").forEach(btn => {
        btn.onclick = () => {
          const b = bList.find(x => x.id === parseInt(btn.dataset.edit));
          editModal(b);
        };
      });

      list.querySelectorAll("[data-tog]").forEach(btn => {
        btn.onclick = () => {
          const bid = btn.dataset.tog;
          const act = btn.dataset.act === "1";
          confirm(
            act ? "Activar sucursal" : "Desactivar sucursal",
            `¿Deseas ${act ? 'activar' : 'desactivar'} esta sucursal?`,
            async () => {
              await api.patch(`/api/branches/${bid}`, { active: act });
              toast(`Sucursal ${act ? 'activada' : 'desactivada'}.`, "ok");
              load();
            }
          );
        };
      });
    } catch(e) {
      list.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
    }
  }

  function editModal(b){
    formModal("Editar sucursal", `
      <div class="field"><label>Nombre</label><input id="sbN" class="input" value="${b.name}"></div>
      <div class="field"><label>Teléfono</label><input id="sbP" class="input" value="${b.phone || ''}"></div>
      <div class="field"><label>Dirección</label><textarea id="sbA" class="textarea">${b.address || ''}</textarea></div>
    `, async () => {
      const name = document.getElementById("sbN").value.trim();
      const phone = document.getElementById("sbP").value.trim();
      const address = document.getElementById("sbA").value.trim();
      if(!name) throw new Error("El nombre es obligatorio.");
      await api.patch(`/api/branches/${b.id}`, { name, phone, address });
      toast("Sucursal actualizada.", "ok");
      load();
    });
  }

  function setup(){
    const btnNew = document.getElementById("sucNew");
    if(btnNew){
      btnNew.onclick = () => {
        formModal("Nueva sucursal", `
          <div class="field"><label>Código (2-10 letras)</label><input id="nbC" class="input" placeholder="ej. SUR" style="text-transform:uppercase"></div>
          <div class="field"><label>Nombre</label><input id="nbN" class="input" placeholder="ej. Sucursal Sur"></div>
          <div class="field"><label>Tipo</label><select id="nbK" class="select"><option value="operativa">Tienda física (operativa)</option><option value="maestra">Administración Central (maestra)</option></select></div>
          <div class="field"><label>Teléfono</label><input id="nbP" class="input" placeholder="Opcional"></div>
          <div class="field"><label>Dirección</label><textarea id="nbA" class="textarea" placeholder="Opcional"></textarea></div>
        `, async () => {
          const code = document.getElementById("nbC").value.trim().toUpperCase();
          const name = document.getElementById("nbN").value.trim();
          const kind = document.getElementById("nbK").value;
          const phone = document.getElementById("nbP").value.trim();
          const address = document.getElementById("nbA").value.trim();
          if(!code || code.length < 2) throw new Error("Código requerido (mín. 2 caracteres).");
          if(!name) throw new Error("El nombre es obligatorio.");
          await api.post("/api/branches", { code, name, kind, phone, address });
          toast("Sucursal creada con éxito.", "ok");
          load();
        });
      };
    }
  }

  views.register("suc", load, ["admin"]);
  document.addEventListener("DOMContentLoaded", setup);
})();
