"use strict";
/* Compras y proveedores (administradora). Recibir una compra da la entrada al inventario una sola vez (lo garantiza el servidor). */
let cPurch = [], cSupp = [], cTab = "compras";
const PSTATUS = { pendiente: "warn", recibida: "ok", cancelada: "danger" };
const PAY_METHODS = [["efectivo", "Efectivo"], ["transferencia", "Transferencia"], ["tarjeta", "Tarjeta"], ["otro", "Otro"]];

async function loadComp() {
  $("cList").innerHTML = loadingHtml(); $("sList").innerHTML = loadingHtml();
  const [a, b, s] = await Promise.all([api("/api/purchases"), api("/api/suppliers"), api("/api/reports/summary")]);
  if (!a.ok) { $("cList").innerHTML = ""; return toastErr(a) }
  cPurch = a.d.purchases; cSupp = b.ok ? b.d.suppliers : [];
  const pend = cPurch.filter(p => p.status === "pendiente").length;
  $("cKpis").innerHTML = kpi("Compras por recibir", pend, { tone: pend ? "gold" : "" }) +
    (s.ok ? kpi("Saldo con proveedores", mxn(s.d.purchases.supplier_balance_total), { note: "Incluye compras aún no recibidas", tone: s.d.purchases.supplier_balance_total > 0 ? "gold" : "" }) : "") + kpi("Proveedores activos", cSupp.filter(x => x.active).length);
  renderPurch(); renderSupp();
}
function renderPurch() {
  paged($("cList"), cPurch, rows => table([
    { h: "Compra", c: p => "#" + p.id + `<small>${esc(when(p.created_at))}</small>` }, { h: "Proveedor", c: p => esc(p.supplier || "—") }, { h: "Estado", c: p => badge(p.status, PSTATUS[p.status]) },
    { h: "Total", cls: "num", c: p => mxn(p.total) }, { h: "Pagado", cls: "num", c: p => mxn(p.paid) }, { h: "Saldo", cls: "num", c: p => `<span class="${p.balance > 0 && p.status !== "cancelada" ? "pos" : ""}">${p.status === "cancelada" ? "—" : mxn(p.balance)}</span>` },
    { h: "", cls: "actions", c: p => `<button class="btn btn-sm" data-pa="view" data-id="${p.id}">Detalle</button>` +
      (p.status === "pendiente" ? ` <button class="btn btn-sm btn-primary" data-pa="recv" data-id="${p.id}">Recibir</button>` : "") +
      (p.status !== "cancelada" && p.balance > 0 ? ` <button class="btn btn-sm" data-pa="pay" data-id="${p.id}">Pagar</button>` : "") +
      (p.status === "pendiente" ? ` <button class="btn btn-sm btn-danger" data-pa="cancel" data-id="${p.id}">Cancelar</button>` : "") }],
    rows, { empty: "Aún no hay compras", hint: "Registra la primera con «Nueva compra»." }), 15);
}
function renderSupp() {
  $("sList").innerHTML = table([
    { h: "Proveedor", c: s => esc(s.name) + (s.notes ? `<small>${esc(s.notes)}</small>` : "") }, { h: "Teléfono", c: s => esc(s.phone || "—") }, { h: "Estado", c: s => badge(s.active ? "activo" : "inactivo", s.active ? "ok" : "") },
    { h: "", cls: "actions", c: s => `<button class="btn btn-sm" data-sa="edit" data-id="${s.id}">Editar</button> <button class="btn btn-sm btn-ghost" data-sa="tog" data-id="${s.id}">${s.active ? "Desactivar" : "Activar"}</button>` }],
    cSupp, { empty: "Aún no hay proveedores", hint: "Agrega uno para poder registrar compras." });
}
document.querySelectorAll("[data-ctab]").forEach(b => b.onclick = () => {
  cTab = b.dataset.ctab; document.querySelectorAll("[data-ctab]").forEach(x => x.setAttribute("aria-pressed", x === b));
  $("cPane").hidden = cTab !== "compras"; $("sPane").hidden = cTab !== "prov"; $("cNew").hidden = cTab !== "compras"; $("sNew").hidden = cTab !== "prov";
});

/* --- nueva compra --- */
async function newPurchase() {
  const act = cSupp.filter(s => s.active); if (!act.length) return toast("Primero registra un proveedor (pestaña Proveedores).", "error");
  const r = await api("/api/products?all=1"); if (!r.ok) return toastErr(r);
  const vars = r.d.products.filter(p => p.active).flatMap(p => p.variants.filter(v => v.active).map(v => ({ id: v.id, cost: p.cost, label: `${p.name} — ${[v.size, v.color].filter(Boolean).join(" / ") || "Única"} (${v.sku})` })));
  if (!vars.length) return toast("Primero registra productos con variantes.", "error");
  const vopts = vars.map(v => `<option value="${v.id}" data-cost="${v.cost}">${esc(v.label)}</option>`).join("");
  const line = () => `<div class="vrow cp-line" style="grid-template-columns:3fr 1fr 1fr"><select class="select select-sm cp-v" aria-label="Variante">${vopts}</select><input class="input input-sm cp-q" type="number" min="1" step="1" value="1" aria-label="Cantidad"><input class="input input-sm cp-c" type="number" min="0" step="0.01" aria-label="Costo unitario" value="${vars[0].cost}"></div>`;
  const total = () => [...$("fBody").querySelectorAll(".cp-line")].reduce((s, l) => s + (Number(l.querySelector(".cp-q").value) || 0) * cn(l.querySelector(".cp-c").value), 0);
  const upd = () => $("cpTotal").textContent = "Total estimado: " + mxn(total() / 100);
  formModal("Nueva compra", `<div class="field"><label for="cpS">Proveedor</label><select id="cpS" class="select">${opts(act.map(s => [s.id, s.name]))}</select></div>
    <div class="vrow vh" style="grid-template-columns:3fr 1fr 1fr"><small>Variante</small><small>Cantidad</small><small>Costo unitario (MXN)</small></div>${line()}
    <button id="cpAdd" type="button" class="btn btn-sm" style="margin-top:var(--s2)">+ Otra partida</button><p id="cpTotal" class="pos" style="margin:var(--s3) 0 0"></p>
    <p class="hint">La compra queda pendiente: el inventario sube hasta que marques «Recibir».</p>`, async () => {
    const items = [...$("fBody").querySelectorAll(".cp-line")].map(l => ({ variant_id: Number(l.querySelector(".cp-v").value), qty: Number(l.querySelector(".cp-q").value), cost: Number(l.querySelector(".cp-c").value) }));
    const res = await api("/api/purchases", { supplier_id: Number($("cpS").value), items });
    if (!res.ok) return res.d.error || "No se pudo guardar."; toast("Compra registrada como pendiente.", "ok"); loadComp(); return null;
  }, { wide: true });
  upd();
  $("cpAdd").onclick = () => { $("cpAdd").insertAdjacentHTML("beforebegin", line()); upd() };
  $("fBody").oninput = e => { if (e.target.classList.contains("cp-v")) { const l = e.target.closest(".cp-line"); l.querySelector(".cp-c").value = e.target.selectedOptions[0].dataset.cost } upd() };
}
$("cNew").onclick = newPurchase;

$("cList").addEventListener("click", async e => {
  const b = e.target.closest("[data-pa]"); if (!b) return; const id = Number(b.dataset.id), p = cPurch.find(x => x.id === id), a = b.dataset.pa; if (!p) return;
  if (a === "view") return showInfo("Compra #" + id + " · " + (p.supplier || ""),
    `<p>${badge(p.status, PSTATUS[p.status])} <span class="muted">${esc(when(p.created_at))}</span></p>` + table([{ h: "Producto", c: i => `${esc(i.name)}<small>${esc(i.sku)}</small>` }, { h: "Cantidad", cls: "num", c: i => i.qty }, { h: "Costo", cls: "num", c: i => mxn(i.cost) }], p.items) +
    `<h3 style="margin:var(--s4) 0 var(--s2)">Pagos</h3>` + (p.payments.length ? p.payments.map(x => listRow(`${esc(x.method)}<small>${esc(when(x.created_at))}</small>`, mxn(x.amount))).join("") : '<p class="muted">Sin pagos registrados.</p>') +
    listRow("Total", mxn(p.total)) + listRow("Saldo", mxn(p.balance), "total"));
  if (a === "recv") { if (!await askConfirm(`Recibir la compra #${id}: las piezas entrarán al inventario y el costo del producto se recalculará (promedio ponderado). Solo se puede hacer una vez.`, { okText: "Recibir mercancía" })) return;
    const r = await withBusy(b, () => api(`/api/purchases/${id}/receive`, {})); return r.ok ? (toast("Mercancía recibida. Inventario actualizado.", "ok"), loadComp()) : toastErr(r) }
  if (a === "cancel") { if (!await askConfirm(`¿Cancelar la compra #${id}? No mueve inventario y no se puede deshacer.`, { danger: true, okText: "Cancelar compra" })) return;
    const r = await withBusy(b, () => api(`/api/purchases/${id}/cancel`, {})); return r.ok ? (toast("Compra cancelada.", "ok"), loadComp()) : toastErr(r) }
  if (a === "pay") formModal(`Pagar compra #${id}`, `<p>Saldo pendiente: <b>${mxn(p.balance)}</b></p>${field("pgA", "Monto (MXN)", { type: "number", min: 0, step: "0.01", value: p.balance })}<div class="field"><label for="pgM">Método de pago</label><select id="pgM" class="select">${opts(PAY_METHODS)}</select></div>`, async () => {
    const r = await api(`/api/purchases/${id}/payments`, { amount: Number($("pgA").value), method: $("pgM").value }); if (!r.ok) return r.d.error || "No se pudo registrar el pago.";
    toast("Pago registrado.", "ok"); loadComp(); return null }, { okText: "Registrar pago" });
});

/* --- proveedores --- */
function supplierForm(s) {
  formModal(s ? "Editar proveedor" : "Nuevo proveedor", field("spN", "Nombre", { value: s ? s.name : "" }) + field("spT", "Teléfono", { value: s ? s.phone || "" : "" }) + field("spO", "Notas", { value: s ? s.notes || "" : "", ph: "Condiciones, contacto, días de entrega" }), async () => {
    const body = { name: $("spN").value, phone: $("spT").value, notes: $("spO").value };
    const r = s ? await api("/api/suppliers/" + s.id, body, "PATCH") : await api("/api/suppliers", body); if (!r.ok) return r.d.error || "No se pudo guardar.";
    toast(s ? "Proveedor actualizado." : "Proveedor creado.", "ok"); loadComp(); return null });
}
$("sNew").onclick = () => supplierForm(null);
$("sList").addEventListener("click", async e => {
  const b = e.target.closest("[data-sa]"); if (!b) return; const s = cSupp.find(x => x.id === Number(b.dataset.id)); if (!s) return;
  if (b.dataset.sa === "edit") return supplierForm(s);
  const r = await api("/api/suppliers/" + s.id, { active: !s.active }, "PATCH"); r.ok ? (toast(s.active ? "Proveedor desactivado." : "Proveedor activado.", "ok"), loadComp()) : toastErr(r);
});
MB.register("comp", { admin: true, title: "Compras y proveedores", load: loadComp });
