/* Marcela Boutique — módulo POS (Caja Rápida) con soporte multisucursal */
(function(){
  let cart = [];
  let productsCache = [];
  let currentKey = genKey();

  function genKey(){
    return 'pos-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9);
  }

  async function load(){
    const openSec = document.getElementById("openCash");
    const posSec = document.getElementById("pos");
    const recSec = document.getElementById("recent");
    if(!openSec || !posSec) return;

    try {
      const cur = await api.get("/api/cash/current");
      if(!cur.session){
        openSec.hidden = false;
        posSec.hidden = true;
        recSec.hidden = true;
        return;
      }
      openSec.hidden = true;
      posSec.hidden = false;
      recSec.hidden = false;
      await loadCatalog();
      await loadRecent();
    } catch(e) {
      toast(e.message, "danger");
    }
  }

  async function loadCatalog(){
    try {
      const res = await api.get("/api/products");
      productsCache = res.products || [];
      renderCategories();
      renderCatalog(productsCache);
    } catch(e) {
      toast("Error al cargar productos: " + e.message, "danger");
    }
  }

  function renderCategories(){
    const catsEl = document.getElementById("cats");
    if(!catsEl) return;
    const cats = ["Todas", ...new Set(productsCache.map(p => p.category).filter(Boolean))];
    catsEl.innerHTML = cats.map((c, i) => `
      <button type="button" class="seg" data-cat="${c}" aria-pressed="${i===0?'true':'false'}">${c}</button>
    `).join("");
    catsEl.querySelectorAll("button").forEach(b => {
      b.onclick = () => {
        catsEl.querySelectorAll("button").forEach(x => x.setAttribute("aria-pressed", "false"));
        b.setAttribute("aria-pressed", "true");
        const c = b.dataset.cat;
        renderCatalog(c === "Todas" ? productsCache : productsCache.filter(p => p.category === c));
      };
    });
  }

  function renderCatalog(list){
    const prodsEl = document.getElementById("prods");
    if(!prodsEl) return;
    if(!list.length){
      prodsEl.innerHTML = '<div class="empty" style="grid-column:1/-1"><strong>No hay prendas en esta categoría</strong></div>';
      return;
    }

    prodsEl.innerHTML = list.map(p => {
      const vOpts = (p.variants || []).map(v => {
        // Ficha contextual: mostrar stock local y stock en otras sucursales
        const otherStock = Object.values(v.branches || {})
          .filter(b => b.branch_id !== window.currentUser?.branch_id && b.stock > 0)
          .map(b => `${b.branch_code}: ${b.stock}`)
          .join(", ");
        const otherBadge = otherStock ? ` [Otras: ${otherStock}]` : '';
        return `<option value="${v.id}" data-stock="${v.available}">
          ${v.size || '-'} / ${v.color || '-'} (${v.available} disp.)${otherBadge}
        </option>`;
      }).join("");

      return `
        <article class="prod">
          <div class="im">${p.image ? `<img src="${p.image}" alt="">` : 'MB'}</div>
          <div class="in">
            <strong>${p.name}</strong>
            <span class="price">${fmt.money(p.price)}</span>
            ${vOpts ? `<select id="v${p.id}" class="select select-sm">${vOpts}</select>` : '<span class="faint">Agotado</span>'}
            ${vOpts ? `<button type="button" class="btn btn-sm btn-primary" data-add="${p.id}">Agregar</button>` : ''}
          </div>
        </article>
      `;
    }).join("");

    prodsEl.querySelectorAll("[data-add]").forEach(b => {
      b.onclick = () => {
        const pid = parseInt(b.dataset.add);
        const p = productsCache.find(x => x.id === pid);
        const vSel = document.getElementById(`v${pid}`);
        const vid = parseInt(vSel.value);
        const v = p.variants.find(x => x.id === vid);
        addToCart(p, v);
      };
    });
  }

  function addToCart(p, v){
    const existing = cart.find(x => x.vid === v.id);
    const inCart = existing ? existing.qty : 0;
    if(inCart + 1 > v.available){
      toast(`No hay suficiente existencia en esta sucursal (Disponible: ${v.available}).`, "warn");
      return;
    }
    if(existing){
      existing.qty++;
    } else {
      cart.push({
        vid: v.id,
        sku: v.sku,
        name: p.name,
        size: v.size,
        color: v.color,
        price: p.price,
        maxStock: v.available,
        qty: 1
      });
    }
    renderCart();
  }

  function renderCart(){
    const itemsEl = document.getElementById("cartItems");
    const subEl = document.getElementById("sub");
    const totEl = document.getElementById("tot");
    const chargeBtn = document.getElementById("charge");
    if(!itemsEl) return;

    if(!cart.length){
      itemsEl.innerHTML = '<p class="muted" style="text-align:center;padding:var(--s4) 0">El carrito está vacío</p>';
      subEl.textContent = fmt.money(0);
      totEl.textContent = fmt.money(0);
      chargeBtn.disabled = true;
      renderPayRow(0);
      return;
    }

    itemsEl.innerHTML = cart.map((it, idx) => `
      <div class="cart-line">
        <div>
          <strong>${it.name}</strong>
          <small>${it.sku} · ${it.size||'-'} / ${it.color||'-'}</small>
          <small>${fmt.money(it.price)} c/u</small>
        </div>
        <div class="qty">
          <button type="button" class="btn btn-sm" data-dec="${idx}">-</button>
          <span>${it.qty}</span>
          <button type="button" class="btn btn-sm" data-inc="${idx}">+</button>
        </div>
        <div class="num" style="font-weight:600">${fmt.money(it.price * it.qty)}</div>
      </div>
    `).join("");

    itemsEl.querySelectorAll("[data-dec]").forEach(b => {
      b.onclick = () => {
        const i = parseInt(b.dataset.dec);
        cart[i].qty--;
        if(cart[i].qty <= 0) cart.splice(i, 1);
        renderCart();
      };
    });

    itemsEl.querySelectorAll("[data-inc]").forEach(b => {
      b.onclick = () => {
        const i = parseInt(b.dataset.inc);
        if(cart[i].qty + 1 > cart[i].maxStock){
          toast("Existencia máxima alcanzada.", "warn");
          return;
        }
        cart[i].qty++;
        renderCart();
      };
    });

    const sub = cart.reduce((acc, it) => acc + (it.price * it.qty), 0);
    const disc = parseFloat(document.getElementById("disc")?.value || 0) || 0;
    const tot = Math.max(0, sub - disc);

    subEl.textContent = fmt.money(sub);
    totEl.textContent = fmt.money(tot);
    chargeBtn.disabled = tot <= 0;
    renderPayRow(tot);
  }

  function renderPayRow(total){
    const paysEl = document.getElementById("pays");
    if(!paysEl) return;
    paysEl.innerHTML = `
      <div class="pay-row">
        <select id="pMth" class="select"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta</option><option value="transferencia">Transferencia</option></select>
        <input id="pAmt" type="number" class="input" value="${total.toFixed(2)}" readonly>
        <div class="rc" id="rcWrap"><label>Efectivo recibido<input id="pRec" type="number" step="0.01" class="input" value="${total.toFixed(2)}"></label></div>
      </div>
    `;

    const mth = document.getElementById("pMth");
    const recWrap = document.getElementById("rcWrap");
    const recInp = document.getElementById("pRec");
    const payInfo = document.getElementById("payInfo");

    function calcChange(){
      if(mth.value !== "efectivo"){
        recWrap.hidden = true;
        payInfo.textContent = "";
        return;
      }
      recWrap.hidden = false;
      const rec = parseFloat(recInp.value) || 0;
      const diff = rec - total;
      if(diff < 0){
        payInfo.className = "pay-info bad";
        payInfo.textContent = `Faltan ${fmt.money(Math.abs(diff))}`;
      } else {
        payInfo.className = "pay-info good";
        payInfo.textContent = `Cambio: ${fmt.money(diff)}`;
      }
    }

    mth.onchange = calcChange;
    recInp.oninput = calcChange;
    calcChange();
  }

  async function executeSale(){
    const chargeBtn = document.getElementById("charge");
    chargeBtn.classList.add("is-loading");
    try {
      const sub = cart.reduce((acc, it) => acc + (it.price * it.qty), 0);
      const disc = parseFloat(document.getElementById("disc")?.value || 0) || 0;
      const tot = sub - disc;
      const mth = document.getElementById("pMth").value;
      const rec = mth === "efectivo" ? (parseFloat(document.getElementById("pRec").value) || tot) : null;

      const payload = {
        idempotency_key: currentKey,
        discount: disc,
        items: cart.map(i => ({ variant_id: i.vid, qty: i.qty })),
        payments: [{ method: mth, amount: tot, received: rec }]
      };

      const res = await api.post("/api/sales", payload);
      document.getElementById("doneInfo").innerHTML = `
        Folio: <strong>${res.folio}</strong><br>
        Total: <strong>${fmt.money(res.total)}</strong><br>
        ${res.change > 0 ? `Cambio: <strong>${fmt.money(res.change)}</strong>` : ''}
      `;
      const doneModal = document.getElementById("doneModal");
      if(doneModal) doneModal.hidden = false;
      const printBtn = document.getElementById("doneP");
      if(printBtn) printBtn.onclick = () => window.open(`/api/sales/${res.id}/receipt.html`, "_blank");

      cart = [];
      currentKey = genKey();
      document.getElementById("disc").value = "0";
      renderCart();
      await loadCatalog();
      await loadRecent();
    } catch(e) {
      toast(e.message, "danger");
    } finally {
      chargeBtn.classList.remove("is-loading");
    }
  }

  async function loadRecent(){
    const salesEl = document.getElementById("sales");
    if(!salesEl) return;
    try {
      const res = await api.get("/api/sales");
      const list = res.sales || [];
      if(!list.length){
        salesEl.innerHTML = '<p class="muted">No hay ventas recientes hoy.</p>';
        return;
      }
      salesEl.innerHTML = table(
        ["Folio", "Total", "Estado", "Hora", "Acciones"],
        list.slice(0, 10).map(s => [
          `<strong>${s.folio}</strong>`,
          fmt.money(s.total_cents / 100),
          badge(s.status, s.status === 'completada' ? 'ok' : 'danger'),
          `<small>${s.created_at}</small>`,
          `<div class="btn-row">
            <a class="btn btn-sm" href="/api/sales/${s.id}/receipt.html" target="_blank">Ticket</a>
            ${s.status === 'completada' ? `
              <button type="button" class="btn btn-sm btn-danger" data-ref="${s.id}">Devolver</button>
            ` : ''}
          </div>`
        ])
      );

      salesEl.querySelectorAll("[data-ref]").forEach(b => {
        b.onclick = () => openRefundModal(parseInt(b.dataset.ref));
      });
    } catch(e){}
  }

  async function openRefundModal(sid){
    try {
      const s = await api.get(`/api/sales/${sid}`);
      const items = s.items || [];
      const rows = items.map(it => `
        <div class="list-row">
          <div><strong>${it.name}</strong> (${it.size||'-'}/${it.color||'-'})<small>${fmt.money(it.price_cents/100)}</small></div>
          <div style="width:80px"><input type="number" class="input input-sm ref-q" data-si="${it.id}" min="0" max="${it.qty}" value="0"></div>
        </div>
      `).join("");

      formModal(`Devolución de venta ${s.folio}`, `
        <p class="muted">Indica cuántas prendas devuelve el cliente:</p>
        ${rows}
        <div class="field" style="margin-top:var(--s3)"><label>Motivo</label><textarea id="rfWhy" class="textarea" placeholder="Escribe el motivo (mín. 5 caracteres)"></textarea></div>
        <div class="field"><label>Método de reembolso</label><select id="rfMth" class="select"><option value="efectivo">Efectivo de caja</option><option value="saldo_favor">Saldo a favor</option></select></div>
        <div class="field"><label>Contraseña de autorización (administradora)</label><input id="rfPass" type="password" class="input"></div>
      `, async () => {
        const toReturn = Array.from(document.querySelectorAll(".ref-q"))
          .map(inp => ({ sale_item_id: parseInt(inp.dataset.si), qty: parseInt(inp.value)||0 }))
          .filter(x => x.qty > 0);
        if(!toReturn.length) throw new Error("Selecciona al menos una prenda para devolver.");
        const reason = document.getElementById("rfWhy").value.trim();
        const method = document.getElementById("rfMth").value;
        const pass = document.getElementById("rfPass").value;
        if(reason.length < 5) throw new Error("Motivo requerido.");

        await api.post(`/api/sales/${sid}/refund`, {
          items: toReturn,
          reason,
          method,
          authorizer: { username: "marcela", password: pass }
        });
        toast("Devolución procesada y prendas reingresadas al inventario.", "ok");
        loadRecent();
        loadCatalog();
      });
    } catch(e) {
      toast("Error al cargar venta: " + e.message, "danger");
    }
  }

  function setup(){
    const openBtn = document.getElementById("openBtn");
    if(openBtn){
      openBtn.onclick = async () => {
        const fVal = parseFloat(document.getElementById("fondo")?.value || 0) || 0;
        await api.post("/api/cash/open", { opening: fVal });
        toast("Caja abierta.", "ok");
        load();
      };
    }

    const chargeBtn = document.getElementById("charge");
    if(chargeBtn) chargeBtn.onclick = executeSale;

    const clearBtn = document.getElementById("clear");
    if(clearBtn){
      clearBtn.onclick = () => {
        cart = [];
        renderCart();
      };
    }

    const discInp = document.getElementById("disc");
    if(discInp) discInp.oninput = renderCart;

    // Lector de código de barras en campo de búsqueda
    const qInp = document.getElementById("q");
    if(qInp){
      qInp.onkeydown = (e) => {
        if(e.key === "Enter"){
          e.preventDefault();
          const code = qInp.value.trim().toUpperCase();
          if(!code) return;
          // Buscar coincidencia exacta por SKU o código de barras
          for(const p of productsCache){
            const v = (p.variants || []).find(x => (x.sku && x.sku.toUpperCase() === code) || (x.barcode && x.barcode === code));
            if(v){
              addToCart(p, v);
              qInp.value = "";
              toast(`Agregado: ${p.name} (${v.sku})`, "ok");
              return;
            }
          }
          toast("Prenda no encontrada con ese código.", "warn");
        }
      };
    }

    const doneC = document.getElementById("doneC");
    if(doneC){
      doneC.onclick = () => {
        document.getElementById("doneModal").hidden = true;
      };
    }
  }

  views.register("pos", load);
  document.addEventListener("DOMContentLoaded", setup);
})();
