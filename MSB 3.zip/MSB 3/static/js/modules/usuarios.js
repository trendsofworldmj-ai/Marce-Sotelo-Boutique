"use strict";
/* Usuarios (administradora): alta, edición (rol, sucursal, contraseña temporal) y activación. */
let usrCache = [], brCache = [];
async function loadUsr() {
  $("uList").innerHTML = loadingHtml();
  const [r, b] = await Promise.all([api("/api/users"), api("/api/branches")]);
  if (!r.ok) { $("uList").innerHTML = ""; return toastErr(r) }
  usrCache = r.d.users; brCache = b.ok ? (b.d.branches || []).filter(x => x.active !== 0 && x.active !== false) : [];
  $("uList").innerHTML = table([
    { h: "Nombre", c: u => esc(u.full_name) + (u.id === MB.user.id ? " " + badge("tú", "gold") : "") },
    { h: "Usuario", c: u => esc(u.username) },
    { h: "Rol", c: u => badge(u.role === "admin" ? "Administradora" : "Cajera", u.role === "admin" ? "gold" : "info") },
    { h: "Sucursal", c: u => esc(u.branch_name || "Todas (central)") },
    { h: "Estado", c: u => badge(u.active ? "activo" : "inactivo", u.active ? "ok" : "") },
    { h: "", cls: "actions", c: u => `<button class="btn btn-sm" data-edit="${u.id}">Editar</button> ` +
        (u.id === MB.user.id ? "" : `<button class="btn btn-sm ${u.active ? "btn-danger" : ""}" data-u="${u.id}" data-act="${u.active ? 0 : 1}">${u.active ? "Desactivar" : "Activar"}</button>`) }
  ], usrCache, { empty: "Sin usuarios" });
}
const branchOpts = sel => opts([["", "Todas (administración central)"], ...brCache.map(b => [b.id, b.name])], sel);
$("uList").addEventListener("click", async e => {
  const ed = e.target.closest("[data-edit]");
  if (ed) {
    const u = usrCache.find(x => x.id === Number(ed.dataset.edit)); if (!u) return;
    return formModal(`Editar a ${u.full_name}`, `<div class="form-grid">${field("ueN", "Nombre completo", { value: u.full_name })}
      <div class="field"><label for="ueR">Rol</label><select id="ueR" class="select">${opts([["cajero", "Cajera"], ["admin", "Administradora"]], u.role)}</select></div>
      <div class="field"><label for="ueB">Sucursal</label><select id="ueB" class="select">${branchOpts(u.branch_id ?? "")}</select></div>
      ${field("ueP", "Nueva contraseña temporal (opcional)", { type: "password", hint: "Déjalo vacío para no cambiarla. Si la escribes, se le pedirá cambiarla al entrar." })}</div>`, async () => {
      const body = { full_name: $("ueN").value, role: $("ueR").value, branch_id: $("ueB").value === "" ? null : Number($("ueB").value) };
      if ($("ueP").value) body.reset_password = $("ueP").value;
      const r = await api(`/api/users/${u.id}`, body, "PATCH"); if (!r.ok) return r.d.error || "No se pudo guardar.";
      toast("Usuario actualizado.", "ok"); loadUsr(); return null }, { okText: "Guardar cambios" });
  }
  const b = e.target.closest("[data-u]"); if (!b) return; const on = b.dataset.act === "1";
  if (!on && !await askConfirm("Esta persona ya no podrá entrar al sistema. Su historial se conserva.", { danger: true, okText: "Desactivar" })) return;
  const r = await withBusy(b, () => api(`/api/users/${b.dataset.u}/active`, { active: on })); r.ok ? (toast(on ? "Usuario activado." : "Usuario desactivado.", "ok"), loadUsr()) : toastErr(r);
});
$("uNew").onclick = () => formModal("Nuevo usuario", `<div class="form-grid">${field("unN", "Nombre completo")}${field("unU", "Usuario", { ph: "ej. caja2", hint: "3 a 30 caracteres: letras, números . _ -" })}</div>
  <div class="field"><label for="unR">Rol</label><select id="unR" class="select">${opts([["cajero", "Cajera: Caja, Apartados y Traspasos"], ["admin", "Administradora: acceso completo"]])}</select></div>
  <div class="field"><label for="unB">Sucursal</label><select id="unB" class="select">${branchOpts("")}</select></div>
  ${field("unP", "Contraseña temporal", { type: "password", hint: "Mínimo 8 caracteres. Se le pedirá cambiarla en su primer acceso." })}`, async () => {
  const bid = $("unB").value;
  const r = await api("/api/users", { full_name: $("unN").value, username: $("unU").value, role: $("unR").value, password: $("unP").value, branch_id: bid === "" ? null : Number(bid) }); if (!r.ok) return r.d.error || "No se pudo crear.";
  toast("Usuario creado.", "ok"); loadUsr(); return null }, { okText: "Crear usuario" });
MB.register("usr", { admin: true, title: "Usuarios", load: loadUsr });
