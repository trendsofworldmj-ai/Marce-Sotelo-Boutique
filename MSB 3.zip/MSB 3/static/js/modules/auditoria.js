"use strict";
/* Auditoría (administradora): solo lectura del registro de eventos. */
const AUD = { login: "Inicio de sesión", login_fallido: "Acceso fallido", cambio_password: "Cambio de contraseña", acceso_denegado: "Acceso denegado", autorizacion_fallida: "Autorización fallida",
  venta: "Venta", venta_cancelada: "Venta cancelada", caja_abierta: "Caja abierta", caja_cerrada: "Caja cerrada", ajuste_inventario: "Ajuste de inventario", importacion_csv: "Importación CSV",
  producto_creado: "Producto creado", producto_editado: "Producto editado", variante_creada: "Variante creada", variante_editada: "Variante editada", compra_creada: "Compra creada", compra_recibida: "Compra recibida",
  compra_cancelada: "Compra cancelada", pago_proveedor: "Pago a proveedor", proveedor_creado: "Proveedor creado", proveedor_editado: "Proveedor editado", gasto_registrado: "Gasto registrado",
  usuario_creado: "Usuario creado", usuario_activo: "Usuario activado", usuario_desactivado: "Usuario desactivado", backup_creado: "Respaldo creado", backup_descargado: "Respaldo descargado", seed_admin: "Alta inicial" };
const audTone = a => /fallid|denegad|cancelad|desactiv/.test(a) ? "danger" : /login$|^venta$|creado|registrado|recibida/.test(a) ? "ok" : "";
async function loadAud() {
  $("auList").innerHTML = loadingHtml();
  const r = await api("/api/audit" + qs({ action: $("auAct").value, user: $("auUser").value.trim(), limit: $("auLim").value }));
  if (!r.ok) { $("auList").innerHTML = ""; return toastErr(r) }
  const sel = $("auAct"), cur = sel.value, known = new Set([...Object.keys(AUD), ...r.d.events.map(e => e.action)]);
  sel.innerHTML = '<option value="">Todas</option>' + [...known].sort((a, b) => (AUD[a] || a).localeCompare(AUD[b] || b, "es")).map(a => `<option value="${esc(a)}">${esc(AUD[a] || a)}</option>`).join(""); sel.value = cur;
  paged($("auList"), r.d.events, rows => table([
    { h: "Fecha", c: e => esc(when(e.created_at)) }, { h: "Usuario", c: e => esc(e.username || "—") }, { h: "Acción", c: e => badge(AUD[e.action] || e.action, audTone(e.action)) }, { h: "Detalle", c: e => esc(e.detail || "") }],
    rows, { empty: "Sin eventos con este filtro", hint: "Quita el filtro de acción o usuario para ver más." }), 25);
}
$("auApply").onclick = loadAud;
$("auUser").onkeydown = e => { if (e.key === "Enter") loadAud() };
MB.register("aud", { admin: true, title: "Auditoría", load: loadAud });
