"use strict";
/* Marcela Boutique — núcleo compartido: utilidades, API, avisos, diálogos, tablas y registro de vistas.
   Todos los módulos de static/js/modules/ se apoyan en esto; no deben duplicar estas funciones. */
const MB = window.MB = { user: null, session: null, views: {}, view: null };
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const mxn = n => Number(n || 0).toLocaleString("es-MX", { style: "currency", currency: "MXN" });
const cn = x => Math.round((Number(x) || 0) * 100);               // MXN → centavos (misma regla que antes)
const newKey = () => crypto.randomUUID ? crypto.randomUUID() : "k" + Date.now() + Math.random().toString(16).slice(2);
const when = s => s ? s.slice(8, 10) + "/" + s.slice(5, 7) + " " + s.slice(11, 16) : "";
const signed = n => (n > 0 ? "+" : "") + mxn(n);
const isAdmin = () => !!MB.user && MB.user.role === "admin";
const pad = n => String(n).padStart(2, "0");
const isoDay = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const todayISO = () => isoDay(new Date());
const monthStartISO = () => { const d = new Date(); d.setDate(1); return isoDay(d) };

/* ---------- API ---------- */
async function api(url, body, method) {
  const o = { method: method || (body !== undefined ? "POST" : "GET"), headers: {} };
  if (body !== undefined) { o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body) }
  try {
    const r = await fetch(url, o); let d = {};
    try { d = await r.json() } catch { }
    if (r.status === 401 && MB.user && url !== "/api/login") { MB.user = null; MB.onExpired && MB.onExpired() }
    return { ok: r.ok, status: r.status, d };
  } catch { return { ok: false, status: 0, d: { error: "Sin conexión con el sistema. Reintenta: la operación no se duplicará." } } }
}
const qs = o => { const p = new URLSearchParams(); for (const k in o) if (o[k] !== "" && o[k] != null) p.set(k, o[k]); const s = p.toString(); return s ? "?" + s : "" };

/* ---------- Avisos ---------- */
let toastTimer;
function toast(msg, kind) {
  const t = $("toast"); t.textContent = msg; t.className = "toast" + (kind ? " is-" + kind : ""); t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.hidden = true, 4200);
}
const toastErr = r => toast((r && r.d && r.d.error) || "No se pudo completar la acción.", "error");

/* ---------- Bloques de HTML reutilizables (devuelven texto: los datos del usuario se escapan con esc()) ---------- */
const badge = (text, tone) => `<span class="badge${tone ? " badge-" + tone : ""}">${esc(text)}</span>`;
const loadingHtml = (t = "Cargando…") => `<div class="loading" role="status">${esc(t)}</div>`;
const emptyHtml = (title, hint = "") => `<div class="empty"><strong>${esc(title)}</strong>${hint ? esc(hint) : ""}</div>`;
let kpi = (label, value, o = {}) => `<div class="kpi${o.tone ? " is-" + o.tone : ""}"><div class="kpi-label">${esc(label)}</div><div class="kpi-value">${value}</div>${o.note ? `<div class="kpi-note">${esc(o.note)}</div>` : ""}</div>`;
const listRow = (left, right, cls = "") => `<div class="list-row ${cls}"><span>${left}</span><span class="num">${right}</span></div>`;
/* Tabla estándar. cols: [{h:"Título", c:fila=>"html", cls:"num"}]. Las celdas c() deben escapar con esc(). */
function table(cols, rows, o = {}) {
  if (!rows.length) return emptyHtml(o.empty || "Sin registros", o.hint || "");
  return `<div class="table-wrap"><table class="tbl"><thead><tr>${cols.map(c => `<th class="${c.cls || ""}">${esc(c.h)}</th>`).join("")}</tr></thead><tbody>${
    rows.map(r => `<tr>${cols.map(c => `<td class="${c.cls || ""}">${c.c(r)}</td>`).join("")}</tr>`).join("")}</tbody>${o.foot ? `<tfoot>${o.foot}</tfoot>` : ""}</table></div>`;
}
/* Paginación en cliente: pinta renderPage(trozo) dentro de host y añade controles Anterior/Siguiente. */
function paged(host, items, renderPage, size = 20) {
  const st = host._pg = { page: 0, pages: Math.max(1, Math.ceil(items.length / size)) };
  st.draw = () => {
    host.dataset.paged = "1";
    const from = st.page * size;
    host.innerHTML = renderPage(items.slice(from, from + size)) + (st.pages > 1 ?
      `<div class="pager"><span>${from + 1}–${Math.min(items.length, from + size)} de ${items.length}</span><span class="btn-row">
       <button class="btn btn-sm" data-pg="-1" ${st.page === 0 ? "disabled" : ""}>Anterior</button><button class="btn btn-sm" data-pg="1" ${st.page >= st.pages - 1 ? "disabled" : ""}>Siguiente</button></span></div>` : "");
  };
  st.draw();
}
document.addEventListener("click", e => {
  const b = e.target.closest("[data-pg]"); if (!b) return;
  const h = b.closest("[data-paged]"), st = h && h._pg; if (!st) return;
  st.page = Math.min(Math.max(0, st.page + Number(b.dataset.pg)), st.pages - 1); st.draw();
});
/* Botón con estado de carga: evita dobles clics mientras el servidor responde. */
async function withBusy(btn, fn) {
  btn.disabled = true; btn.classList.add("is-loading");
  try { return await fn() } finally { btn.disabled = false; btn.classList.remove("is-loading") }
}
/* Campo de formulario como texto (para diálogos generados por JS). */
const field = (id, label, o = {}) => `<div class="field"><label for="${id}">${esc(label)}</label>${
  o.select ? `<select class="select" id="${id}">${o.select}</select>` :
  o.area ? `<textarea class="textarea" id="${id}" rows="2" placeholder="${esc(o.ph || "")}"></textarea>` :
  `<input class="input" id="${id}" type="${o.type || "text"}" ${o.min != null ? `min="${o.min}"` : ""} ${o.step ? `step="${o.step}"` : ""} placeholder="${esc(o.ph || "")}" value="${esc(o.value ?? "")}" autocomplete="off">`}${o.hint ? `<span class="hint">${esc(o.hint)}</span>` : ""}</div>`;
const opts = (list, sel) => list.map(([v, t]) => `<option value="${esc(v)}" ${String(v) === String(sel) ? "selected" : ""}>${esc(t)}</option>`).join("");

/* ---------- Diálogos ---------- */
let lastFocus = null;
function showModal(id) { lastFocus = document.activeElement; const m = $(id); m.hidden = false; const f = m.querySelector("input:not([type=hidden]):not([hidden]),select,textarea,.btn-primary"); if (f) f.focus() }
function hideModal(id) { $(id).hidden = true; if (lastFocus && lastFocus.focus && document.contains(lastFocus)) lastFocus.focus() }
document.addEventListener("keydown", e => {
  const open = [...document.querySelectorAll(".modal")].filter(m => !m.hidden).pop(); if (!open) return;
  if (e.key === "Escape") { const c = open.querySelector("[data-cancel]"); if (c) c.click() }
  if (e.key === "Tab") {   // el foco no sale del diálogo abierto
    const f = [...open.querySelectorAll("button,input,select,textarea,a[href]")].filter(x => !x.disabled && !x.hidden && x.offsetParent !== null);
    if (!f.length) return; const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus() } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus() }
  }
});
/* Diálogo de formulario: save() devuelve un texto de error (se muestra sin cerrar) o null para cerrar. */
function formModal(title, html, save, o = {}) {
  return new Promise(res => {
    $("fTitle").textContent = title; $("fBody").oninput = null; $("fBody").innerHTML = html; $("fErr").textContent = ""; $("fOk").textContent = o.okText || "Guardar";
    $("fDialog").classList.toggle("wide", !!o.wide); showModal("formModal");
    const close = v => { hideModal("formModal"); $("fOk").onclick = $("fNo").onclick = null; res(v) };
    $("fNo").onclick = () => close(false);
    $("fOk").onclick = async () => { $("fErr").textContent = ""; const e = await withBusy($("fOk"), save); if (e) $("fErr").textContent = e; else close(true) };
  });
}
function askConfirm(text, o = {}) {
  return new Promise(res => {
    $("cText").textContent = text; $("cOk").textContent = o.okText || "Sí, continuar"; $("cOk").className = "btn " + (o.danger ? "btn-danger" : "btn-primary");
    showModal("confModal"); $("cOk").focus();
    const close = v => { hideModal("confModal"); $("cOk").onclick = $("cNo").onclick = null; res(v) };
    $("cOk").onclick = () => close(true); $("cNo").onclick = () => close(false);
  });
}
function showInfo(title, html) { $("infoTitle").textContent = title; $("infoBody").innerHTML = html; showModal("infoModal") }
$("infoOk").onclick = () => hideModal("infoModal");

/* ---------- Vistas y navegación por rol ---------- */
/* MB.register("clave", { admin:bool, load:fn }) — el elemento de la vista es #v_clave (en templates/partials/views). */
MB.register = (key, def) => { MB.views[key] = Object.assign({ el: $("v" + key[0].toUpperCase() + key.slice(1)), admin: false }, def) };
MB.go = key => {
  const v = MB.views[key]; if (!v || (v.admin && !isAdmin())) return;     // la barrera real está en el servidor; aquí solo se oculta
  MB.view = key;
  for (const k in MB.views) MB.views[k].el.hidden = k !== key;
  document.querySelectorAll("#nav .nav-item").forEach(b => b.classList.toggle("act", b.dataset.v === key));
  $("side").classList.remove("open"); $("menuBtn").setAttribute("aria-expanded", "false");
  document.title = (v.title || "Sistema") + " · Marcela Boutique";
  if (v.load) v.load();
};
MB.applyRole = () => {
  document.querySelectorAll("#nav [data-admin]").forEach(b => b.hidden = !isAdmin());
  document.querySelectorAll("#nav .nav-group").forEach(g => { g.hidden = !g.nextElementSibling || ![...g.parentElement.querySelectorAll(`.nav-item[data-g="${g.dataset.g}"]`)].some(b => !b.hidden) });
};

/* ---------- Compatibilidad con los módulos multisucursal (POS, Apartados, Traspasos, Sucursales) ----------
   Esos módulos usan api.get/post (lanzan Error), views.register, fmt.money, table(encabezados, filas),
   kpi(etiqueta, valor, nota, clase), formModal con guardado que lanza Error, infoModal y toast("danger"|"warn"). */
const apiOk = r => { if (!r.ok) throw new Error((r.d && r.d.error) || "No se pudo completar la acción."); return r.d };
api.get = async url => apiOk(await api(url));
api.post = async (url, body) => apiOk(await api(url, body === undefined ? {} : body, "POST"));
api.patch = async (url, body) => apiOk(await api(url, body === undefined ? {} : body, "PATCH"));
const fmt = { money: n => mxn(n) };
const VIEW_TITLES = { pos: "Caja rápida", apart: "Apartados", transf: "Traspasos", suc: "Sucursales" };
const views = {
  register(key, load, flags = []) { MB.register(key, { admin: flags.includes("admin"), title: VIEW_TITLES[key] || key, load }) },
  show(key) { MB.go(key) }
};
const _table = table, _kpi = kpi, _toast = toast, _formModal = formModal;
table = function (cols, rows, o = {}) {
  if (cols.length && typeof cols[0] === "string") {
    if (!rows.length) return emptyHtml(o.empty || "Sin registros", o.hint || "");
    return `<div class="table-wrap"><table class="tbl"><thead><tr>${cols.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${
      rows.map(r => `<tr>${r.map(c => `<td>${c ?? ""}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  }
  return _table(cols, rows, o);
};
kpi = function (label, value, a, b) {
  if (typeof a === "string") return _kpi(label, value, { note: a, tone: String(b || "").replace(/^is-/, "") || undefined });
  return _kpi(label, value, a || {});
};
toast = function (msg, kind) { _toast(msg, kind === "danger" ? "error" : kind) };
formModal = function (title, html, save, o = {}) {
  return _formModal(title, html, async () => { try { return await save() || null } catch (e) { return e.message || "No se pudo completar la acción." } }, o);
};
function infoModal(title, html) { showInfo(title, html) }
