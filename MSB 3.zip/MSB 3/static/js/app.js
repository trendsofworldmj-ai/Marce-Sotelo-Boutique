"use strict";
/* Marcela Boutique — arranque: sesión, inicio de sesión (con cambio de contraseña obligatorio), menú y navegación. */
function showLoginScreen(msg) {
  $("login").hidden = false; $("top").hidden = true; $("shell").hidden = true;
  $("lm").textContent = msg || ""; $("lp").value = "";
}
async function enterApp(user) {
  MB.user = user;
  $("login").hidden = true; $("top").hidden = false; $("shell").hidden = false;
  $("userChip").textContent = `${user.full_name} (${user.role === "admin" ? "Administradora" : "Cajera"})`;
  const bc = $("branchChip");
  bc.textContent = user.branch_name ? `Sucursal: ${user.branch_name}` : "Administración central";
  bc.classList.toggle("on", !!user.branch_name);
  MB.applyRole();
  await loadSession();                    // estado de la caja (chip superior); definido en modules/caja.js
  MB.go("pos");
}
MB.onExpired = () => showLoginScreen("Tu sesión terminó. Vuelve a entrar.");

async function doLogin() {
  const err = $("lm"); err.textContent = "";
  const u = $("lu").value.trim(), p = $("lp").value, n = $("ln").value;
  if (!u || !p) { err.textContent = "Escribe usuario y contraseña."; return }
  const r = await withBusy($("lb"), () => api("/api/login", { username: u, password: p }));
  if (!r.ok) { err.textContent = r.d.error || "No se pudo iniciar sesión."; return }
  if (r.d.must_change) {
    $("lnW").hidden = false;
    if (n.length < 8) { err.textContent = "Es tu primer acceso: define una nueva contraseña de al menos 8 caracteres."; $("ln").focus(); return }
    const c = await api("/api/password", { current: p, new: n });
    if (!c.ok) { err.textContent = c.d.error || "No se pudo cambiar la contraseña."; return }
  }
  $("lp").value = ""; $("ln").value = ""; $("lnW").hidden = true;
  const me = await api("/api/me");
  if (me.ok) enterApp(me.d.user); else err.textContent = "No se pudo abrir la sesión.";
}

document.addEventListener("DOMContentLoaded", async () => {
  $("lb").onclick = doLogin;
  ["lu", "lp", "ln"].forEach(id => $(id).addEventListener("keydown", e => { if (e.key === "Enter") doLogin() }));
  $("nav").addEventListener("click", e => { const b = e.target.closest(".nav-item"); if (b) MB.go(b.dataset.v) });
  $("menuBtn").onclick = () => { const o = $("side").classList.toggle("open"); $("menuBtn").setAttribute("aria-expanded", String(o)) };
  $("logout").onclick = async () => { await api("/api/logout", {}); MB.user = null; showLoginScreen("") };
  const me = await api("/api/me");
  if (me.ok && !me.d.must_change) enterApp(me.d.user); else showLoginScreen("");
});
