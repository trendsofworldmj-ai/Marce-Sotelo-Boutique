import os, sqlite3
from flask import current_app, g

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DB_PATH"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

def close_db(e=None):
    d = g.pop("db", None)
    if d is not None:
        d.close()

_BRANCH_ID_COLUMNS = ("users", "cash_sessions", "sales", "purchases", "expenses", "inventory_movements")

def get_default_branch_id(con):
    r = con.execute("SELECT id FROM branches WHERE code='SJO'").fetchone()
    if r:
        return r["id"] if hasattr(r, "keys") else r[0]
    r_any = con.execute("SELECT id FROM branches WHERE kind='operativa' ORDER BY id ASC LIMIT 1").fetchone()
    if r_any:
        return r_any["id"] if hasattr(r_any, "keys") else r_any[0]
    cur = con.execute("INSERT INTO branches (code, name, kind, active) VALUES ('SJO', 'San José', 'operativa', 1)")
    return cur.lastrowid

def _migrate(con):
    existing_tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    
    # 1. Columnas branch_id
    for table in _BRANCH_ID_COLUMNS:
        if table not in existing_tables:
            continue
        cols = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
        if "branch_id" not in cols:
            con.execute(f"ALTER TABLE {table} ADD COLUMN branch_id INTEGER REFERENCES branches(id)")
    
    # 2. Sucursal San José y sincronización variant_stock
    if "branches" in existing_tables:
        sjo_id = get_default_branch_id(con)
        if "variant_stock" in existing_tables and "variants" in existing_tables:
            con.execute("""
                INSERT INTO variant_stock (variant_id, branch_id, stock, min_stock, reserved)
                SELECT v.id, ?, v.stock, v.min_stock, 0
                FROM variants v
                WHERE NOT EXISTS (
                    SELECT 1 FROM variant_stock vs WHERE vs.variant_id = v.id AND vs.branch_id = ?
                )
            """, (sjo_id, sjo_id))

    # 3. Tablas de Traspasos (si no existían)
    con.execute("""
    CREATE TABLE IF NOT EXISTS transfers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folio TEXT NOT NULL UNIQUE,
        origin_branch_id INTEGER NOT NULL REFERENCES branches(id),
        dest_branch_id INTEGER NOT NULL REFERENCES branches(id),
        status TEXT NOT NULL DEFAULT 'solicitado' CHECK(status IN ('solicitado','autorizado','en_transito','recibido','rechazado','cancelado')),
        requested_by INTEGER NOT NULL REFERENCES users(id),
        authorized_by INTEGER REFERENCES users(id),
        shipped_by INTEGER REFERENCES users(id),
        received_by INTEGER REFERENCES users(id),
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        CHECK (origin_branch_id != dest_branch_id)
    )""")

    con.execute("""
    CREATE TABLE IF NOT EXISTS transfer_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transfer_id INTEGER NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
        variant_id INTEGER NOT NULL REFERENCES variants(id),
        qty_requested INTEGER NOT NULL CHECK(qty_requested > 0),
        qty_shipped INTEGER NOT NULL DEFAULT 0 CHECK(qty_shipped >= 0),
        qty_received INTEGER NOT NULL DEFAULT 0 CHECK(qty_received >= 0)
    )""")

    con.execute("""
    CREATE TABLE IF NOT EXISTS transfer_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transfer_id INTEGER NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id),
        action TEXT NOT NULL,
        detail TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )""")

    # 4. Tablas de Apartados (Layaways)
    con.execute("""
    CREATE TABLE IF NOT EXISTS layaways (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folio TEXT NOT NULL UNIQUE,
        branch_id INTEGER NOT NULL REFERENCES branches(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        customer_name TEXT NOT NULL,
        customer_phone TEXT,
        total_cents INTEGER NOT NULL CHECK(total_cents > 0),
        paid_cents INTEGER NOT NULL DEFAULT 0 CHECK(paid_cents >= 0),
        status TEXT NOT NULL DEFAULT 'vigente' CHECK(status IN ('vigente','liquidado','cancelado')),
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        notes TEXT
    )""")

    con.execute("""
    CREATE TABLE IF NOT EXISTS layaway_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        layaway_id INTEGER NOT NULL REFERENCES layaways(id) ON DELETE CASCADE,
        variant_id INTEGER NOT NULL REFERENCES variants(id),
        qty INTEGER NOT NULL CHECK(qty > 0),
        price_cents INTEGER NOT NULL CHECK(price_cents > 0)
    )""")

    con.execute("""
    CREATE TABLE IF NOT EXISTS layaway_payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        layaway_id INTEGER NOT NULL REFERENCES layaways(id) ON DELETE CASCADE,
        session_id INTEGER NOT NULL REFERENCES cash_sessions(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
        method TEXT NOT NULL CHECK(method IN ('efectivo','tarjeta','transferencia','otro')),
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )""")

    # 5. Tablas de Devoluciones Parciales
    con.execute("""
    CREATE TABLE IF NOT EXISTS sale_refunds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folio TEXT NOT NULL UNIQUE,
        sale_id INTEGER NOT NULL REFERENCES sales(id),
        session_id INTEGER REFERENCES cash_sessions(id),
        branch_id INTEGER NOT NULL REFERENCES branches(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        authorized_by INTEGER NOT NULL REFERENCES users(id),
        refund_amount_cents INTEGER NOT NULL CHECK(refund_amount_cents > 0),
        method TEXT NOT NULL CHECK(method IN ('efectivo','tarjeta','transferencia','saldo_favor','otro')),
        reason TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )""")

    con.execute("""
    CREATE TABLE IF NOT EXISTS sale_refund_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        refund_id INTEGER NOT NULL REFERENCES sale_refunds(id) ON DELETE CASCADE,
        sale_item_id INTEGER NOT NULL REFERENCES sale_items(id),
        variant_id INTEGER NOT NULL REFERENCES variants(id),
        qty INTEGER NOT NULL CHECK(qty > 0),
        refund_cents INTEGER NOT NULL CHECK(refund_cents >= 0)
    )""")

def init_app(app):
    app.teardown_appcontext(close_db)
    with app.app_context():
        con = get_db()
        con.execute("PRAGMA journal_mode=WAL")
        with open(os.path.join(os.path.dirname(__file__), "schema.sql"), encoding="utf-8") as f:
            con.executescript(f.read())
        with con:
            _migrate(con)