import re
from flask import Blueprint, g, jsonify, request
import db
from auth import audit, role_required
from inventory import cents, move_stock, to_int
from sales import err

bp = Blueprint("purchases", __name__)
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
P = lambda c: c / 100

# ---------- Proveedores ----------
@bp.get("/api/suppliers")
@role_required("admin")
def suppliers():
    return jsonify(suppliers=[dict(r) for r in db.get_db().execute("SELECT * FROM suppliers ORDER BY name")])

@bp.post("/api/suppliers")
@role_required("admin")
def add_supplier():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    name = str(d.get("name") or "").strip()
    if not name: return err("El nombre del proveedor es obligatorio.", 400)
    with con:
        sid = con.execute("INSERT INTO suppliers(name,phone,notes) VALUES(?,?,?)", (name, d.get("phone"), d.get("notes"))).lastrowid
        audit(con, g.user["id"], "proveedor_creado", f"id={sid}")
    return jsonify(id=sid), 201

@bp.patch("/api/suppliers/<int:sid>")
@role_required("admin")
def edit_supplier(sid):
    d, con, sets, args = request.get_json(silent=True) or {}, db.get_db(), [], []
    for k in ("name", "phone", "notes"):
        if k in d: sets.append(f"{k}=?"); args.append(d[k])
    if "active" in d: sets.append("active=?"); args.append(int(bool(d["active"])))
    if not sets: return err("Nada que actualizar.", 400)
    with con:
        if con.execute(f"UPDATE suppliers SET {','.join(sets)} WHERE id=?", args + [sid]).rowcount != 1: return err("Proveedor no encontrado.", 404)
        audit(con, g.user["id"], "proveedor_editado", f"id={sid}")
    return jsonify(ok=True)

# ---------- Compras ----------
def purchase_detail(con, pid):
    p = con.execute("""
        SELECT p.*, s.name AS supplier, b.name as branch_name 
        FROM purchases p 
        LEFT JOIN suppliers s ON s.id=p.supplier_id 
        LEFT JOIN branches b ON b.id=p.branch_id
        WHERE p.id=?
    """, (pid,)).fetchone()
    if not p: return None
    items = con.execute("""SELECT pi.variant_id,v.sku,pr.name,pi.qty,pi.cost_cents FROM purchase_items pi JOIN variants v ON v.id=pi.variant_id
                           JOIN products pr ON pr.id=v.product_id WHERE pi.purchase_id=?""", (pid,)).fetchall()
    pays = con.execute("SELECT amount_cents,method,created_at FROM purchase_payments WHERE purchase_id=? ORDER BY id", (pid,)).fetchall()
    paid = sum(x["amount_cents"] for x in pays)
    return {"id": pid, "supplier": p["supplier"], "branch_id": p["branch_id"], "branch_name": p["branch_name"],
            "status": p["status"], "created_at": p["created_at"], "total": P(p["total_cents"]),
            "paid": P(paid), "balance": P(p["total_cents"] - paid),
            "items": [{"variant_id": i["variant_id"], "sku": i["sku"], "name": i["name"], "qty": i["qty"], "cost": P(i["cost_cents"])} for i in items],
            "payments": [{"amount": P(x["amount_cents"]), "method": x["method"], "created_at": x["created_at"]} for x in pays]}

@bp.post("/api/purchases")
@role_required("admin")
def create_purchase():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    if not con.execute("SELECT 1 FROM suppliers WHERE id=? AND active=1", (d.get("supplier_id"),)).fetchone(): return err("Proveedor no válido o inactivo.", 400)
    branch_id = d.get("branch_id") or g.user["branch_id"] or db.get_default_branch_id(con)
    try:
        items = []
        for it in d.get("items") or []:
            qty, cost = to_int(it.get("qty"), "cantidad", 1), cents(it.get("cost"), "costo")
            if not con.execute("SELECT 1 FROM variants WHERE id=?", (it.get("variant_id"),)).fetchone(): raise ValueError("Variante no encontrada.")
            items.append((it["variant_id"], qty, cost))
        if not items: raise ValueError("La compra no tiene partidas.")
    except (ValueError, KeyError) as e: return err(str(e), 400)
    with con:
        pid = con.execute("INSERT INTO purchases(supplier_id,user_id,branch_id,total_cents) VALUES(?,?,?,?)",
                          (d["supplier_id"], g.user["id"], branch_id, sum(q * c for _, q, c in items))).lastrowid
        con.executemany("INSERT INTO purchase_items(purchase_id,variant_id,qty,cost_cents) VALUES(?,?,?,?)", [(pid, v, q, c) for v, q, c in items])
        audit(con, g.user["id"], "compra_creada", f"id={pid} sucursal={branch_id}")
    return jsonify(id=pid), 201

@bp.get("/api/purchases")
@role_required("admin")
def list_purchases():
    bid = request.args.get("branch_id")
    sql = "SELECT id FROM purchases WHERE 1=1"
    args = []
    if bid: sql += " AND branch_id=?"; args.append(bid)
    sql += " ORDER BY id DESC LIMIT 100"
    rows = db.get_db().execute(sql, args).fetchall()
    return jsonify(purchases=[purchase_detail(db.get_db(), r["id"]) for r in rows])

@bp.get("/api/purchases/<int:pid>")
@role_required("admin")
def get_purchase(pid):
    r = purchase_detail(db.get_db(), pid)
    return jsonify(r) if r else err("Compra no encontrada.", 404)

@bp.post("/api/purchases/<int:pid>/receive")
@role_required("admin")
def receive(pid):
    con = db.get_db()
    p = con.execute("SELECT * FROM purchases WHERE id=?", (pid,)).fetchone()
    if not p: return err("Compra no encontrada.", 404)
    target_branch = p["branch_id"] or db.get_default_branch_id(con)

    with con:
        if con.execute("UPDATE purchases SET status='recibida' WHERE id=? AND status='pendiente'", (pid,)).rowcount != 1:
            return err("Esta compra ya fue recibida o cancelada.", 409)
        for it in con.execute("SELECT variant_id,qty,cost_cents FROM purchase_items WHERE purchase_id=?", (pid,)).fetchall():
            # Promedio ponderado considerando la existencia consolidada actual del producto
            r = con.execute("""SELECT p.id,p.cost_cents,(SELECT COALESCE(SUM(stock),0) FROM variants WHERE product_id=p.id) AS stock
                               FROM products p WHERE p.id=(SELECT product_id FROM variants WHERE id=?)""", (it["variant_id"],)).fetchone()
            tot = r["stock"] + it["qty"]
            con.execute("UPDATE products SET cost_cents=? WHERE id=?", ((r["stock"] * r["cost_cents"] + it["qty"] * it["cost_cents"] + tot // 2) // tot, r["id"]))
            # El stock físico entra a la sucursal de la compra
            move_stock(con, it["variant_id"], target_branch, "compra", it["qty"], f"Compra #{pid}", g.user["id"], "purchase", pid)
        audit(con, g.user["id"], "compra_recibida", f"id={pid} sucursal={target_branch}")
    return jsonify(ok=True)

@bp.post("/api/purchases/<int:pid>/cancel")
@role_required("admin")
def cancel_purchase(pid):
    con = db.get_db()
    with con:
        if con.execute("UPDATE purchases SET status='cancelada' WHERE id=? AND status='pendiente'", (pid,)).rowcount != 1:
            return err("Solo se pueden cancelar compras pendientes.", 409)
        audit(con, g.user["id"], "compra_cancelada", f"id={pid}")
    return jsonify(ok=True)

@bp.post("/api/purchases/<int:pid>/payments")
@role_required("admin")
def pay_purchase(pid):
    d, con = request.get_json(silent=True) or {}, db.get_db()
    det = purchase_detail(con, pid)
    if not det: return err("Compra no encontrada.", 404)
    if det["status"] == "cancelada": return err("No se puede pagar una compra cancelada.", 409)
    try: amt = cents(d.get("amount"), "monto")
    except ValueError as e: return err(str(e), 400)
    if amt <= 0: return err("El pago debe ser mayor a 0.", 400)
    
    method = str(d.get("method") or "").strip().lower()
    if not method: return err("Indica el método de pago.", 400)
    
    with con:
        # Re-cálculo atómico de saldo restante bajo bloqueo de transacción
        cur_p = con.execute("SELECT total_cents, status FROM purchases WHERE id=?", (pid,)).fetchone()
        if cur_p["status"] == "cancelada":
            return err("No se puede pagar una compra cancelada.", 409)
        already_paid = con.execute("SELECT COALESCE(SUM(amount_cents), 0) FROM purchase_payments WHERE purchase_id=?", (pid,)).fetchone()[0]
        bal_cents = cur_p["total_cents"] - already_paid
        if amt > bal_cents:
            return err(f"El pago excede el saldo pendiente ({P(bal_cents)}).", 400)

        con.execute("INSERT INTO purchase_payments(purchase_id,amount_cents,method,user_id) VALUES(?,?,?,?)", (pid, amt, method, g.user["id"]))
        audit(con, g.user["id"], "pago_proveedor", f"compra={pid} monto={amt}")

    return jsonify(purchase_detail(con, pid)), 201

# ---------- Gastos ----------
@bp.post("/api/expenses")
@role_required("admin")
def add_expense():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    concept = str(d.get("concept") or "").strip()
    branch_id = d.get("branch_id") or g.user["branch_id"]
    try: amt = cents(d.get("amount"), "monto")
    except ValueError as e: return err(str(e), 400)
    if not concept or amt <= 0: return err("Concepto y monto (mayor a 0) son obligatorios.", 400)
    with con:
        eid = con.execute("INSERT INTO expenses(user_id,branch_id,concept,category,amount_cents) VALUES(?,?,?,?,?)",
                          (g.user["id"], branch_id, concept, (str(d.get("category") or "").strip() or "General"), amt)).lastrowid
        audit(con, g.user["id"], "gasto_registrado", f"id={eid} sucursal={branch_id} monto={amt}")
    return jsonify(id=eid), 201

@bp.get("/api/expenses")
@role_required("admin")
def list_expenses():
    sql, args = " WHERE 1=1", []
    if request.args.get("branch_id"):
        sql += " AND branch_id=?"; args.append(request.args.get("branch_id"))
    for k, op in (("from", ">="), ("to", "<=")):
        v = request.args.get(k)
        if v:
            if not DATE_RE.match(v): return err("Fechas en formato AAAA-MM-DD.", 400)
            sql += f" AND date(created_at){op}?"; args.append(v)
    con = db.get_db()
    rows = con.execute("SELECT id,branch_id,concept,category,amount_cents,created_at FROM expenses" + sql + " ORDER BY id DESC", args).fetchall()
    cats = con.execute("SELECT category,SUM(amount_cents) FROM expenses" + sql + " GROUP BY category ORDER BY 2 DESC", args).fetchall()
    return jsonify(expenses=[{"id": r["id"], "branch_id": r["branch_id"], "concept": r["concept"], "category": r["category"], "amount": P(r["amount_cents"]), "created_at": r["created_at"]} for r in rows],
                   by_category={c[0]: P(c[1]) for c in cats}, total=P(sum(r["amount_cents"] for r in rows)))