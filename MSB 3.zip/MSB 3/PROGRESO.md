# Marcela Boutique — Progreso

**Stack:** Python 3 + Flask + SQLite (local). Dinero en centavos (INTEGER). Sin otras dependencias.

## Bloque 1 — Base, autenticación y roles ✅
- `schema.sql`: esquema completo (usuarios, productos, variantes talla/color, movimientos, compras, proveedores, caja, ventas, pagos, gastos, auditoría). CHECK de stock >= 0 y `idempotency_key` única en ventas.
- Login con hash, bloqueo (5 fallos = 10 min), cambio obligatorio de contraseña, cookies HttpOnly/SameSite, escrituras solo JSON.
- Roles `admin` / `cajero` validados en servidor (`role_required`); auditoría de accesos y gestión de usuarios.
- Pruebas: `python -m unittest tests.test_bloque1 -v`

## Bloque 2 — Productos, variantes e inventario ✅
- `inventory.py` (Blueprint). `move_stock()` es la ÚNICA vía para cambiar existencias: atómica, sin negativos, siempre registra movimiento (la usarán ventas y compras).
- API: `GET/POST /api/products`, `PATCH /api/products/<id>`, `POST /api/products/<id>/variants`, `POST /api/variants/<id>/adjust` (motivo obligatorio), `GET /api/inventory/low|movements|export.csv`, `POST /api/inventory/import`.
- Búsqueda por nombre, SKU o código de barras. El cajero no ve costos y no puede crear ni ajustar.
- CSV: importación todo-o-nada; SKUs existentes se omiten (no pisa existencias); exportación protegida contra fórmulas de Excel.
- Pruebas: `python -m unittest tests.test_bloque1 tests.test_bloque2` (16 OK).
- Sin interfaz todavía: la pantalla de inventario llega con la migración del diseño (bloque 6).

## Bloque 3 — Punto de venta ✅
- `sales.py` (Blueprint). `POST /api/sales`: una sola transacción (venta + partidas + pagos + movimientos de inventario); si algo falla, no se guarda nada.
- Precio y costo salen SIEMPRE de la base (el cliente no puede alterarlos). `idempotency_key` obligatoria: reintento/doble clic devuelve la misma venta sin descontar dos veces.
- Pagos: efectivo/tarjeta/transferencia/otro; deben sumar exactamente el total; cambio calculado con efectivo recibido.
- Descuento: cajero hasta 10% (`CASHIER_MAX_DISCOUNT_PCT`); mayor requiere credenciales de la administradora (`authorizer`), con bloqueo tras 5 fallos y auditoría.
- Cancelación: motivo obligatorio + autorización; regresa existencias como `devolucion`; no se puede cancelar dos veces.
- Comprobante imprimible: `GET /api/sales/<id>/receipt.html` (no fiscal). Cajero solo ve sus ventas.
- Incluye apertura de caja (`POST /api/cash/open`, `GET /api/cash/current`) porque toda venta exige caja abierta.
- Pruebas: `python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3` (24 OK).
- NO incluido aún: devolución parcial por partida, incidencias del cajero, pantalla de caja rápida (bloque 6).

## Bloque 4 — Caja y control financiero ✅
- `cash.py` (Blueprint). Efectivo esperado = fondo + cobros en efectivo de la sesión + entradas − salidas.
- API: `GET /api/cash/summary` (ventas por método, canceladas, entradas/salidas, esperado), `POST /api/cash/movements` (motivo obligatorio; una salida no puede exceder el efectivo en caja), `POST /api/cash/close` (contado vs. esperado → diferencia, queda en auditoría), `GET /api/cash/sessions` (admin).
- Cancelar una venta pagada en efectivo registra automáticamente una salida (reembolso) en la caja de quien cancela y exige que esa persona tenga caja abierta.
- Caja cerrada = no se puede vender ni cerrar de nuevo. Cada cajero ve solo sus sesiones; la administradora ve todas.
- Pruebas: `python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3 tests.test_bloque4` (30 OK).
- Aprobado por Marcela: descuento del cajero hasta 10% sin autorización.

## Bloque 5 — Compras, proveedores, gastos y pagos ✅
- `purchases.py` (Blueprint, solo administradora). Proveedores: alta/edición/desactivación.
- Compra nace `pendiente` (no mueve inventario). `POST /api/purchases/<id>/receive` da la entrada una sola vez (segundo intento = 409) y recalcula el costo del producto como promedio ponderado con la existencia actual. Solo se cancelan compras pendientes.
- Pagos a proveedor (`purchase_payments`, tabla nueva): parciales, nunca mayores al saldo; no se paga una compra cancelada.
- Gastos: concepto, categoría y monto > 0; consulta por rango de fechas con total y resumen por categoría. Sin borrado (historial).
- Toda acción POST debe enviar cuerpo JSON (aunque sea `{}`): es la protección anti-CSRF del servidor.
- Pruebas: `python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3 tests.test_bloque4 tests.test_bloque5` (37 OK).
- NO incluido: recepción parcial de compras, gastos pagados desde la caja.

## Bloque 6A — Reportes, balance y auditoría (servidor) ✅
- `reports.py` (solo administradora). Rango `?from=AAAA-MM-DD&to=...` (por defecto, mes actual).
- `GET /api/reports/summary`: ventas (conteo, ticket promedio, por método, canceladas), costo de ventas, utilidad bruta y margen %, gastos, utilidad neta, flujo de efectivo (cobros − gastos − pagos a proveedor), compras recibidas, saldo con proveedores, valor del inventario a costo y a precio.
- `GET /api/reports/top-products`, `GET /api/reports/sales-by-day`, `GET /api/audit` (filtros `action`, `user`, `limit`).
- Las ventas canceladas no cuentan como ingreso. El costo usa el costo guardado al momento de cada venta (no cambia si luego se recalcula el promedio).
- Pruebas: `python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3 tests.test_bloque4 tests.test_bloque5 tests.test_bloque6a` (41 OK).

## Bloque 6B-1 — Interfaz: acceso y caja rápida (POS) ✅
- `templates/app.html` (una sola página, sin dependencias externas). Reemplaza la pantalla de acceso anterior.
- Acceso con cambio de contraseña obligatorio, apertura de caja con fondo inicial, catálogo con filtros por categoría y búsqueda por nombre/SKU/código de barras (Enter agrega la pieza escaneada), selección de talla/color con existencias, carrito con límites de stock, descuento, pagos divididos (hasta 4), cambio automático, modal de autorización de la administradora (descuentos altos y cancelaciones), comprobante imprimible y ventas recientes.
- El cliente reutiliza la misma `idempotency_key` si hay un fallo de red (no duplica la venta).
- Verificación: prueba automática en navegador simulado `tests/ui_smoke` (21 comprobaciones: login, caja, carrito, cambio, descuento con autorización, venta, comprobante, cancelación, logout). Ejecutar: `cd tests/ui_smoke && npm i jsdom`, `python serve.py &` y `node ui.js`.
- Pruebas Python: `python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3 tests.test_bloque4 tests.test_bloque5 tests.test_bloque6a tests.test_bloque6b` (42 OK).

## Bloque 6B-2 — Interfaz: menú y pantalla de Caja ✅
- Menú superior (Caja rápida / Caja). Pantalla Caja: resumen del turno (fondo, cobros en efectivo, entradas, salidas incluyendo reembolsos, efectivo esperado, ventas por método, canceladas), registro de entradas/salidas con motivo, cierre con efectivo contado + confirmación + resultado con diferencia (faltante/sobrante), y "último corte" cuando no hay caja abierta.
- Administradora: historial de todas las cajas con diferencia y botón "Ver" (detalle y movimientos).
- API: el resumen de caja ahora incluye `cash_collected` (cobros en efectivo brutos) para que las cuentas cuadren visualmente.
- Verificación: `tests/ui_smoke/ui.js` (28 comprobaciones, flujo del cajero) y `tests/ui_smoke/admin.js` (historial de la administradora). Ejecutar con `python serve.py &` y `node ui.js` / `node admin.js` (requiere `npm i jsdom`; reiniciar `serve.py` entre ambos).
- Pruebas Python: 42 OK.

## Bloque 7 — Productos e inventario (interfaz) + endurecimiento de la API ✅ (sesión de continuidad)
**Implementado**
- Pestaña **Productos** (solo administradora): catálogo con búsqueda (nombre/categoría/SKU/código), filtros "existencias bajas" e "inactivos", alta de producto con variantes, edición de producto, alta de variante, edición de variante (talla, color, SKU, código de barras, mínimo), activar/desactivar producto y variante (con confirmación si aún hay piezas), ajuste de existencias con motivo obligatorio, historial por variante y general (con SKU y usuario), exportar CSV, importar CSV (todo o nada, muestra las líneas con error).
- API nueva: `PATCH /api/variants/<id>` (auditado, SKU único, SKU vacío rechazado). `GET /api/products` ahora devuelve `active` por variante y **excluye variantes inactivas** salvo `?all=1` de la administradora (antes el POS habría vendido variantes inactivas).
- Endurecimiento: textos validados (`txt()`): un tipo inesperado ya no produce error 500; `image` solo acepta rutas locales `/static/…`; nombre obligatorio al editar; ajustes y existencias con tope; `MAX_CONTENT_LENGTH` 5 MB.
- Cabeceras: `Content-Security-Policy`, `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, `Cache-Control: no-store` en `/` y `/api/*`. `secret.key` se crea con permisos 0600.
**Archivos:** `inventory.py`, `app.py`, `db.py`, `templates/app.html`, `tests/test_bloque7.py`, `tests/ui_pw/productos.py`, `tests/ui_pw/pos.py`.

## Bloque 8 — Respaldo y recuperación ✅
- `backup.py`: copia consistente con la API de respaldo de SQLite (válida con la app en uso), verificada con `integrity_check`; nombres validados por expresión estricta (sin rutas arbitrarias); restaurar exige escribir `RESTAURAR`, valida que el respaldo sea íntegro, tenga las tablas esperadas y **al menos una administradora activa**, y **siempre guarda antes una copia `-pre-restore`** (la restauración se puede deshacer). Todo queda en auditoría.
- Respaldo automático al cerrar caja (se conservan los últimos 14 automáticos; manuales y `pre-restore` nunca se borran solos). Si falla, no impide cerrar la caja y se registra en el log.
- API (solo administradora): `GET/POST /api/backups`, `GET /api/backups/<nombre>/download`, `POST /api/backups/restore`. Pestaña **Respaldo** en la interfaz.
- **Crear:** pestaña Respaldo → "Crear respaldo ahora", o `python backup.py create`. **Listar:** `python backup.py list`.
- **Restaurar:** pestaña Respaldo → "Restaurar" → escribir RESTAURAR, o `python backup.py restore boutique-AAAAMMDD-HHMMSS.db`. Tras restaurar, la página se recarga; si el usuario ya no existe en el respaldo, se pide iniciar sesión.
- **Recuperación ante pérdida total de la PC:** copiar un `.db` descargado a `instance/backups/` en la instalación nueva y restaurarlo con el comando anterior.
- Los respaldos contienen datos financieros y hashes de contraseñas: guardarlos en un lugar seguro. No están cifrados.
**Archivos:** `backup.py`, `cash.py`, `app.py`, `templates/app.html`, `tests/test_bloque8.py`, `tests/ui_pw/respaldo.py`.

## Rediseño integral de interfaz ✅ — plan de migración y resultado
**Diagnóstico (antes):** `templates/app.html` = 316 líneas / 39 KB con CSS (~25 líneas minificadas) y ~220 líneas de JS en un solo `<script>`; estado global suelto, 7 modales casi iguales, menú superior plano con 4 pestañas, tipografía serif en todo (incluidas cifras), sin estilos de foco, sin estados de carga ni vacíos consistentes, tablas hechas con `div.row`. La CSP ya permite `script-src/style-src 'self'`, así que se pueden usar archivos estáticos locales sin tocar `app.py`.
**Estructura objetivo (sin framework nuevo, sin CDN, 100 % local):**
- `static/css/tokens.css` (variables), `static/css/components.css` (botones, campos, tablas, tarjetas KPI, modales, toasts, etiquetas, vacíos, carga), `static/css/layout.css` (shell, navegación, vistas).
- `static/js/core.js` (api, formato, toast, modal/confirmación/formulario, tabla, KPI, rutas por rol) y un archivo por módulo en `static/js/modules/`.
- `templates/app.html` (shell) + `templates/partials/` (macros Jinja reutilizables y una plantilla por vista). `receipt.html` no se toca (impresión de ticket).
**Etapas** (tras cada una se ejecutaron las pruebas): 1) sistema de diseño y estructura · 2) navegación y componentes comunes · 3) Caja rápida y Caja · 4) Productos e inventario · 5) Compras, proveedores y gastos · 6) Reportes, auditoría, usuarios y respaldos.
**Reglas:** no se tocan cálculos, API, esquema ni roles. Los IDs que usan las pruebas existentes se conservan (`#lu #lp #lb #top #nav #openBtn #pos #charge #doneModal #pList #fBody #fOk …`).

### Resultado
- **Sistema de diseño** (`static/css/`): `tokens.css` (colores, tipografía, espaciado, formas, sombras, tamaños; todo contraste de texto ≥ 4.5:1), `components.css` (botones + estado de carga, campos y validación, tablas, filtros, paginación, tarjetas KPI, modales, avisos, etiquetas, vacíos, carga, foco visible, `prefers-reduced-motion`), `layout.css` (acceso, barra superior, menú lateral, composición de vistas, móvil).
- **JS** (`static/js/`): `core.js` (api, formato, avisos, diálogos con Esc y foco atrapado, `table()`, `paged()`, `kpi()`, `badge()`, `withBusy()`, registro de vistas por rol), `app.js` (acceso y arranque) y un módulo por pantalla en `modules/`: `pos`, `caja`, `productos`, `compras`, `gastos`, `reportes`, `auditoria`, `usuarios`, `respaldo`.
- **Plantillas Jinja**: `base.html`, `app.html` y `partials/` (`_ui.html` con macros, `login`, `shell` con menú agrupado por rol, `dialogs`, y una plantilla por vista en `partials/views/`). `receipt.html` no se modificó.
- **Navegación:** menú lateral agrupado (Ventas · Inventario · Compras · Análisis · Administración); en móvil es un cajón. La cajera solo ve *Caja rápida* y *Caja y cortes* (los demás elementos y encabezados vacíos se ocultan; el servidor sigue negando con 403).
- **Pantallas nuevas sobre la API ya existente:** Compras y proveedores (crear, recibir, cancelar, pagar, detalle), Gastos, Reportes y balance, Auditoría (filtros), Usuarios (alta y activar/desactivar).
- **Sin internet:** todo es local (fuentes del sistema, íconos SVG en línea); `tests/test_rediseno.py` falla si aparece cualquier recurso http(s) externo.
- **Sin cambios** en `app.py`, módulos de negocio, `schema.sql` ni CSP.
- Se eliminó el `app.html` monolítico: su contenido quedó íntegramente repartido en los archivos anteriores (cada función migrada se verificó con las pruebas de abajo).

## Resultados de pruebas (22/10/2026, tras el rediseño)
| Suite | Resultado |
|---|---|
| `python -m unittest tests.test_bloque1 … tests.test_bloque8 tests.test_rediseno` (10 módulos) | **60 de 60 OK** (55 previas + 5 nuevas) |
| `python tests/ui_pw/productos.py` (Chromium real) | 20 de 20 OK |
| `python tests/ui_pw/pos.py` (Chromium real) | 5 de 5 OK |
| `python tests/ui_pw/respaldo.py` (Chromium real) | 9 de 9 OK |
| `python tests/ui_pw/admin.py` (**nueva**, Chromium real: flujo de cajera con corte, compras→recibir→pagar, gastos, reportes, auditoría, usuarios, móvil 390 px, permisos 403) | 52 de 52 OK |
- Ejecutar todo: `python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3 tests.test_bloque4 tests.test_bloque5 tests.test_bloque6a tests.test_bloque6b tests.test_bloque7 tests.test_bloque8 tests.test_rediseno` y, con `pip install -r requirements-dev.txt` + `python -m playwright install chromium`, `python tests/ui_pw/<nombre>.py` (`SHOTS=carpeta` en `admin.py` guarda capturas).
- **`tests/ui_smoke/ui.js` y `admin.js` (jsdom): adaptados al nuevo marcado (scripts externos, `#shell`, `.cart-line`) pero NO ejecutados**: `npm i jsdom` falla sin red en este entorno. Su cobertura (pantalla Caja, historial) la repite `ui_pw/admin.py` en navegador real. No se marcan como aprobadas.
- Las pruebas de interfaz usan `bypass_csp` solo porque Playwright evalúa cadenas como JavaScript; la CSP de la app sí está activa.

## Criterios contables simplificados (leer antes de usar los reportes)
- Base de **devengado simple por fecha de venta**: una venta cancelada deja de contar en la fecha de la venta original, aunque se cancele después (no hay cierre de periodos).
- **Utilidad bruta** = ventas completadas − costo guardado en cada partida al vender. **Utilidad neta** = bruta − gastos registrados. No incluye impuestos, depreciación ni sueldos que no se hayan capturado como gasto.
- **"Flujo de efectivo" del reporte es una aproximación**: suma el total de ventas (efectivo, tarjeta y transferencia) menos gastos y pagos a proveedores; no resta reembolsos ni representa el saldo de la caja. El saldo real de efectivo está en el módulo Caja.
- **Saldo con proveedores** incluye compras pendientes aún no recibidas (se trata como compromiso, no solo como mercancía ya recibida).
- **Costo** = promedio ponderado por producto (no por variante), recalculado al recibir una compra.
- No es un balance conciliado ni contabilidad fiscal.

## Defectos y riesgos conocidos (auditoría)
1. ~~Faltaba la interfaz de Compras, Gastos, Reportes, Auditoría y Usuarios~~ → resuelto con el rediseño.
2. La administradora no puede restablecer contraseñas ni cambiar roles (no hay endpoint).
3. No hay devolución parcial por partida; solo cancelación completa.
4. Los gastos no pueden salir de la caja y la fecha no es editable.
5. Restaurar un respaldo no bloquea ventas simultáneas (uso previsto: una sola PC, restaurar sin ventas en curso).
6. Un usuario existente bloqueado recibe un mensaje distinto al de usuario inexistente (permite deducir qué cuentas existen).
7. Servidor local sin HTTPS (cookie sin `Secure`); válido solo en `127.0.0.1`.
8. Respaldos sin cifrar y sin copia externa automática.
9. (Rediseño) Los avisos usan un solo `#toast`: un aviso nuevo reemplaza al anterior. La revisión visual se hizo con capturas de Chromium en 1280 px y 390 px; falta probar en la tableta/pantalla real de la tienda y con el lector de códigos físico.
10. (Rediseño) Los archivos estáticos no llevan versión en la URL: tras actualizar la app, si el navegador conserva CSS/JS viejos, recargar con Ctrl+F5.
11. (Rediseño) `receipt.html` conserva su CSS propio (ticket de 300 px) a propósito; no usa los tokens.

## Decisiones técnicas
- Local en la PC de la boutique (opción A). Escucha solo en 127.0.0.1.
- UI: base oscura del brief con dorado, rosa palo tomado del logo; logo sobre círculo dorado.
- Todo POST con cuerpo JSON (`{}` si no hay datos): protección anti-CSRF. Sin imágenes remotas.

## Pendiente
(6B-4, 6B-5 y la interfaz de usuarios quedaron hechos con el rediseño.)
6B-6. Usuarios: restablecer contraseña y cambio de rol (requiere API nueva; la pantalla ya existe).
6B-7. Devolución parcial; mensaje de login uniforme; gastos desde caja.
Después: demostración controlada con datos ficticios, revisión con la usuaria real y prueba en la impresora de tickets.

## Qué falta para producción
Restablecimiento de contraseñas, revisión del criterio contable con un contador, copia de respaldo externa programada y cifrada, prueba de restauración en una PC limpia, HTTPS si se accede por red, y repetir las pruebas de Caja en navegador.

## Cómo instalar y ejecutar
```
python -m venv .venv && .venv\Scripts\activate      (Windows)   |   source .venv/bin/activate   (macOS/Linux)
pip install -r requirements.txt
python seed.py            # crea a "marcela" con contraseña temporal (anótala; se pide cambiarla al entrar)
python app.py             # http://127.0.0.1:5000
```
Primer acceso real: no hay contraseñas predeterminadas; `seed.py` genera una aleatoria y solo funciona si no existe una administradora.
