"""
Generador de licencias para Marcela Boutique.
Uso en terminal:
  python gen_license.py MB-XXXX-XXXX-XXXX-XXXX [PERPETUAL | AAAA-MM-DD]
"""
import base64, hashlib, hmac, sys

MASTER_SECRET = b"MB_2026_SecKey_LocalLicensing_MarcelaBoutique"

def make_license(machine_id, expires_at="PERPETUAL", tier="MULTISUCURSAL"):
    machine_id = machine_id.strip().upper()
    payload = f"{machine_id}:{expires_at}:{tier}"
    payload_b64 = base64.b64encode(payload.encode("utf-8")).decode("utf-8")
    sig = hmac.new(MASTER_SECRET, payload_b64.encode("utf-8"), hashlib.sha256).hexdigest().upper()[:24]
    return f"{payload_b64}.{sig}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python gen_license.py <ID_DE_MAQUINA> [PERPETUAL | AAAA-MM-DD]")
        print("Ejemplo: python gen_license.py MB-A1B2-C3D4-E5F6 PERPETUAL")
        sys.exit(1)
        
    m_id = sys.argv[1]
    exp = sys.argv[2] if len(sys.argv) > 2 else "PERPETUAL"
    key = make_license(m_id, exp)
    print("\n=======================================================")
    print("  MARCELA BOUTIQUE — GENERADOR DE LICENCIA OFFLINE")
    print("=======================================================")
    print(f"ID de Máquina : {m_id}")
    print(f"Vigencia      : {exp}")
    print(f"Tipo          : MULTISUCURSAL")
    print("-------------------------------------------------------")
    print(f"CLAVE DE ACTIVACIÓN:\n\n{key}\n")
    print("=======================================================\n")