from flask import Blueprint, Response, g, jsonify, render_template_string, request
import db
from auth import login_required

bp = Blueprint("labels", __name__)

# Patrones de barras Code 128 (107 símbolos: barras y espacios)
PATTERNS = [
    "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
    "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
    "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
    "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
    "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
    "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
    "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
    "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
    "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
    "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
    "114131", "311141", "411131", "211412", "211214", "211232", "2331112"
]
START_B, STOP = 104, 106

def code128_svg(text, height=36, bar_width=1.5):
    """Genera un SVG autónomo del código de barras Code 128 resistente a caracteres no ASCII."""
    raw = str(text or "").strip()
    # Transliteración de acentos y caracteres especiales comunes
    trans = {'á':'a','é':'e','í':'i','ó':'o','ú':'u','Á':'A','É':'E','Í':'I','Ó':'O','Ú':'U','ñ':'n','Ñ':'N','ü':'u','Ü':'U'}
    sanitized = []
    for c in raw:
        c = trans.get(c, c)
        if 32 <= ord(c) <= 126:
            sanitized.append(c)
        else:
            sanitized.append('-')
    clean_text = "".join(sanitized) or "000000"

    vals = [START_B] + [ord(c) - 32 for c in clean_text]
    chk = (vals[0] + sum(i * v for i, v in enumerate(vals[1:], 1))) % 103
    vals.extend([chk, STOP])
    
    modules = "".join(PATTERNS[v] for v in vals)
    svg_elements = []
    x = 10.0
    for i, char in enumerate(modules):
        w = int(char) * bar_width
        if i % 2 == 0:  # barra negra
            svg_elements.append(f'<rect x="{x:.1f}" y="0" width="{w:.1f}" height="{height}" fill="#000"/>')
        x += w
    total_w = x + 10.0
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_w:.1f} {height}" style="max-width:100%;height:{height}px;">{"".join(svg_elements)}</svg>'

LABEL_TEMPLATE = """<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Etiquetas</title>
<style>
@page { size: 50mm 30mm; margin: 0; }
body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #fff; color: #000; }
.label { width: 48mm; height: 28mm; padding: 1mm; box-sizing: border-box; page-break-after: always; display: flex; flex-direction: column; align-items: center; justify-content: space-between; text-align: center; }
.brand { font-size: 8pt; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase; }
.pname { font-size: 8.5pt; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 46mm; }
.desc { font-size: 7.5pt; color: #333; }
.barcode-box { margin: 1px 0; }
.sku { font-size: 7.5pt; font-family: monospace; font-weight: bold; }
.price { font-size: 11pt; font-weight: 800; }
@media print { .noprint { display: none; } }
</style>
</head>
<body>
<div class="noprint" style="padding:10px;background:#f5f5f5;border-bottom:1px solid #ccc;text-align:center;">
  <button onclick="window.print()" style="padding:8px 16px;font-size:14px;font-weight:bold;cursor:pointer;">Imprimir Etiquetas</button>
</div>
{% for item in items %}
<div class="label">
  <div class="brand">Marcela Boutique</div>
  <div class="pname">{{ item.name }}</div>
  <div class="desc">{{ item.size }} · {{ item.color }}</div>
  <div class="barcode-box">{{ item.svg|safe }}</div>
  <div class="sku">{{ item.barcode_text }}</div>
  <div class="price">${{ item.price }}</div>
</div>
{% endfor %}
</body>
</html>"""

@bp.get("/api/variants/<int:vid>/label.html")
@login_required
def single_label(vid):
    con = db.get_db()
    r = con.execute("""
        SELECT v.*, p.name, p.price_cents FROM variants v
        JOIN products p ON p.id = v.product_id
        WHERE v.id = ?
    """, (vid,)).fetchone()
    if not r: return "Variante no encontrada", 404

    code = r["barcode"] or r["sku"]
    svg = code128_svg(code)
    items = [{
        "name": r["name"], "size": r["size"] or "-", "color": r["color"] or "-",
        "barcode_text": code, "price": f"{r['price_cents'] / 100:,.2f}", "svg": svg
    }]
    return render_template_string(LABEL_TEMPLATE, items=items)

@bp.get("/api/purchases/<int:pid>/labels.html")
@login_required
def purchase_labels(pid):
    """Imprime todas las etiquetas de los artículos recibidos en una compra."""
    con = db.get_db()
    rows = con.execute("""
        SELECT pi.qty, v.sku, v.barcode, v.size, v.color, pr.name, pr.price_cents
        FROM purchase_items pi
        JOIN variants v ON v.id = pi.variant_id
        JOIN products pr ON pr.id = v.product_id
        WHERE pi.purchase_id = ?
    """, (pid,)).fetchall()
    if not rows: return "Compra no encontrada", 404

    items = []
    for r in rows:
        code = r["barcode"] or r["sku"]
        svg = code128_svg(code)
        for _ in range(r["qty"]):
            items.append({
                "name": r["name"], "size": r["size"] or "-", "color": r["color"] or "-",
                "barcode_text": code, "price": f"{r['price_cents'] / 100:,.2f}", "svg": svg
            })
    return render_template_string(LABEL_TEMPLATE, items=items)