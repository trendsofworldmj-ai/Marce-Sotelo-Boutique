import re
from datetime import date
from flask import Blueprint, jsonify, request
import db
from auth import role_required
from sales import err

bp = Blueprint("reports", __name__)
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
P = lambda c: round((c or 0) / 100, 2)

def period():
    today = date.today()
    f = request.args.get("from") or today.replace(day=1).isoformat()
    t = request.args.get("to") or today.isoformat()
    if not (DATE_RE.match(f) and DATE_RE.match(t)):
        raise ValueError("Fechas en formato AAAA-MM-DD.")
    if f > t:
        raise ValueError("La fecha inicial no puede ser posterior a la final.")
    return f, t

def one(con, sql, args):
    return con.execute(sql, args).fetchone()

@bp.get("/api/reports/summary")
@role_required("admin")
def summary():
    try:
        f, t = period()
    except ValueError as e:
        return err(str(e), 400)
        
    con = db.get_db()
    bid = request.args.get("branch_id", type=int)

    b_sql = " AND branch_id=?" if bid else ""
    b_args = (bid,) if bid else ()
    a = (f, t) + b_args

    # Ventas completadas
    n, sub, disc, total = one(con, f"""
        SELECT COUNT(*), COALESCE(SUM(subtotal_cents),0), COALESCE(SUM(discount_cents),0), COALESCE(SUM(total_cents),0)
        FROM sales 
        WHERE status='completada' AND date(created_at) BETWEEN ? AND ?{b_sql}
    """, a)
    
    # Costo de ventas (COGS)
    cogs = one(con, f"""
        SELECT COALESCE(SUM(si.qty * si.cost_cents), 0)
        FROM sale_items si 
        JOIN sales s ON s.id = si.sale_id
        WHERE s.status='completada' AND date(s.created_at) BETWEEN ? AND ?{b_sql.replace('branch_id', 's.branch_id')}
    """, a)[0]

    # Desglose de ingresos por método de pago
    by_method = {r[0]: P(r[1]) for r in con.execute(f"""
        SELECT p.method, SUM(p.amount_cents)
        FROM payments p 
        JOIN sales s ON s.id = p.sale_id
        WHERE s.status='completada' AND date(s.created_at) BETWEEN ? AND ?{b_sql.replace('branch_id', 's.branch_id')}
        GROUP BY p.method
    """, a)}

    # Ventas canceladas
    cn, ct = one(con, f"""
        SELECT COUNT(*), COALESCE(SUM(total_cents), 0)
        FROM sales 
        WHERE status='cancelada' AND date(created_at) BETWEEN ? AND ?{b_sql}
    """, a)

    # Devoluciones parciales efectuadas en el periodo
    ref_count, ref_cents = one(con, f"""
        SELECT COUNT(*), COALESCE(SUM(refund_amount_cents), 0)
        FROM sale_refunds 
        WHERE date(created_at) BETWEEN ? AND ?{b_sql}
    """, a)

    # Gastos operativos
    exp = one(con, f"""
        SELECT COALESCE(SUM(amount_cents), 0)
        FROM expenses 
        WHERE date(created_at) BETWEEN ? AND ?{b_sql}
    """, a)[0]

    # Compras recibidas
    bought = one(con, f"""
        SELECT COALESCE(SUM(total_cents), 0)
        FROM purchases 
        WHERE status='recibida' AND date(created_at) BETWEEN ? AND ?{b_sql}
    """, a)[0]

    # Pagos a proveedores
    paid = one(con, f"""
        SELECT COALESCE(SUM(x.amount_cents), 0)
        FROM purchase_payments x 
        JOIN purchases q ON q.id = x.purchase_id
        WHERE date(x.created_at) BETWEEN ? AND ?{b_sql.replace('branch_id', 'q.branch_id')}
    """, a)[0]

    # Saldo adeudado a proveedores
    owed = one(con, f"""
        SELECT COALESCE(SUM(p.total_cents), 0) - COALESCE((
            SELECT SUM(x.amount_cents) 
            FROM purchase_payments x 
            JOIN purchases q ON q.id = x.purchase_id 
            WHERE q.status != 'cancelada'{b_sql.replace('branch_id', 'q.branch_id')}
        ), 0)
        FROM purchases p 
        WHERE p.status != 'cancelada'{b_sql}
    """, b_args + b_args)[0]

    gp = total - cogs

    # Valoración de inventario
    inv_sql = """
        SELECT COALESCE(SUM(vs.stock * p.cost_cents), 0), COALESCE(SUM(vs.stock * p.price_cents), 0)
        FROM variant_stock vs
        JOIN variants v ON v.id = vs.variant_id
        JOIN products p ON p.id = v.product_id
        WHERE v.active=1 AND p.active=1
    """
    inv_args = ()
    if bid:
        inv_sql += " AND vs.branch_id=?"; inv_args = (bid,)
    inv = one(con, inv_sql, inv_args)

    return jsonify(
        period={"from": f, "to": t, "branch_id": bid},
        software_info={"engine": "Marcela Boutique Enterprise", "developer": "IQpanda Tecnovador"},
        sales={
            "count": n,
            "subtotal": P(sub),
            "discounts": P(disc),
            "total": P(total),
            "avg_ticket": P(total // n) if n else 0,
            "by_method": by_method,
            "cancelled": {"count": cn, "total": P(ct)},
            "refunds": {"count": ref_count, "total": P(ref_cents)}
        },
        profit={
            "cogs": P(cogs),
            "gross_profit": P(gp),
            "gross_margin_pct": round(gp * 100 / total, 1) if total else 0,
            "expenses": P(exp),
            "net": P(gp - exp)
        },
        cash_flow={
            "in_sales": P(total),
            "out_expenses": P(exp),
            "out_supplier_payments": P(paid),
            "net": P(total - exp - paid)
        },
        purchases={
            "received_total": P(bought),
            "paid_in_period": P(paid),
            "supplier_balance_total": P(owed)
        },
        inventory={
            "value_at_cost": P(inv[0]),
            "value_at_price": P(inv[1])
        }
    )

@bp.get("/api/reports/top-products")
@role_required("admin")
def top_products():
    try: f, t = period()
    except ValueError as e: return err(str(e), 400)
    limit = min(max(request.args.get("limit", 10, type=int), 1), 100)
    bid = request.args.get("branch_id", type=int)
    
    sql = """
        SELECT p.id, p.name, SUM(si.qty) AS units, SUM(si.qty*si.price_cents) AS revenue, SUM(si.qty*si.cost_cents) AS cost
        FROM sale_items si 
        JOIN sales s ON s.id=si.sale_id 
        JOIN variants v ON v.id=si.variant_id 
        JOIN products p ON p.id=v.product_id
        WHERE s.status='completada' AND date(s.created_at) BETWEEN ? AND ?
    """
    args = [f, t]
    if bid:
        sql += " AND s.branch_id=?"; args.append(bid)
    sql += " GROUP BY p.id ORDER BY units DESC, revenue DESC LIMIT ?"
    args.append(limit)
    rows = db.get_db().execute(sql, args).fetchall()
    return jsonify(period={"from": f, "to": t, "branch_id": bid}, note="Ingreso a precio de lista (antes de descuentos).",
                   products=[{"id": r["id"], "name": r["name"], "units": r["units"], "revenue": P(r["revenue"]), "profit": P(r["revenue"] - r["cost"])} for r in rows])

@bp.get("/api/reports/sales-by-day")
@role_required("admin")
def by_day():
    try: f, t = period()
    except ValueError as e: return err(str(e), 400)
    bid = request.args.get("branch_id", type=int)
    sql = "SELECT date(created_at) d,COUNT(*) n,SUM(total_cents) s FROM sales WHERE status='completada' AND date(created_at) BETWEEN ? AND ?"
    args = [f, t]
    if bid:
        sql += " AND branch_id=?"; args.append(bid)
    sql += " GROUP BY d ORDER BY d"
    rows = db.get_db().execute(sql, args).fetchall()
    return jsonify(period={"from": f, "to": t, "branch_id": bid}, days=[{"date": r["d"], "count": r["n"], "total": P(r["s"])} for r in rows])

@bp.get("/api/audit")
@role_required("admin")
def audit_log():
    sql, args = "SELECT a.id,a.created_at,u.username,a.action,a.detail FROM audit_log a LEFT JOIN users u ON u.id=a.user_id WHERE 1=1", []
    if request.args.get("action"): sql += " AND a.action=?"; args.append(request.args["action"])
    if request.args.get("user"): sql += " AND u.username=?"; args.append(request.args["user"].lower())
    args.append(min(max(request.args.get("limit", 100, type=int), 1), 500))
    return jsonify(events=[dict(r) for r in db.get_db().execute(sql + " ORDER BY a.id DESC LIMIT ?", args)])