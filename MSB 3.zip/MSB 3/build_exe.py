"""
Script de compilación para Windows:
Genera la carpeta distribuible con el ejecutable nativo MarcelaBoutique.exe.
Ejecutar con: python build_exe.py
"""
import os, subprocess, sys

def build():
    print("Iniciando empaquetado con PyInstaller...")
    try:
        import PyInstaller
    except ImportError:
        print("Instalando PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--name=MarcelaBoutique",
        "--noconsole",               # Sin ventana negra de consola
        "--onedir",                  # En carpeta para carga instantánea y datos persistentes
        "--add-data=templates;templates",
        "--add-data=static;static",
        "--add-data=schema.sql;.",
        "launcher.py"
    ]
    
    print("Ejecutando:", " ".join(cmd))
    subprocess.check_call(cmd)
    print("\n¡Compilación terminada!")
    print("El ejecutable listo para producción está en: dist/MarcelaBoutique/MarcelaBoutique.exe")

if __name__ == "__main__":
    build()