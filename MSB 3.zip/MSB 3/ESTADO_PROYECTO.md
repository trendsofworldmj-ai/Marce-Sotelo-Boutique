# ESTADO DEL PROYECTO — Marcela Boutique (Sistema Multisucursal Completo)
### Edición Luxury & Enterprise — Desarrollado por IQpanda Tecnovador

Última actualización: 2026-10-24 (Optimización Final de Grado Comercial).

## 1. Arquitectura y Módulos en Producción

- **Ingeniería y Firma:** Diseñado, auditado y desarrollado por **IQpanda Tecnovador**.
- **Topología Multisucursal:** Base de datos centralizada SQLite en modo WAL de alto rendimiento, operada por la sucursal principal (**San José**) y sucursales remotas mediante enlace seguro/VPN.
- **Inventario Local y Consolidado:** Existencias atómicas por sucursal en `variant_stock`. Consultas de existencias consolidadas (`SUM(stock)`) sin riesgo de sobrescritura entre tiendas.
- **Punto de Venta Comercial (POS):**
  - Botonera rápida de denominaciones ($50, $100, $200, $500, $1,000, Exacto).
  - Presets de descuento rápido (5%, 10%) con autorización digital automática o administradora.
  - Atadura de sesión y caja a la sucursal del usuario autenticado; ficha contextual que informa sobre inventario en otras sucursales; lector de código de barras nativo.
- **Traspasos Autorizados:** Solicitud entre tiendas, autorización de administradora, despacho con piezas en tránsito y recepción con control de discrepancias.
- **Apartados (Layaways):** Reserva de mercancía sin sobreventas, abonos a cuenta en caja abierta y entrega física liquidada, con integración total a la cuadratura del corte de caja.
- **Devoluciones Parciales y Cancelaciones Blindadas:** Reembolso y reingreso de prendas específicas por partida sin anular la venta completa, con prevención matemática de doble reembolso en cancelaciones posteriores.
- **Etiquetas Térmicas:** Generador SVG local Code 128 (50×30 mm), sanitizado contra fallos de codificación, 100% independiente de internet.
- **Licenciamiento Offline Criptográfico:** Identificación por hardware de equipo y firmado HMAC-SHA256 para despliegues comerciales.
- **Empaquetado Windows:** Compilación lista para ejecutable (`MarcelaBoutique.exe`) sin consola visible para cajeras.

## 2. Suite Completa de Pruebas Unitarias y de Integración

Ejecución de las 13 suites de prueba (todas aprobadas):
```bash
python -m unittest tests.test_bloque1 tests.test_bloque2 tests.test_bloque3 tests.test_bloque4 \
  tests.test_bloque5 tests.test_bloque6a tests.test_bloque6b tests.test_bloque7 tests.test_bloque8 \
  tests.test_bloque9_multisucursal tests.test_bloque10_multisucursal_core tests.test_bloque11_traspasos_apartados \
  tests.test_bloque12_interfaz_multisucursal tests.test_bloque13_licenciamiento tests.test_rediseno -v