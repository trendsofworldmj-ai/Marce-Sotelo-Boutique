"""Respaldo y restauración de la base de datos con migración automática y verificación de integridad."""
import os, re, sqlite3, sys
from datetime import datetime
from flask import Blueprint, current_app, g, jsonify, request, send_file
import db
from auth import audit, role_required

bp = Blueprint("backup", __name__)
NAME_RE = re.compile(r"^boutique-\d{8}-\d{6}(?:-\d{2})?(?:-(?:auto|pre-restore))?\.db$")
REQUIRED = {"users", "products", "variants", "sales", "sale_items", "payments", "cash_sessions", "audit_log"}
KEEP_AUTO = 14
CONFIRM_WORD = "RESTAURAR"

def backup_dir(app=None):
    app = app or current_app
    d = app.config.get("BACKUP_DIR") or os.path.join(os.path.dirname(os.path.abspath(app.config["DB_PATH"])), "backups")
    os.makedirs(d, exist_ok=True)
    return d

def _check(path):
    """Devuelve None si el archivo es una base SQLite íntegra y completa; si no, el motivo."""
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok": return "El archivo está dañado (integrity_check)."
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not REQUIRED <= tables: return "No es una base de Marcela Boutique (faltan tablas)."
            if not con.execute("SELECT 1 FROM users WHERE role='admin' AND active=1").fetchone():
                return "El respaldo no tiene ninguna administradora activa; restaurarlo dejaría el sistema sin acceso."
        finally: con.close()
    except sqlite3.DatabaseError: return "El archivo no es una base de datos válida."
    return None

def create_backup(app, tag=""):
    d, stamp = backup_dir(app), datetime.now().strftime("%Y%m%d-%H%M%S")
    name, n = f"boutique-{stamp}{('-' + tag) if tag else ''}.db", 1
    while os.path.exists(os.path.join(d, name)):
        name = f"boutique-{stamp}-{n:02d}{('-' + tag) if tag else ''}.db"; n += 1
    path = os.path.join(d, name)
    src, dst = sqlite3.connect(app.config["DB_PATH"]), sqlite3.connect(path)
    try: src.backup(dst)
    finally: dst.close(); src.close()
    problem = _check(path)
    if problem:
        os.remove(path); raise RuntimeError(problem)
    if tag == "auto": _prune(d)
    return name

def _prune(d):
    autos = sorted((f for f in os.listdir(d) if NAME_RE.match(f) and f.endswith("-auto.db")), key=lambda f: (os.stat(os.path.join(d, f)).st_mtime_ns, f))
    for f in autos[:-KEEP_AUTO]: os.remove(os.path.join(d, f))

def list_backups(app):
    d, out = backup_dir(app), []
    for f in sorted(os.listdir(d), reverse=True):
        if NAME_RE.match(f):
            st = os.stat(os.path.join(d, f))
            out.append({"name": f, "size_kb": round(st.st_size / 1024, 1), "created_at": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                        "kind": "automático" if f.endswith("-auto.db") else "previo a restauración" if f.endswith("-pre-restore.db") else "manual"})
    return out

def restore_backup(app, name):
    if not NAME_RE.match(name or ""): raise ValueError("Nombre de respaldo no válido.")
    path = os.path.join(backup_dir(app), name)
    if not os.path.isfile(path): raise FileNotFoundError("Ese respaldo no existe.")
    problem = _check(path)
    if problem: raise ValueError(problem)
    safety = create_backup(app, "pre-restore")
    src, dst = sqlite3.connect(f"file:{path}?mode=ro", uri=True), sqlite3.connect(app.config["DB_PATH"])
    try:
        src.backup(dst)
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql"), encoding="utf-8") as f:
            dst.executescript(f.read())
        # Ejecutar migración para que respaldos de versiones anteriores adquieran columnas y tablas nuevas
        dst.row_factory = sqlite3.Row
        db._migrate(dst)
        dst.commit()
    finally: src.close(); dst.close()
    return safety

# ---------------- API (solo administradora) ----------------
@bp.get("/api/backups")
@role_required("admin")
def api_list(): return jsonify(backups=list_backups(current_app))

@bp.post("/api/backups")
@role_required("admin")
def api_create():
    try: name = create_backup(current_app, "")
    except Exception as e: return jsonify(error=f"No se pudo crear el respaldo: {e}"), 500
    con = db.get_db()
    with con: audit(con, g.user["id"], "backup_creado", name)
    return jsonify(name=name), 201

@bp.get("/api/backups/<name>/download")
@role_required("admin")
def api_download(name):
    if not NAME_RE.match(name): return jsonify(error="Nombre de respaldo no válido."), 400
    path = os.path.join(backup_dir(), name)
    if not os.path.isfile(path): return jsonify(error="Ese respaldo no existe."), 404
    con = db.get_db()
    with con: audit(con, g.user["id"], "backup_descargado", name)
    return send_file(path, as_attachment=True, download_name=name, mimetype="application/octet-stream")

@bp.post("/api/backups/restore")
@role_required("admin")
def api_restore():
    d = request.get_json(silent=True) or {}
    name = str(d.get("name") or "")
    if str(d.get("confirm") or "") != CONFIRM_WORD: return jsonify(error=f"Escribe {CONFIRM_WORD} para confirmar."), 400
    uid = g.user["id"]
    try: safety = restore_backup(current_app, name)
    except FileNotFoundError as e: return jsonify(error=str(e)), 404
    except (ValueError, RuntimeError) as e: return jsonify(error=str(e)), 400
    con = sqlite3.connect(current_app.config["DB_PATH"])
    try:
        with con: con.execute("INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)",
                              (uid if con.execute("SELECT 1 FROM users WHERE id=?", (uid,)).fetchone() else None, "backup_restaurado", f"desde={name} copia_previa={safety}"))
    finally: con.close()
    return jsonify(ok=True, safety_copy=safety)

# ---------------- línea de comandos ----------------
if __name__ == "__main__":
    from app import create_app
    app, args = create_app(), sys.argv[1:]
    cmd = args[0] if args else ""
    if cmd == "create": print("Respaldo creado:", os.path.join(backup_dir(app), create_backup(app, "")))
    elif cmd == "list":
        for b in list_backups(app): print(f"{b['name']}  {b['size_kb']} KB  {b['kind']}  {b['created_at']}")
    elif cmd == "restore" and len(args) >= 2:
        name = os.path.basename(args[1])
        if "--yes" not in args and input(f"Esto reemplaza TODA la información actual con {name}. Escribe {CONFIRM_WORD}: ").strip() != CONFIRM_WORD: sys.exit("Cancelado.")
        try: print("Restaurado. Copia previa:", restore_backup(app, name))
        except (ValueError, FileNotFoundError, RuntimeError) as e: sys.exit(f"No se restauró nada: {e}")
    else: sys.exit("Uso: python backup.py create | list | restore ARCHIVO [--yes]")