import sqlite3
from datetime import datetime, timedelta
from decimal import Decimal
from flask import Blueprint, g, jsonify, render_template, request
from werkzeug.security import check_password_hash
import db
from auth import audit, login_required
from inventory import StockError, cents, move_stock

bp = Blueprint("sales", __name__)
METHODS = {"efectivo", "tarjeta", "transferencia", "otro"}
REFUND_METHODS = {"efectivo", "tarjeta", "transferencia", "saldo_favor", "otro"}
CASHIER_MAX_DISCOUNT_PCT = 10

def err(msg, code=400): return jsonify(error=msg), code
def folio(sid): return f"MB-{sid:06d}"
def ref_folio(rfid): return f"DEV-{rfid:06d}"

@bp.app_template_filter("mxn")
def mxn(c): return f"${c / 100:,.2f}"

def current_session(con, uid):
    return con.execute("SELECT * FROM cash_sessions WHERE user_id=? AND status='abierta'", (uid,)).fetchone()

def authorizer(con, d):
    if g.user["role"] == "admin": return g.user["id"]
    a = d.get("authorizer") or {}
    u = con.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1", (str(a.get("username", "")).strip().lower(),)).fetchone()
    if u and u["locked_until"] and datetime.fromisoformat(u["locked_until"]) > datetime.now(): return None
    if u and check_password_hash(u["pass_hash"], str(a.get("password", ""))):
        # Resetear intentos fallidos y bloqueo tras autorización exitosa
        with con:
            con.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?", (u["id"],))
        return u["id"]
    with con:
        if u:
            n = u["failed_attempts"] + 1
            lock = (datetime.now() + timedelta(minutes=10)).isoformat() if n >= 5 else None
            con.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?", (0 if lock else n, lock, u["id"]))
        audit(con, g.user["id"], "autorizacion_fallida", request.path)
    return None

@bp.post("/api/cash/open")
@login_required
def open_cash():
    con = db.get_db()
    if current_session(con, g.user["id"]): return err("Ya tienes una caja abierta.", 409)
    try: opening = cents((request.get_json(silent=True) or {}).get("opening", 0), "fondo inicial")
    except ValueError as e: return err(str(e), 400)
    
    branch_id = g.user["branch_id"] or db.get_default_branch_id(con)
    with con:
        cur = con.execute("INSERT INTO cash_sessions(user_id,branch_id,opening_cents) VALUES(?,?,?)", (g.user["id"], branch_id, opening))
        audit(con, g.user["id"], "caja_abierta", f"sesion={cur.lastrowid} sucursal={branch_id}")
    return jsonify(session_id=cur.lastrowid, branch_id=branch_id), 201

@bp.get("/api/cash/current")
@login_required
def cash_current():
    s = current_session(db.get_db(), g.user["id"])
    return jsonify(session=dict(s) if s else None)

def parse_sale(con, d, branch_id):
    lines = {}
    for it in d.get("items") or []:
        try: vid, qty = int(it["variant_id"]), int(it["qty"])
        except (KeyError, TypeError, ValueError): raise ValueError("Partida no válida.")
        if qty <= 0: raise ValueError("La cantidad debe ser mayor a 0.")
        lines[vid] = lines.get(vid, 0) + qty
    if not lines: raise ValueError("El carrito está vacío.")
    
    items = []
    for vid, qty in lines.items():
        r = con.execute("""
            SELECT v.id, v.sku, p.price_cents, p.cost_cents,
                   COALESCE(vs.stock, 0) as stock, COALESCE(vs.reserved, 0) as reserved
            FROM variants v 
            JOIN products p ON p.id = v.product_id
            LEFT JOIN variant_stock vs ON vs.variant_id = v.id AND vs.branch_id = ?
            WHERE v.id=? AND v.active=1 AND p.active=1
        """, (branch_id, vid)).fetchone()
        
        if not r: raise ValueError(f"La variante {vid} no existe o está inactiva.")
        avail = r["stock"] - r["reserved"]
        if avail < qty:
            raise StockError(f"Existencia insuficiente en sucursal para SKU: {r['sku']} (Disponible: {avail}, Solicitado: {qty})")

        items.append({"vid": vid, "sku": r["sku"], "qty": qty, "price": r["price_cents"], "cost": r["cost_cents"]})
        
    subtotal = sum(i["price"] * i["qty"] for i in items)
    disc = cents(d.get("discount", 0), "descuento")
    if disc > subtotal: raise ValueError("El descuento no puede exceder el subtotal.")
    total = subtotal - disc
    if total <= 0: raise ValueError("El total debe ser mayor a 0.")
    pays = []
    for p in d.get("payments") or []:
        m = str(p.get("method", "")).lower()
        if m not in METHODS: raise ValueError(f"Método de pago no válido: {m}.")
        amt = cents(p.get("amount"), "pago")
        rec = cents(p["received"], "recibido") if m == "efectivo" and p.get("received") is not None else None
        if amt <= 0 or (rec is not None and rec < amt): raise ValueError("Pago no válido (monto o efectivo recibido).")
        pays.append((m, amt, rec))
    if sum(p[1] for p in pays) != total: raise ValueError(f"Los pagos deben sumar exactamente el total ({mxn(total)}).")
    return items, subtotal, disc, total, pays

@bp.post("/api/sales")
@login_required
def create_sale():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    key = str(d.get("idempotency_key") or "").strip()
    if len(key) < 8: return err("Falta la llave de operación (idempotency_key).", 400)
    
    def existing():
        r = con.execute("SELECT id,user_id FROM sales WHERE idempotency_key=?", (key,)).fetchone()
        return (jsonify(id=r["id"], folio=folio(r["id"]), duplicate=True), 200) if r and r["user_id"] == g.user["id"] else None
    if (x := existing()): return x
    
    sess = current_session(con, g.user["id"])
    if not sess: return err("Abre tu caja antes de vender.", 409)

    branch_id = sess["branch_id"] or g.user["branch_id"] or db.get_default_branch_id(con)

    try: items, subtotal, disc, total, pays = parse_sale(con, d, branch_id)
    except (ValueError, StockError) as e: return err(str(e), 409 if isinstance(e, StockError) else 400)

    auth_by = None
    if disc > 0:
        if g.user["role"] == "admin" or disc * 100 <= subtotal * CASHIER_MAX_DISCOUNT_PCT:
            auth_by = g.user["id"] if g.user["role"] == "admin" else None
        elif not (auth_by := authorizer(con, d)):
            return err(f"Descuento mayor a {CASHIER_MAX_DISCOUNT_PCT}%: requiere autorización de la administradora.", 403)
            
    try:
        with con:
            sid = con.execute(
                "INSERT INTO sales(session_id,user_id,branch_id,idempotency_key,subtotal_cents,discount_cents,total_cents,authorized_by) VALUES(?,?,?,?,?,?,?,?)",
                (sess["id"], g.user["id"], branch_id, key, subtotal, disc, total, auth_by)
            ).lastrowid
            
            for i in items:
                con.execute("INSERT INTO sale_items(sale_id,variant_id,qty,price_cents,cost_cents) VALUES(?,?,?,?,?)",
                            (sid, i["vid"], i["qty"], i["price"], i["cost"]))
                move_stock(con, i["vid"], branch_id, "venta", -i["qty"], f"Venta {folio(sid)}", g.user["id"], "sale", sid)

            for m, amt, rec in pays:
                con.execute("INSERT INTO payments(sale_id,method,amount_cents,received_cents) VALUES(?,?,?,?)",
                            (sid, m, amt, rec))
            audit(con, g.user["id"], "venta", f"{folio(sid)} sucursal={branch_id} total={total}")
    except StockError as e: return err(str(e), 409)
    except sqlite3.IntegrityError:
        return existing() or err("No se pudo registrar la venta.", 409)
        
    return jsonify(id=sid, folio=folio(sid), total=total / 100, change=sum((r - a) for _, a, r in pays if r is not None) / 100), 201

def load_sale(con, sid):
    s = con.execute("SELECT s.*,u.full_name AS cashier, b.name as branch_name FROM sales s JOIN users u ON u.id=s.user_id LEFT JOIN branches b ON b.id=s.branch_id WHERE s.id=?", (sid,)).fetchone()
    if not s or (g.user["role"] != "admin" and s["user_id"] != g.user["id"]): return None
    items = con.execute("""SELECT si.id,si.qty,si.price_cents,p.name,v.size,v.color,v.sku FROM sale_items si
                           JOIN variants v ON v.id=si.variant_id JOIN products p ON p.id=v.product_id WHERE si.sale_id=?""", (sid,)).fetchall()
    pays = con.execute("SELECT * FROM payments WHERE sale_id=?", (sid,)).fetchall()
    change = sum((p["received_cents"] - p["amount_cents"]) for p in pays if p["received_cents"] is not None)
    return {"sale": s, "folio": folio(sid), "items": items, "payments": pays, "change": change}

@bp.get("/api/sales")
@login_required
def list_sales():
    con, sql, args = db.get_db(), "SELECT id,session_id,user_id,branch_id,total_cents,status,created_at FROM sales", []
    if g.user["role"] != "admin":
        sql += " WHERE user_id=?"; args.append(g.user["id"])
    elif request.args.get("branch_id"):
        sql += " WHERE branch_id=?"; args.append(request.args.get("branch_id"))
    return jsonify(sales=[dict(r, folio=folio(r["id"])) for r in con.execute(sql + " ORDER BY id DESC LIMIT 50", args)])

@bp.get("/api/sales/<int:sid>")
@login_required
def sale_json(sid):
    r = load_sale(db.get_db(), sid)
    if not r: return err("Venta no encontrada.", 404)
    return jsonify(folio=r["folio"], sale=dict(r["sale"]), items=[dict(i) for i in r["items"]], payments=[dict(p) for p in r["payments"]], change=r["change"] / 100)

@bp.get("/api/sales/<int:sid>/receipt.html")
@login_required
def receipt(sid):
    r = load_sale(db.get_db(), sid)
    return render_template("receipt.html", **r) if r else err("Venta no encontrada.", 404)

@bp.post("/api/sales/<int:sid>/cancel")
@login_required
def cancel(sid):
    d, con = request.get_json(silent=True) or {}, db.get_db()
    reason = str(d.get("reason") or "").strip()
    if len(reason) < 5: return err("Escribe el motivo de la cancelación (mín. 5 caracteres).", 400)
    r = load_sale(con, sid)
    if not r: return err("Venta no encontrada.", 404)
    if r["sale"]["status"] != "completada": return err("La venta ya está cancelada.", 409)
    if not (auth_id := authorizer(con, d)): return err("Se requiere autorización de la administradora.", 403)
    
    cash_paid = con.execute("SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE sale_id=? AND method='efectivo'", (sid,)).fetchone()[0]
    
    # Restar reembolsos previos para evitar doble salida de efectivo
    already_refunded_cash = con.execute("""
        SELECT COALESCE(SUM(refund_amount_cents), 0) FROM sale_refunds 
        WHERE sale_id=? AND method='efectivo'
    """, (sid,)).fetchone()[0]
    cash_to_refund = max(0, cash_paid - already_refunded_cash)

    drawer = current_session(con, g.user["id"])
    if cash_to_refund > 0 and not drawer: return err("Abre tu caja para registrar el reembolso en efectivo.", 409)
    
    branch_id = drawer["branch_id"] if drawer else (r["sale"]["branch_id"] or db.get_default_branch_id(con))

    with con:
        if con.execute("UPDATE sales SET status='cancelada',cancel_reason=?,authorized_by=? WHERE id=? AND status='completada'", (reason, auth_id, sid)).rowcount != 1:
            return err("La venta ya está cancelada.", 409)
        
        # Devolver solo las prendas que no hayan sido reembolsadas previamente
        sale_items = con.execute("SELECT id, variant_id, qty FROM sale_items WHERE sale_id=?", (sid,)).fetchall()
        for row in sale_items:
            already_refunded_qty = con.execute("""
                SELECT COALESCE(SUM(qty), 0) FROM sale_refund_items WHERE sale_item_id=?
            """, (row["id"],)).fetchone()[0]
            remaining_qty = row["qty"] - already_refunded_qty
            if remaining_qty > 0:
                move_stock(con, row["variant_id"], branch_id, "devolucion", remaining_qty, f"Cancelación {folio(sid)}: {reason}", g.user["id"], "sale", sid)

        if cash_to_refund > 0 and drawer:
            con.execute("INSERT INTO cash_movements(session_id,kind,amount_cents,reason,user_id) VALUES(?,?,?,?,?)",
                        (drawer["id"], "salida", cash_to_refund, f"Reembolso cancelación {folio(sid)}", g.user["id"]))
        audit(con, g.user["id"], "venta_cancelada", f"{folio(sid)} autoriza={auth_id} sucursal={branch_id}")
    return jsonify(ok=True)

@bp.post("/api/sales/<int:sid>/refund")
@login_required
def partial_refund(sid):
    d, con = request.get_json(silent=True) or {}, db.get_db()
    reason = str(d.get("reason") or "").strip()
    if len(reason) < 5: return err("Escribe el motivo de la devolución (mín. 5 caracteres).", 400)
    
    s = con.execute("SELECT * FROM sales WHERE id=?", (sid,)).fetchone()
    if not s: return err("Venta no encontrada.", 404)
    if s["status"] != "completada": return err("Solo se pueden procesar devoluciones sobre ventas completadas.", 409)

    method = str(d.get("method") or "efectivo").lower()
    if method not in REFUND_METHODS:
        return err(f"Método de reembolso no válido: {method}.", 400)

    if not (auth_id := authorizer(con, d)):
        return err("Se requiere autorización de la administradora.", 403)

    return_items = d.get("items") or []
    if not return_items: return err("Indica las prendas a devolver.", 400)

    # Consolidar líneas por sale_item_id para blindar contra partidas duplicadas en payload
    lines = {}
    for it in return_items:
        try:
            si_id = int(it.get("sale_item_id"))
            qty_val = int(it.get("qty", 1))
        except (TypeError, ValueError):
            return err("Partida o cantidad no válida.", 400)
        if qty_val <= 0: return err("Cantidad a devolver debe ser mayor a 0.", 400)
        lines[si_id] = lines.get(si_id, 0) + qty_val

    refund_lines = []
    total_refund_cents = 0
    disc_ratio = Decimal(s["discount_cents"]) / Decimal(s["subtotal_cents"]) if s["subtotal_cents"] else Decimal(0)

    for si_id, qty_to_return in lines.items():
        si = con.execute("SELECT * FROM sale_items WHERE id=? AND sale_id=?", (si_id, sid)).fetchone()
        if not si: return err(f"Partida {si_id} no encontrada en esta venta.", 404)

        already_refunded = con.execute("""
            SELECT COALESCE(SUM(qty), 0) FROM sale_refund_items WHERE sale_item_id=?
        """, (si_id,)).fetchone()[0]

        if (already_refunded + qty_to_return) > si["qty"]:
            return err(f"No se pueden devolver {qty_to_return} piezas. Vendidas: {si['qty']}, Ya devueltas: {already_refunded}.", 400)

        unit_effective = int(Decimal(si["price_cents"]) * (Decimal(1) - disc_ratio))
        line_refund = unit_effective * qty_to_return
        total_refund_cents += line_refund
        refund_lines.append((si_id, si["variant_id"], qty_to_return, line_refund))

    if total_refund_cents <= 0:
        return err("El monto total a devolver debe ser mayor a 0.", 400)

    drawer = current_session(con, g.user["id"])
    if method == "efectivo" and not drawer:
        return err("Abre tu caja para registrar el reembolso en efectivo.", 409)

    branch_id = drawer["branch_id"] if drawer else (s["branch_id"] or db.get_default_branch_id(con))

    with con:
        cur = con.execute("""
            INSERT INTO sale_refunds (folio, sale_id, session_id, branch_id, user_id, authorized_by, refund_amount_cents, method, reason)
            VALUES ('TEMP', ?, ?, ?, ?, ?, ?, ?, ?)
        """, (sid, drawer["id"] if drawer else None, branch_id, g.user["id"], auth_id, total_refund_cents, method, reason))
        rfid = cur.lastrowid
        r_folio = ref_folio(rfid)
        con.execute("UPDATE sale_refunds SET folio=? WHERE id=?", (r_folio, rfid))

        for si_id, vid, qty, amt in refund_lines:
            con.execute("INSERT INTO sale_refund_items (refund_id, sale_item_id, variant_id, qty, refund_cents) VALUES (?,?,?,?,?)",
                        (rfid, si_id, vid, qty, amt))
            move_stock(con, vid, branch_id, "devolucion", qty, f"Devolución parcial {r_folio}: {reason}", g.user["id"], "refund", rfid)

        if method == "efectivo" and drawer:
            con.execute("""
                INSERT INTO cash_movements (session_id, kind, amount_cents, reason, user_id)
                VALUES (?, 'salida', ?, ?, ?)
            """, (drawer["id"], total_refund_cents, f"Reembolso devolución {r_folio}", g.user["id"]))

        audit(con, g.user["id"], "devolucion_parcial", f"{r_folio} venta={folio(sid)} monto={total_refund_cents}")

    return jsonify(id=rfid, folio=r_folio, refund_total=total_refund_cents / 100), 201