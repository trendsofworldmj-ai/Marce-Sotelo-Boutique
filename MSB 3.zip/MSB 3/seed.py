"""Crea la administradora inicial (una sola vez). Uso: python seed.py"""
import secrets
from app import create_app
import db
from auth import audit, create_user

app = create_app()
with app.app_context():
    con = db.get_db()
    if con.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        print("Ya existe una administradora. No se hizo nada.")
    else:
        pw = secrets.token_urlsafe(9)
        with con:
            create_user(con, "marcela", "Marcela", "admin", pw)
            audit(con, None, "seed_admin")
        print(f"Usuario: marcela\nContraseña temporal: {pw}\n(Se pedirá cambiarla en el primer inicio de sesión.)")
