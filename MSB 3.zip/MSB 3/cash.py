from flask import Blueprint, current_app, g, jsonify, request
import db
from auth import audit, login_required, role_required
from inventory import cents
from sales import current_session, err

bp = Blueprint("cash", __name__)

def summary(con, sid):
    """Efectivo esperado = fondo + cobros en efectivo (ventas y apartados) de la sesión + entradas - salidas."""
    s = con.execute("SELECT * FROM cash_sessions WHERE id=?", (sid,)).fetchone()
    q = lambda sql: con.execute(sql, (sid,)).fetchone()
    
    # Desglose de cobros por método en ventas completadas
    by_method = {r[0]: r[1] for r in con.execute("""
        SELECT p.method, SUM(p.amount_cents) FROM payments p JOIN sales x ON x.id=p.sale_id
        WHERE x.session_id=? AND x.status='completada' GROUP BY p.method
    """, (sid,))}
    
    # Desglose de abonos y anticipos de apartados (layaways) cobrados en este turno
    layaway_pays = con.execute("""
        SELECT method, SUM(amount_cents) FROM layaway_payments 
        WHERE session_id=? GROUP BY method
    """, (sid,)).fetchall()
    for m, amt in layaway_pays:
        by_method[m] = by_method.get(m, 0) + amt

    # Efectivo bruto recibido de ventas y de apartados
    cash_sales = q("SELECT COALESCE(SUM(p.amount_cents),0) FROM payments p JOIN sales x ON x.id=p.sale_id WHERE x.session_id=? AND p.method='efectivo'")[0]
    cash_layaways = q("SELECT COALESCE(SUM(amount_cents),0) FROM layaway_payments WHERE session_id=? AND method='efectivo'")[0]
    cash_gross = cash_sales + cash_layaways

    ent = q("SELECT COALESCE(SUM(amount_cents),0) FROM cash_movements WHERE session_id=? AND kind='entrada'")[0]
    sal = q("SELECT COALESCE(SUM(amount_cents),0) FROM cash_movements WHERE session_id=? AND kind='salida'")[0]
    canc = q("SELECT COUNT(*),COALESCE(SUM(total_cents),0) FROM sales WHERE session_id=? AND status='cancelada'")
    exp = s["opening_cents"] + cash_gross + ent - sal
    mv = [dict(r) for r in con.execute("SELECT kind,amount_cents,reason,created_at FROM cash_movements WHERE session_id=? ORDER BY id", (sid,))]
    P = lambda c: c / 100
    return {"session_id": sid, "status": s["status"], "opened_at": s["opened_at"], "closed_at": s["closed_at"], "opening": P(s["opening_cents"]), "cash_collected": P(cash_gross),
            "sales_by_method": {k: P(v) for k, v in by_method.items()}, "sales_total": P(sum(by_method.values())),
            "cancelled": {"count": canc[0], "total": P(canc[1])}, "entradas": P(ent), "salidas": P(sal), "expected": P(exp),
            "counted": None if s["counted_cents"] is None else P(s["counted_cents"]),
            "difference": None if s["counted_cents"] is None else P(s["counted_cents"] - s["expected_cents"]), "movements": mv}, exp

def visible(con, sid):
    s = con.execute("SELECT * FROM cash_sessions WHERE id=?", (sid,)).fetchone()
    return s if s and (g.user["role"] == "admin" or s["user_id"] == g.user["id"]) else None

@bp.get("/api/cash/summary")
@login_required
def cash_summary():
    con = db.get_db()
    sid = request.args.get("session_id", type=int)
    if sid is None:
        s = current_session(con, g.user["id"])
        if not s: return err("No tienes una caja abierta.", 404)
        sid = s["id"]
    elif not visible(con, sid): return err("Sesión no encontrada.", 404)
    return jsonify(summary(con, sid)[0])

@bp.post("/api/cash/movements")
@login_required
def cash_movement():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    s = current_session(con, g.user["id"])
    if not s: return err("Abre tu caja antes de registrar movimientos.", 409)
    kind, reason = str(d.get("kind", "")), str(d.get("reason") or "").strip()
    if kind not in ("entrada", "salida"): return err("Tipo de movimiento no válido.", 400)
    if len(reason) < 5: return err("Escribe el motivo (mín. 5 caracteres).", 400)
    try: amt = cents(d.get("amount"), "monto")
    except ValueError as e: return err(str(e), 400)
    if amt <= 0: return err("El monto debe ser mayor a 0.", 400)
    with con:
        if kind == "salida" and amt > summary(con, s["id"])[1]: return err("No hay suficiente efectivo en caja para esa salida.", 400)
        con.execute("INSERT INTO cash_movements(session_id,kind,amount_cents,reason,user_id) VALUES(?,?,?,?,?)", (s["id"], kind, amt, reason, g.user["id"]))
        audit(con, g.user["id"], f"caja_{kind}", f"sesion={s['id']} monto={amt}")
    return jsonify(ok=True), 201

@bp.post("/api/cash/close")
@login_required
def close_cash():
    d, con = request.get_json(silent=True) or {}, db.get_db()
    s = current_session(con, g.user["id"])
    if not s: return err("No tienes una caja abierta.", 409)
    try: counted = cents(d.get("counted"), "efectivo contado")
    except ValueError as e: return err(str(e), 400)
    with con:
        exp = summary(con, s["id"])[1]
        con.execute("UPDATE cash_sessions SET status='cerrada',closed_at=datetime('now','localtime'),expected_cents=?,counted_cents=? WHERE id=?", (exp, counted, s["id"]))
        audit(con, g.user["id"], "caja_cerrada", f"sesion={s['id']} esperado={exp} contado={counted} diferencia={counted - exp}")
    try:    # respaldo automático al cerrar caja; un fallo aquí no debe impedir el cierre
        import backup
        backup.create_backup(current_app._get_current_object(), "auto")
    except Exception as e: current_app.logger.warning("Respaldo automático falló: %s", e)
    return jsonify(summary(con, s["id"])[0])

@bp.get("/api/cash/sessions")
@role_required("admin")
def sessions():
    rows = db.get_db().execute("""SELECT c.id,u.username,c.opened_at,c.closed_at,c.status,c.expected_cents,c.counted_cents FROM cash_sessions c
                                  JOIN users u ON u.id=c.user_id ORDER BY c.id DESC LIMIT 100""").fetchall()
    return jsonify(sessions=[{"id": r["id"], "user": r["username"], "opened_at": r["opened_at"], "closed_at": r["closed_at"], "status": r["status"],
                              "difference": None if r["counted_cents"] is None else (r["counted_cents"] - r["expected_cents"]) / 100} for r in rows])