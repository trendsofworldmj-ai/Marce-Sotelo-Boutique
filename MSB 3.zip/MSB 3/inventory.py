import csv, io, sqlite3
from decimal import Decimal, InvalidOperation
from flask import Blueprint, Response, g, jsonify, request
import db
from auth import audit, login_required, role_required

bp = Blueprint("inv", __name__)
CSV_COLS = ["producto", "categoria", "marca", "sku", "barcode", "talla", "color", "costo", "precio", "existencia", "minimo", "sucursal"]

class StockError(ValueError): pass

def cents(v, field="monto"):
    try: c = int((Decimal(str(v)) * 100).quantize(Decimal(1)))
    except (InvalidOperation, ValueError): raise ValueError(f"{field}: número no válido.")
    if c < 0: raise ValueError(f"{field}: no puede ser negativo.")
    return c

def to_int(v, field, minimum=0):
    try: n = int(str(v).strip() or 0)
    except ValueError: raise ValueError(f"{field}: debe ser un entero.")
    if n < minimum: raise ValueError(f"{field}: mínimo {minimum}.")
    return n

def txt(v, field="texto", maxlen=200):
    if v is None: return None
    if not isinstance(v, (str, int, float)) or isinstance(v, bool): raise ValueError(f"{field}: texto no válido.")
    v = str(v).strip()
    if len(v) > maxlen: raise ValueError(f"{field}: máximo {maxlen} caracteres.")
    return v or None

def img(v):
    v = txt(v, "imagen", 300)
    if v and not v.startswith("/static/"): raise ValueError("imagen: solo rutas locales que empiecen con /static/.")
    return v

def _resolve_branch_id(con, branch_id=None, user=None):
    if branch_id is not None:
        b = con.execute("SELECT id FROM branches WHERE id=? AND active=1", (branch_id,)).fetchone()
        if b: return b["id"]
    if user and user["branch_id"]:
        return user["branch_id"]
    return db.get_default_branch_id(con)

def move_stock(con, variant_id, *args, **kwargs):
    """
    Control atómico de existencias por sucursal en variant_stock.
    Soporta firma multisucursal:
      move_stock(con, variant_id, branch_id, kind, qty, reason, user_id, ref_type=None, ref_id=None)
    Y retrocompatibilidad con llamadas tradicionales de 4/5/6 argumentos:
      move_stock(con, variant_id, kind, qty, reason, user_id)
    """
    if len(args) >= 5 and (isinstance(args[0], int) or args[0] is None):
        branch_id, kind, qty, reason, user_id = args[0], args[1], args[2], args[3], args[4]
        ref_type = args[5] if len(args) > 5 else kwargs.get("ref_type")
        ref_id = args[6] if len(args) > 6 else kwargs.get("ref_id")
    else:
        kind, qty, reason, user_id = args[0], args[1], args[2], args[3]
        branch_id = kwargs.get("branch_id")
        ref_type = args[4] if len(args) > 4 else kwargs.get("ref_type")
        ref_id = args[5] if len(args) > 5 else kwargs.get("ref_id")

    branch_id = _resolve_branch_id(con, branch_id)

    con.execute("""
        INSERT INTO variant_stock (variant_id, branch_id, stock, min_stock, reserved)
        VALUES (?, ?, 0, 1, 0)
        ON CONFLICT(variant_id, branch_id) DO NOTHING
    """, (variant_id, branch_id))

    cur = con.execute("""
        UPDATE variant_stock 
        SET stock = stock + ? 
        WHERE variant_id = ? AND branch_id = ? AND (stock + ?) >= reserved
    """, (qty, variant_id, branch_id, qty))

    if cur.rowcount != 1:
        raise StockError("Existencia insuficiente o variante inexistente en la sucursal.")

    con.execute("""
        UPDATE variants 
        SET stock = (SELECT COALESCE(SUM(stock), 0) FROM variant_stock WHERE variant_id = ?)
        WHERE id = ?
    """, (variant_id, variant_id))

    con.execute("""
        INSERT INTO inventory_movements(variant_id, branch_id, kind, qty, reason, ref_type, ref_id, user_id)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?)
    """, (variant_id, branch_id, kind, qty, reason, ref_type, ref_id, user_id))

def add_variant(con, pid, v, uid, branch_id=None):
    size, color = txt(v.get("size"), "talla", 40) or "", txt(v.get("color"), "color", 40) or ""
    sku = (txt(v.get("sku"), "sku", 60) or "").upper() or f"P{pid}-{size}-{color}".upper().replace(" ", "")
    min_stock = to_int(v.get("min_stock", 1), "mínimo")
    cur = con.execute("INSERT INTO variants(product_id,sku,barcode,size,color,min_stock) VALUES(?,?,?,?,?,?)",
                      (pid, sku, txt(v.get("barcode"), "código de barras", 60), size, color, min_stock))
    vid = cur.lastrowid
    stock = to_int(v.get("stock", 0), "existencia")
    if stock > 1_000_000: raise ValueError("existencia: valor demasiado grande.")

    target_branch = _resolve_branch_id(con, branch_id)
    con.execute("INSERT INTO variant_stock(variant_id, branch_id, stock, min_stock, reserved) VALUES(?,?,0,?,0)",
                (vid, target_branch, min_stock))
    if stock:
        move_stock(con, vid, target_branch, "inicial", stock, "Alta inicial", uid)
    return vid

def add_product(con, d, uid, branch_id=None):
    name = txt(d.get("name"), "nombre", 120)
    if not name: raise ValueError("El nombre es obligatorio.")
    variants = d.get("variants") or []
    if not isinstance(variants, list) or not all(isinstance(x, dict) for x in variants): raise ValueError("Variantes no válidas.")
    if not variants: raise ValueError("Agrega al menos una variante (talla/color).")
    cur = con.execute("INSERT INTO products(name,description,category,brand,cost_cents,price_cents,image) VALUES(?,?,?,?,?,?,?)",
                      (name, txt(d.get("description"), "descripción", 500), txt(d.get("category"), "categoría", 60),
                       txt(d.get("brand"), "marca", 60), cents(d.get("cost", 0), "costo"), cents(d.get("price"), "precio"), img(d.get("image"))))
    pid = cur.lastrowid
    for v in variants:
        add_variant(con, pid, v, uid, branch_id)
    return pid

def serialize(con, p, admin, inactive=False, user_branch_id=None):
    vs = con.execute("SELECT * FROM variants WHERE product_id=?" + ("" if inactive else " AND active=1") + " ORDER BY id", (p["id"],)).fetchall()
    
    variants_out = []
    for v in vs:
        stocks = con.execute("""
            SELECT b.id AS branch_id, b.name AS branch_name, b.code AS branch_code,
                   COALESCE(vs.stock, 0) AS stock, COALESCE(vs.min_stock, ?) AS min_stock,
                   COALESCE(vs.reserved, 0) AS reserved
            FROM branches b
            LEFT JOIN variant_stock vs ON vs.branch_id = b.id AND vs.variant_id = ?
            WHERE b.active = 1 OR vs.variant_id IS NOT NULL
        """, (v["min_stock"], v["id"])).fetchall()
        
        branch_map = {
            r["branch_id"]: {
                "branch_id": r["branch_id"],
                "branch_name": r["branch_name"],
                "branch_code": r["branch_code"],
                "stock": r["stock"],
                "min_stock": r["min_stock"],
                "reserved": r["reserved"],
                "available": r["stock"] - r["reserved"]
            } for r in stocks
        }

        if user_branch_id and user_branch_id in branch_map:
            local_stock = branch_map[user_branch_id]["stock"]
            local_min = branch_map[user_branch_id]["min_stock"]
            local_reserved = branch_map[user_branch_id]["reserved"]
        else:
            local_stock = sum(s["stock"] for s in branch_map.values()) if branch_map else v["stock"]
            local_min = v["min_stock"]
            local_reserved = sum(s["reserved"] for s in branch_map.values()) if branch_map else 0

        total_consolidated = sum(s["stock"] for s in branch_map.values()) if branch_map else v["stock"]

        variants_out.append({
            "id": v["id"],
            "sku": v["sku"],
            "barcode": v["barcode"],
            "size": v["size"],
            "color": v["color"],
            "stock": local_stock,
            "min_stock": local_min,
            "reserved": local_reserved,
            "available": local_stock - local_reserved,
            "consolidated_stock": total_consolidated,
            "branches": branch_map,
            "low": local_stock <= local_min,
            "active": bool(v["active"])
        })

    out = {
        "id": p["id"],
        "name": p["name"],
        "description": p["description"],
        "category": p["category"],
        "brand": p["brand"],
        "price": p["price_cents"] / 100,
        "image": p["image"],
        "active": bool(p["active"]),
        "variants": variants_out
    }
    if admin: out["cost"] = p["cost_cents"] / 100
    return out

def safe(r):
    return "'" + r if isinstance(r, str) and r[:1] in "=+-@" else r

def fail(e):
    if isinstance(e, sqlite3.IntegrityError): return jsonify(error="SKU o código de barras duplicado."), 409
    return jsonify(error=str(e)), 400

@bp.get("/api/products")
@login_required
def products():
    con, admin = db.get_db(), g.user["role"] == "admin"
    show_all = admin and bool(request.args.get("all"))
    q = (request.args.get("q") or "").strip()
    sql, args = "SELECT DISTINCT p.* FROM products p LEFT JOIN variants v ON v.product_id=p.id WHERE 1=1", []
    if not show_all: sql += " AND p.active=1"
    if q:
        like = f"%{q}%"; sql += " AND (p.name LIKE ? OR v.sku LIKE ? OR v.barcode LIKE ?)"; args += [like] * 3
    if request.args.get("category"): sql += " AND p.category=?"; args.append(request.args["category"])
    rows = con.execute(sql + " ORDER BY p.name", args).fetchall()
    
    u_branch = g.user["branch_id"]
    return jsonify(products=[serialize(con, r, admin, show_all, u_branch) for r in rows])

@bp.post("/api/products")
@role_required("admin")
def create_product():
    con = db.get_db()
    d = request.get_json(silent=True) or {}
    branch_id = d.get("branch_id") or g.user["branch_id"]
    try:
        with con:
            pid = add_product(con, d, g.user["id"], branch_id)
            audit(con, g.user["id"], "producto_creado", f"id={pid}")
    except (ValueError, sqlite3.IntegrityError) as e: return fail(e)
    return jsonify(id=pid), 201

@bp.patch("/api/products/<int:pid>")
@role_required("admin")
def edit_product(pid):
    d, con, sets, args = request.get_json(silent=True) or {}, db.get_db(), [], []
    try:
        for k, lim in (("name", 120), ("description", 500), ("category", 60), ("brand", 60)):
            if k in d:
                val = txt(d[k], k, lim)
                if k == "name" and not val: raise ValueError("El nombre es obligatorio.")
                sets.append(f"{k}=?"); args.append(val)
        if "image" in d: sets.append("image=?"); args.append(img(d["image"]))
        for k, col in (("cost", "cost_cents"), ("price", "price_cents")):
            if k in d: sets.append(f"{col}=?"); args.append(cents(d[k], k))
        if "active" in d: sets.append("active=?"); args.append(int(bool(d["active"])))
        if not sets: return jsonify(error="Nada que actualizar."), 400
        with con:
            if con.execute(f"UPDATE products SET {','.join(sets)} WHERE id=?", args + [pid]).rowcount != 1:
                return jsonify(error="Producto no encontrado."), 404
            audit(con, g.user["id"], "producto_editado", f"id={pid} campos={','.join(d)}")
    except ValueError as e: return fail(e)
    return jsonify(ok=True)

@bp.post("/api/products/<int:pid>/variants")
@role_required("admin")
def new_variant(pid):
    con = db.get_db()
    if not con.execute("SELECT 1 FROM products WHERE id=?", (pid,)).fetchone(): return jsonify(error="Producto no encontrado."), 404
    d = request.get_json(silent=True) or {}
    branch_id = d.get("branch_id") or g.user["branch_id"]
    try:
        with con:
            vid = add_variant(con, pid, d, g.user["id"], branch_id)
            audit(con, g.user["id"], "variante_creada", f"id={vid}")
    except (ValueError, sqlite3.IntegrityError) as e: return fail(e)
    return jsonify(id=vid), 201

@bp.patch("/api/variants/<int:vid>")
@role_required("admin")
def edit_variant(vid):
    d, con, sets, args = request.get_json(silent=True) or {}, db.get_db(), [], []
    try:
        for k, lim in (("size", 40), ("color", 40)):
            if k in d: sets.append(f"{k}=?"); args.append(txt(d[k], k, lim) or "")
        if "barcode" in d: sets.append("barcode=?"); args.append(txt(d["barcode"], "código de barras", 60))
        if "sku" in d:
            sku = (txt(d["sku"], "sku", 60) or "").upper()
            if not sku: raise ValueError("El SKU no puede estar vacío.")
            sets.append("sku=?"); args.append(sku)
        if "min_stock" in d: sets.append("min_stock=?"); args.append(to_int(d["min_stock"], "mínimo"))
        if "active" in d: sets.append("active=?"); args.append(int(bool(d["active"])))
        if not sets: return jsonify(error="Nada que actualizar."), 400
        with con:
            if con.execute(f"UPDATE variants SET {','.join(sets)} WHERE id=?", args + [vid]).rowcount != 1:
                return jsonify(error="Variante no encontrada."), 404
            audit(con, g.user["id"], "variante_editada", f"id={vid} campos={','.join(d)}")
    except (ValueError, sqlite3.IntegrityError) as e: return fail(e)
    return jsonify(ok=True)

@bp.post("/api/variants/<int:vid>/adjust")
@role_required("admin")
def adjust(vid):
    d, con = request.get_json(silent=True) or {}, db.get_db()
    reason = str(d.get("reason") or "").strip()
    branch_id = d.get("branch_id") or g.user["branch_id"]
    target_branch = _resolve_branch_id(con, branch_id)
    try:
        delta = int(d.get("delta"))
        if delta == 0: raise ValueError("La cantidad no puede ser 0.")
        if abs(delta) > 1_000_000: raise ValueError("Cantidad fuera de rango.")
        if len(reason) < 5: raise ValueError("Escribe el motivo del ajuste (mín. 5 caracteres).")
        with con:
            move_stock(con, vid, target_branch, "ajuste", delta, reason, g.user["id"])
            audit(con, g.user["id"], "ajuste_inventario", f"variante={vid} sucursal={target_branch} delta={delta}")
    except (TypeError, ValueError) as e: return jsonify(error=str(e) if str(e).count(" ") > 1 else "Cantidad no válida."), 400
    
    current_b_stock = con.execute("SELECT stock FROM variant_stock WHERE variant_id=? AND branch_id=?", (vid, target_branch)).fetchone()[0]
    return jsonify(stock=current_b_stock, branch_id=target_branch)

@bp.get("/api/inventory/low")
@login_required
def low():
    con = db.get_db()
    bid = request.args.get("branch_id", type=int) or g.user["branch_id"]
    sql = """
        SELECT v.id, p.name, v.sku, v.size, v.color, vs.stock, vs.min_stock, b.name as branch_name
        FROM variant_stock vs
        JOIN variants v ON v.id = vs.variant_id
        JOIN products p ON p.id = v.product_id
        JOIN branches b ON b.id = vs.branch_id
        WHERE v.active=1 AND p.active=1 AND vs.stock <= vs.min_stock
    """
    args = []
    if bid:
        sql += " AND vs.branch_id=?"; args.append(bid)
    sql += " ORDER BY vs.stock ASC"
    rows = con.execute(sql, args).fetchall()
    return jsonify(low=[dict(r) for r in rows])

@bp.get("/api/inventory/movements")
@role_required("admin")
def movements():
    vid = request.args.get("variant_id")
    bid = request.args.get("branch_id", type=int)
    sql = """
        SELECT m.*, u.username, v.sku, b.name as branch_name 
        FROM inventory_movements m 
        LEFT JOIN users u ON u.id=m.user_id 
        LEFT JOIN variants v ON v.id=m.variant_id
        LEFT JOIN branches b ON b.id=m.branch_id
        WHERE 1=1
    """
    args = []
    if vid: sql += " AND m.variant_id=?"; args.append(vid)
    if bid: sql += " AND m.branch_id=?"; args.append(bid)
    return jsonify(movements=[dict(r) for r in db.get_db().execute(sql + " ORDER BY m.id DESC LIMIT 200", args).fetchall()])

@bp.post("/api/inventory/clean")
@role_required("admin")
def clean_inventory():
    """
    Saneamiento de inventario con 3 modos estrictos:
    1. 'zero_stock': Ajusta a 0 todas las existencias de forma auditada por sucursal.
    2. 'deactivate': Desactiva lógicamente productos y variantes sin borrar nada.
    3. 'purge_test': Elimina ÚNICAMENTE productos sin ventas, compras, apartados ni traspasos.
    """
    d, con = request.get_json(silent=True) or {}, db.get_db()
    mode = str(d.get("mode") or "").strip().lower()
    reason = str(d.get("reason") or "").strip()
    branch_id = d.get("branch_id")

    if len(reason) < 5:
        return jsonify(error="Se requiere un motivo formal (mín. 5 caracteres) para esta operación."), 400

    if mode == "zero_stock":
        target_branch = _resolve_branch_id(con, branch_id) if branch_id else None
        with con:
            sql = "SELECT variant_id, branch_id, stock FROM variant_stock WHERE stock > 0"
            args = []
            if target_branch:
                sql += " AND branch_id=?"; args.append(target_branch)
            active_stocks = con.execute(sql, args).fetchall()
            
            for row in active_stocks:
                move_stock(con, row["variant_id"], row["branch_id"], "ajuste", -row["stock"], f"Puesta a cero: {reason}", g.user["id"])
            audit(con, g.user["id"], "inventario_puesto_a_cero", f"motivo={reason} registros={len(active_stocks)}")
        return jsonify(ok=True, message=f"Se pusieron a cero {len(active_stocks)} existencias mediante ajustes auditados.")

    elif mode == "deactivate":
        with con:
            c1 = con.execute("UPDATE products SET active=0 WHERE active=1").rowcount
            c2 = con.execute("UPDATE variants SET active=0 WHERE active=1").rowcount
            audit(con, g.user["id"], "inventario_desactivado", f"motivo={reason} productos={c1} variantes={c2}")
        return jsonify(ok=True, message=f"Se desactivaron {c1} productos y {c2} variantes.")

    elif mode == "purge_test":
        with con:
            uncleanable_pids = set(r[0] for r in con.execute("""
                SELECT DISTINCT v.product_id FROM sale_items si JOIN variants v ON v.id = si.variant_id
                UNION
                SELECT DISTINCT v.product_id FROM purchase_items pi JOIN variants v ON v.id = pi.variant_id
                UNION
                SELECT DISTINCT v.product_id FROM transfer_items ti JOIN variants v ON v.id = ti.variant_id
                UNION
                SELECT DISTINCT v.product_id FROM layaway_items li JOIN variants v ON v.id = li.variant_id
            """).fetchall())

            all_pids = set(r[0] for r in con.execute("SELECT id FROM products").fetchall())
            purgeable = all_pids - uncleanable_pids

            if not purgeable:
                return jsonify(error="No hay productos de prueba sin historial comercial para eliminar."), 409

            placeholders = ",".join("?" * len(purgeable))
            p_args = list(purgeable)

            v_rows = con.execute(f"SELECT id FROM variants WHERE product_id IN ({placeholders})", p_args).fetchall()
            v_ids = [r[0] for r in v_rows]
            if v_ids:
                v_placeholders = ",".join("?" * len(v_ids))
                con.execute(f"DELETE FROM variant_stock WHERE variant_id IN ({v_placeholders})", v_ids)
                con.execute(f"DELETE FROM inventory_movements WHERE variant_id IN ({v_placeholders})", v_ids)
                con.execute(f"DELETE FROM variants WHERE id IN ({v_placeholders})", v_ids)
            
            con.execute(f"DELETE FROM products WHERE id IN ({placeholders})", p_args)
            audit(con, g.user["id"], "productos_prueba_eliminados", f"motivo={reason} eliminados={len(purgeable)}")

        return jsonify(ok=True, message=f"Se eliminaron {len(purgeable)} productos de prueba sin historial comercial.")

    return jsonify(error="Modo no válido. Opciones: 'zero_stock', 'deactivate', 'purge_test'."), 400

@bp.get("/api/inventory/export.csv")
@role_required("admin")
def export_csv():
    out = io.StringIO(); w = csv.writer(out); w.writerow(CSV_COLS)
    sql = """
        SELECT p.name, p.category, p.brand, v.sku, v.barcode, v.size, v.color, 
               p.cost_cents, p.price_cents, vs.stock, vs.min_stock, b.code as branch_code
        FROM variant_stock vs
        JOIN variants v ON v.id = vs.variant_id
        JOIN products p ON p.id = v.product_id
        JOIN branches b ON b.id = vs.branch_id
        ORDER BY p.name, v.id, b.id
    """
    for r in db.get_db().execute(sql).fetchall():
        w.writerow([safe(x) for x in (r[0], r[1] or "", r[2] or "", r[3], r[4] or "", r[5] or "", r[6] or "", r[7] / 100, r[8] / 100, r[9], r[10], r[11])])
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=inventario.csv"})

@bp.post("/api/inventory/import")
@role_required("admin")
def import_csv():
    con, text = db.get_db(), str((request.get_json(silent=True) or {}).get("csv") or "").lstrip("\ufeff")
    rows, errors, skipped, groups = list(csv.DictReader(io.StringIO(text))), [], [], {}
    if not rows: return jsonify(error="CSV vacío."), 400
    existing = {r[0] for r in con.execute("SELECT sku FROM variants")}
    
    b_map = {r["code"].upper(): r["id"] for r in con.execute("SELECT id, code FROM branches").fetchall()}
    default_branch = db.get_default_branch_id(con)

    for i, r in enumerate(rows, start=2):
        r = {(k or "").strip().lower(): (v or "").strip() for k, v in r.items()}
        try:
            if not r.get("producto") or not r.get("sku"): raise ValueError("producto y sku son obligatorios.")
            sku = r["sku"].upper()
            if sku in existing: skipped.append(sku); continue
            cents(r.get("precio"), "precio"); cents(r.get("costo") or 0, "costo")
            b_code = (r.get("sucursal") or "").upper()
            branch_id = b_map.get(b_code, default_branch)

            v = {"sku": sku, "barcode": r.get("barcode"), "size": r.get("talla"), "color": r.get("color"),
                 "stock": to_int(r.get("existencia"), "existencia"), "min_stock": to_int(r.get("minimo") or 1, "mínimo")}
            
            key = (r["producto"], r.get("categoria"), r.get("marca"), branch_id)
            g_ = groups.setdefault(key, {"name": r["producto"], "category": r.get("categoria"),
                  "brand": r.get("marca"), "cost": r.get("costo") or 0, "price": r["precio"], "variants": [], "branch_id": branch_id})
            g_["variants"].append(v)
        except ValueError as e: errors.append(f"Línea {i}: {e}")
    if errors: return jsonify(error="El archivo tiene errores; no se importó nada.", detalles=errors[:20]), 400
    try:
        with con:
            for d in groups.values():
                add_product(con, d, g.user["id"], d["branch_id"])
            audit(con, g.user["id"], "importacion_csv", f"productos={len(groups)}")
    except (ValueError, sqlite3.IntegrityError) as e: return fail(e)
    return jsonify(productos=len(groups), variantes=sum(len(x["variants"]) for x in groups.values()), omitidos=skipped)