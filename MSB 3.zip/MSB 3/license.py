import base64, hashlib, hmac, os, platform, subprocess, uuid
from datetime import datetime
from flask import Blueprint, current_app, jsonify, request

bp = Blueprint("license", __name__)

# Semilla secreta para firma criptográfica (solo el autor la conoce para generar claves válidas)
MASTER_SECRET = b"MB_2026_SecKey_LocalLicensing_MarcelaBoutique"

def get_machine_id():
    """Genera un identificador de hardware único y determinista para la máquina."""
    raw = [str(uuid.getnode()), platform.node(), platform.machine()]
    try:
        if platform.system() == "Windows":
            out = subprocess.check_output("wmic csproduct get uuid", shell=True, text=True, stderr=subprocess.DEVNULL)
            lines = [l.strip() for l in out.splitlines() if l.strip() and "UUID" not in l]
            if lines: raw.append(lines[0])
    except Exception:
        pass
    h = hashlib.sha256("::".join(raw).encode("utf-8")).hexdigest().upper()
    return f"MB-{h[:4]}-{h[4:8]}-{h[8:12]}-{h[12:16]}"

def license_file_path(app=None):
    app = app or current_app
    return os.path.join(app.instance_path, "license.sig")

def verify_license_string(lic_str, expected_machine_id=None):
    """Verifica la validez matemática, correspondencia de hardware y vigencia de la clave."""
    if not lic_str or "." not in lic_str:
        return False, "Formato de clave no válido."
    
    parts = lic_str.strip().split(".")
    if len(parts) != 2:
        return False, "Estructura de clave corrupta."
    
    payload_b64, signature = parts[0], parts[1]
    
    # Validar firma HMAC
    expected_sig = hmac.new(MASTER_SECRET, payload_b64.encode("utf-8"), hashlib.sha256).hexdigest().upper()[:24]
    if not hmac.compare_digest(signature.upper(), expected_sig):
        return False, "Firma digital de licencia inválida."
    
    try:
        payload = base64.b64decode(payload_b64.encode("utf-8")).decode("utf-8")
        mid, exp_date, tier = payload.split(":")
    except Exception:
        return False, "Carga de datos de licencia corrupta."
    
    # Validar correspondencia con la máquina física
    current_mid = expected_machine_id or get_machine_id()
    if mid != current_mid:
        return False, f"Esta licencia pertenece a otro equipo ({mid})."
    
    # Validar vigencia
    if exp_date != "PERPETUAL":
        try:
            exp_dt = datetime.strptime(exp_date, "%Y-%m-%d").date()
            if datetime.now().date() > exp_dt:
                return False, f"La licencia expiró el {exp_date}."
        except ValueError:
            return False, "Fecha de vigencia no válida."
    
    return True, {"machine_id": mid, "expires_at": exp_date, "tier": tier}

def is_system_licensed(app=None):
    """Comprueba si el sistema tiene una licencia válida instalada."""
    path = license_file_path(app)
    if not os.path.isfile(path):
        return False, "Licencia no instalada."
    try:
        with open(path, "r", encoding="utf-8") as f:
            lic_str = f.read().strip()
        return verify_license_string(lic_str)
    except Exception as e:
        return False, str(e)

@bp.get("/api/license/status")
def license_status():
    mid = get_machine_id()
    ok, data_or_err = is_system_licensed()
    if ok:
        return jsonify(licensed=True, machine_id=mid, info=data_or_err)
    return jsonify(licensed=False, machine_id=mid, error=data_or_err)

@bp.post("/api/license/activate")
def activate_license():
    d = request.get_json(silent=True) or {}
    key = str(d.get("key") or "").strip()
    if not key:
        return jsonify(error="Ingresa una clave de licencia válida."), 400
    
    mid = get_machine_id()
    ok, res = verify_license_string(key, mid)
    if not ok:
        return jsonify(error=res), 400
    
    # Guardar en archivo local
    os.makedirs(current_app.instance_path, exist_ok=True)
    with open(license_file_path(), "w", encoding="utf-8") as f:
        f.write(key)
        
    return jsonify(ok=True, message="Sistema activado exitosamente.", info=res)